import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Filter for residential loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all beam element IDs that support residential loads
supporting_beam_ids = []

for _, load in residential_loads.iterrows():
    # Parse the nodes for loading area
    node_string = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in node_string.split(',')]
    
    # Create pairs of consecutive nodes (forming the perimeter)
    node_pairs = []
    for i in range(len(nodes)):
        node_pairs.append((nodes[i], nodes[(i+1) % len(nodes)]))
    
    # Find beams that connect these node pairs
    for node1, node2 in node_pairs:
        # Check both directions (node1->node2 and node2->node1)
        beam = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        if not beam.empty:
            # Check if it's a beam (horizontal element - no change in Z coordinate)
            node1_z = node_df[node_df['Node ID'] == node1]['Z (m)'].iloc[0]
            node2_z = node_df[node_df['Node ID'] == node2]['Z (m)'].iloc[0]
            
            if node1_z == node2_z:  # Horizontal element (beam)
                supporting_beam_ids.extend(beam['Element ID'].tolist())

# Remove duplicates and sort
supporting_beam_ids = sorted(list(set(supporting_beam_ids)))

# Create output dataframe
output_df = pd.DataFrame({'Element ID': supporting_beam_ids})

# Save to CSV
output_df.to_csv('Task_5_out.csv', index=False)