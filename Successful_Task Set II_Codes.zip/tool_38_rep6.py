import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_38_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find second floor elevation (one floor above first floor)
unique_z = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z[1]  # Second unique z-value

# Find X-2 grid coordinate (second unique x-coordinate)
unique_x = sorted(node_df['X (m)'].unique())
x2_coord = unique_x[1]  # Second unique x-coordinate

# Find material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Find nodes on first floor (z = first_floor_z) at X-2 grid
first_floor_x2_nodes = node_df[(node_df['Z (m)'] == first_floor_z) & (node_df['X (m)'] == x2_coord)]['Node ID'].tolist()

# Find nodes on second floor (z = second_floor_z) at X-2 grid  
second_floor_x2_nodes = node_df[(node_df['Z (m)'] == second_floor_z) & (node_df['X (m)'] == x2_coord)]['Node ID'].tolist()

# Find columns connecting first floor X-2 nodes to second floor X-2 nodes
for element_id, row in element_df.iterrows():
    node1 = row['Node 1']
    node2 = row['Node 2']
    
    # Check if this is a column on X-2 grid connecting first floor to second floor
    if ((node1 in first_floor_x2_nodes and node2 in second_floor_x2_nodes) or 
        (node2 in first_floor_x2_nodes and node1 in second_floor_x2_nodes)):
        
        # Get node coordinates to verify it's a column (vertical element)
        node1_coords = node_df[node_df['Node ID'] == node1][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Check if it's a column (only z changes, x and y remain same)
        if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
            node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
            node1_coords['Z (m)'] != node2_coords['Z (m)']):
            
            # Update material to SHN355
            element_df.at[element_id, 'Material'] = shn355_material

# Save updated Element.csv
element_df.to_csv('Task_38_out/Element.csv', index=False)

print("Updated Element.csv saved to Task_38_out folder")
print(f"First floor columns along grid X-2 updated to material SHN355 (Material Number: {shn355_material})")