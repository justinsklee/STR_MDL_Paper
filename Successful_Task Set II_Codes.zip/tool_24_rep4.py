import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_24_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Get second floor elevation (one story above ground)
second_floor_z = nodes_df[nodes_df['Z (m)'] > first_floor_z]['Z (m)'].min()

# Function to classify elements
def classify_element(row, nodes_df):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if element is a brace (diagonal): change in (x or y) AND z coordinates
    if (x1 != x2 or y1 != y2) and z1 != z2:
        return 'brace'
    # Check if element is a column (vertical): change ONLY in z coordinates
    elif x1 == x2 and y1 == y2 and z1 != z2:
        return 'column'
    # Check if element is a beam (horizontal): NO change in z coordinates
    elif z1 == z2:
        return 'beam'
    else:
        return 'unknown'

# Add element classification
elements_df['element_type'] = elements_df.apply(lambda row: classify_element(row, nodes_df), axis=1)

# Find first floor braces
first_floor_braces = []
for idx, row in elements_df.iterrows():
    if row['element_type'] == 'brace':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1_z = nodes_df[nodes_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
        node2_z = nodes_df[nodes_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
        
        # Check if one node is at first floor and the other is above first floor
        if (node1_z == first_floor_z and node2_z > first_floor_z) or \
           (node2_z == first_floor_z and node1_z > first_floor_z):
            first_floor_braces.append(row['Element ID'])

# Update material for first floor braces
for element_id in first_floor_braces:
    elements_df.loc[elements_df['Element ID'] == element_id, 'Material'] = 1003

# Remove the temporary classification column
elements_df = elements_df.drop('element_type', axis=1)

# Sort by Element ID
elements_df = elements_df.sort_values('Element ID')

# Save updated Element.csv
elements_df.to_csv('Task_24_out/Element.csv', index=False)

print(f"Updated {len(first_floor_braces)} first floor braces with material 1003")
print(f"First floor brace element IDs: {first_floor_braces}")