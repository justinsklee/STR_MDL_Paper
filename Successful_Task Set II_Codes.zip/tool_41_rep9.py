import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations
floor_elevations = sorted(node_df['Z (m)'].unique())
roof_elevation = max(floor_elevations)

# Filter beams with section 101 on the roof level
roof_beams_101 = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    section = element['Section']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates of both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in Z coordinates) and on roof level
    if (node1['Z (m)'] == node2['Z (m)'] == roof_elevation and section == 101):
        roof_beams_101.append(element_id)

# Get section properties for section 101
section_101 = section_df[section_df['Section Number'] == 101].iloc[0]
area = section_101['Area']  # m²

# Calculate total weight
total_weight = 0
density = 7850  # kg/m³

for element_id in roof_beams_101:
    element = element_df[element_df['Element ID'] == element_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Calculate length
    length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                     (node2['Y (m)'] - node1['Y (m)'])**2 + 
                     (node2['Z (m)'] - node1['Z (m)'])**2)
    
    # Calculate weight for this beam
    weight = area * length * density
    total_weight += weight

# Round up to nearest 10 kg
total_weight_rounded = np.ceil(total_weight / 10) * 10

# Create output DataFrame
output_df = pd.DataFrame({
    'Total Weight (kg)': [int(total_weight_rounded)]
})

# Save to CSV
output_df.to_csv('Task_41_out.csv', index=False)