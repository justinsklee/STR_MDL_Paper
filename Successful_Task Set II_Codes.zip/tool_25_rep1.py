import pandas as pd
import os

# Load CSV files
node_df = pd.read_csv('Node.csv')
element_df = pd.read_csv('Element.csv')
material_df = pd.read_csv('Material.csv')

# Create output folder
os.makedirs('Task_25_out', exist_ok=True)

# Find unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
third_floor_elevation = floor_elevations[2]

# Find nodes at third floor elevation
third_floor_nodes = node_df[node_df['Z (m)'] == third_floor_elevation]['Node ID'].tolist()

# Find material number for SS400
ss400_material = material_df[material_df['Name'] == 'SS400']['Material Number'].iloc[0]

# Identify columns: elements where only z-coordinate changes between nodes
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only z changes, x and y stay same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Find third floor columns (columns with one node at third floor and other node above)
third_floor_columns = []
for col_id in columns:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if one node is at third floor and other is above
    if ((node1_z == third_floor_elevation and node2_z > third_floor_elevation) or
        (node2_z == third_floor_elevation and node1_z > third_floor_elevation)):
        third_floor_columns.append(col_id)

# Update material for third floor columns
element_df.loc[element_df['Element ID'].isin(third_floor_columns), 'Material'] = ss400_material

# Save updated Element.csv
element_df.to_csv('Task_25_out/Element.csv', index=False)

print(f"Updated {len(third_floor_columns)} third floor columns with SS400 material")