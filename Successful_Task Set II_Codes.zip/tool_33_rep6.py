import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_33_out', exist_ok=True)

# Load CSV files
beam_end_release = pd.read_csv('Beam_end_release.csv')
element = pd.read_csv('Element.csv')
node = pd.read_csv('Node.csv')

# Find X-3 grid coordinate (third unique X coordinate)
unique_x_coords = sorted(node['X (m)'].unique())
x3_coord = unique_x_coords[2]  # X-3 is the third X coordinate

# Find braces along grid X-3
# Braces are diagonal elements (change in x/y AND z coordinates)
# Along grid X-3 means both nodes have the same X coordinate as X-3
braces_on_x3 = []

for _, elem in element.iterrows():
    elem_id = elem['Element ID']
    node1_id = elem['Node 1']
    node2_id = elem['Node 2']
    
    # Get node coordinates
    node1 = node[node['Node ID'] == node1_id].iloc[0]
    node2 = node[node['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on X-3 grid
    if abs(node1['X (m)'] - x3_coord) < 1e-6 and abs(node2['X (m)'] - x3_coord) < 1e-6:
        # Check if it's a brace (change in x/y AND z coordinates)
        x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
        y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
        z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
        
        # Brace: change in (x or y) AND z coordinates
        if (x_change or y_change) and z_change:
            braces_on_x3.append(elem_id)

# Remove beam-end-release for braces along grid X-3
beam_end_release_updated = beam_end_release[~beam_end_release['Element ID'].isin(braces_on_x3)]

# Sort by Element ID in ascending order
beam_end_release_updated = beam_end_release_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated beam end release file
beam_end_release_updated.to_csv('Task_33_out/Beam_end_release.csv', index=False)