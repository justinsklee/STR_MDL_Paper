import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_30_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Fourth floor is at index 3 (0-based indexing: 0=1st, 1=2nd, 2=3rd, 3=4th)
if len(floor_elevations) >= 4:
    fourth_floor_elevation = floor_elevations[3]
    
    # Find braces on the fourth floor
    # Braces have one node at the floor and another node above the floor
    braces_to_remove = []
    
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a brace (diagonal element)
        # Braces have change in (x or y) AND z coordinates
        x_change = node1_coords['X (m)'] != node2_coords['X (m)']
        y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        
        is_brace = (x_change or y_change) and z_change
        
        if is_brace:
            # Check if one node is at fourth floor and the other is above
            node1_at_fourth = node1_coords['Z (m)'] == fourth_floor_elevation
            node2_at_fourth = node2_coords['Z (m)'] == fourth_floor_elevation
            node1_above_fourth = node1_coords['Z (m)'] > fourth_floor_elevation
            node2_above_fourth = node2_coords['Z (m)'] > fourth_floor_elevation
            
            if (node1_at_fourth and node2_above_fourth) or (node2_at_fourth and node1_above_fourth):
                braces_to_remove.append(row['Element ID'])
    
    # Remove the identified braces
    element_df = element_df[~element_df['Element ID'].isin(braces_to_remove)]
    
    # Sort by Element ID in ascending order
    element_df = element_df.sort_values('Element ID').reset_index(drop=True)
    
    # Save updated Element.csv
    element_df.to_csv('Task_30_out/Element.csv', index=False)
    
    print(f"Removed {len(braces_to_remove)} braces from fourth floor")
    if braces_to_remove:
        print(f"Removed brace elements: {braces_to_remove}")
else:
    print("Model does not have a fourth floor")
    # Still save the original file
    element_df.to_csv('Task_30_out/Element.csv', index=False)