import pandas as pd
import os

# Create output folder
os.makedirs('Task_37_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')
node_df = pd.read_csv('Node.csv')

# Identify columns (vertical elements - change only in z coordinates)
columns = []
for _, elem in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == elem['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == elem['Node 2']].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(elem['Element ID'])

# Identify beams (horizontal elements - no change in z coordinates)
beams = []
for _, elem in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == elem['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == elem['Node 2']].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(elem['Element ID'])

# Find beams directly connected to columns
beams_connected_to_columns = set()
for beam_id in beams:
    beam = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_nodes = [beam['Node 1'], beam['Node 2']]
    
    # Check if any column shares a node with this beam
    for column_id in columns:
        column = element_df[element_df['Element ID'] == column_id].iloc[0]
        column_nodes = [column['Node 1'], column['Node 2']]
        
        if any(node in column_nodes for node in beam_nodes):
            beams_connected_to_columns.add(beam_id)
            break

# Identify sub-beams (beams not directly connected to columns)
sub_beams = [beam_id for beam_id in beams if beam_id not in beams_connected_to_columns]

# Find sub-beams that have beam-end-release (i-end release = '11' and j-end release = '11')
released_sub_beams = []
for sub_beam_id in sub_beams:
    release_row = beam_end_release_df[beam_end_release_df['Element ID'] == sub_beam_id]
    if not release_row.empty:
        release = release_row.iloc[0]
        if str(release['i-end release']) == '11' and str(release['j-end release']) == '11':
            released_sub_beams.append(sub_beam_id)

# Remove sub-beams that are NOT beam-end-released
sub_beams_to_remove = [sub_beam_id for sub_beam_id in sub_beams if sub_beam_id not in released_sub_beams]

# Filter out the sub-beams to remove from the element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_to_remove)]

# Sort by Element ID
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_37_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_to_remove)} sub-beams that are not beam-end-released")
print(f"Sub-beams removed: {sub_beams_to_remove}")