import pandas as pd
import numpy as np

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
sections_df = pd.read_csv('Long_Section.csv')

# Find the highest floor elevation (roof level)
max_z = nodes_df['Z (m)'].max()

# Find grid X-1 coordinate (first X-direction grid line)
x_coords = sorted(nodes_df['X (m)'].unique())
x1_coord = x_coords[0]  # X-1 grid coordinate

# Get roof level nodes
roof_nodes = nodes_df[nodes_df['Z (m)'] == max_z]

# Find beams on the roof level along grid X-1
roof_beams = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (same Z coordinate, no change in Z)
    if node1['Z (m)'] == node2['Z (m)']:
        # Check if it's on roof level
        if node1['Z (m)'] == max_z:
            # Check if both nodes are on grid X-1
            if node1['X (m)'] == x1_coord and node2['X (m)'] == x1_coord:
                # Calculate beam length
                length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                               (node2['Y (m)'] - node1['Y (m)'])**2 + 
                               (node2['Z (m)'] - node1['Z (m)'])**2)
                
                # Check if length > 1.3m
                if length > 1.3:
                    section_name = sections_df[sections_df['Section Number'] == element['Section']]['Section Name'].iloc[0]
                    roof_beams.append({
                        'Element ID': element['Element ID'],
                        'Section Name': section_name
                    })

# Create output dataframe
output_df = pd.DataFrame(roof_beams)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_49_out.csv', index=False)