import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Get all unique z-coordinates and sort them to find floor levels
z_coords = sorted(node_df['Z (m)'].unique())
first_floor_z = z_coords[0]
second_floor_z = z_coords[1] if len(z_coords) > 1 else first_floor_z + 1

# Merge element data with node coordinates for both nodes
element_with_coords = element_df.merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 1', right_on='Node ID', 
    suffixes=('', '_node1')
).merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 2', right_on='Node ID', 
    suffixes=('_node1', '_node2')
)

# Identify first floor bracing elements
# Braces are diagonal elements: change in (x or y) coordinates AND z coordinates
# For first floor bracing: one node at first floor level, other node above first floor level
first_floor_braces = []

for _, row in element_with_coords.iterrows():
    x1, y1, z1 = row['X (m)_node1'], row['Y (m)_node1'], row['Z (m)_node1']
    x2, y2, z2 = row['X (m)_node2'], row['Y (m)_node2'], row['Z (m)_node2']
    
    # Check if element is a brace (diagonal): change in (x or y) AND z coordinates
    has_xy_change = (x1 != x2) or (y1 != y2)
    has_z_change = (z1 != z2)
    is_brace = has_xy_change and has_z_change
    
    # Check if it's first floor bracing: one node at first floor, other above
    is_first_floor_brace = is_brace and (
        (z1 == first_floor_z and z2 > first_floor_z) or 
        (z2 == first_floor_z and z1 > first_floor_z)
    )
    
    if is_first_floor_brace:
        first_floor_braces.append({
            'Element ID': row['Element ID'],
            'Section': row['Section']
        })

# Create output dataframe
output_df = pd.DataFrame(first_floor_braces)
output_df = output_df.sort_values('Element ID').reset_index(drop=True)

# Save to CSV
output_df.to_csv('Task_13_out.csv', index=False)

print(f"Found {len(first_floor_braces)} first floor bracing elements")
print(output_df)