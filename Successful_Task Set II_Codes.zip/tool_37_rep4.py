import pandas as pd
import os

# Create output folder
os.makedirs('Task_37_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify columns (vertical elements - only z coordinate changes)
columns = []
for _, elem in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == elem['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == elem['Node 2']].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(elem['Element ID'])

# Identify beams (horizontal elements - no change in z coordinate)
beams = []
for _, elem in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == elem['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == elem['Node 2']].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(elem['Element ID'])

# Find beams directly connected to columns
beams_connected_to_columns = set()
for beam_id in beams:
    beam_elem = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_nodes = [beam_elem['Node 1'], beam_elem['Node 2']]
    
    # Check if any column shares a node with this beam
    for col_id in columns:
        col_elem = element_df[element_df['Element ID'] == col_id].iloc[0]
        col_nodes = [col_elem['Node 1'], col_elem['Node 2']]
        
        if any(node in col_nodes for node in beam_nodes):
            beams_connected_to_columns.add(beam_id)
            break

# Identify sub-beams (beams not directly connected to columns)
sub_beams = [beam_id for beam_id in beams if beam_id not in beams_connected_to_columns]

# Get beam-end-released elements
beam_end_released = set(beam_end_release_df['Element ID'].tolist())

# Find sub-beams that are NOT beam-end-released
sub_beams_not_released = [sub_beam for sub_beam in sub_beams if sub_beam not in beam_end_released]

# Remove these sub-beams from the element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_not_released)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_37_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_not_released)} sub-beams that are not beam-end-released: {sub_beams_not_released}")
print(f"Updated Element.csv saved with {len(updated_element_df)} elements")