import pandas as pd
import os

# Create output folder
os.makedirs('Task_47_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
support_df = pd.read_csv('Support.csv')
sections_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (minimum z-coordinate)
first_floor_z = nodes_df['Z (m)'].min()

# Find Y-1 grid coordinate (minimum y-coordinate)
y1_grid_coord = nodes_df['Y (m)'].min()

# Find nodes on first floor and Y-1 grid
first_floor_nodes = nodes_df[nodes_df['Z (m)'] == first_floor_z]
y1_grid_nodes = first_floor_nodes[first_floor_nodes['Y (m)'] == y1_grid_coord]

# Find columns that have one node on first floor Y-1 grid and other node above
first_floor_columns = []
for _, node in y1_grid_nodes.iterrows():
    node_id = node['Node ID']
    # Find elements connected to this node
    connected_elements = elements_df[(elements_df['Node 1'] == node_id) | (elements_df['Node 2'] == node_id)]
    
    for _, element in connected_elements.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates of both nodes
        node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        # Check if it's a column (vertical element with same x,y coordinates)
        if (node1['X (m)'] == node2['X (m)'] and 
            node1['Y (m)'] == node2['Y (m)'] and 
            node1['Z (m)'] != node2['Z (m)']):
            
            # Check if it has section 101
            if element['Section'] == 101:
                # Check if one node is on first floor and other is above
                if ((node1['Z (m)'] == first_floor_z and node2['Z (m)'] > first_floor_z) or
                    (node2['Z (m)'] == first_floor_z and node1['Z (m)'] > first_floor_z)):
                    first_floor_columns.append(element['Element ID'])

# Find support nodes for these columns (nodes on first floor)
support_nodes_to_update = []
for _, node in y1_grid_nodes.iterrows():
    node_id = node['Node ID']
    # Check if this node is connected to any of our identified columns
    connected_elements = elements_df[(elements_df['Node 1'] == node_id) | (elements_df['Node 2'] == node_id)]
    
    for _, element in connected_elements.iterrows():
        if element['Element ID'] in first_floor_columns:
            support_nodes_to_update.append(node_id)
            break

# Update support conditions to pin (Rx=0, Ry=0, Rz=0)
for node_id in support_nodes_to_update:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated Support.csv
support_df.to_csv('Task_47_out/Support.csv', index=False)