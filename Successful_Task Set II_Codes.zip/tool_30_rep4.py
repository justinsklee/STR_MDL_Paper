import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_30_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Fourth floor is at index 3 (0-indexed: ground=0, 2nd=1, 3rd=2, 4th=3)
if len(floor_elevations) >= 4:
    fourth_floor_z = floor_elevations[3]
    
    # Find nodes on the fourth floor
    fourth_floor_nodes = nodes_df[nodes_df['Z (m)'] == fourth_floor_z]['Node ID'].tolist()
    
    # Find nodes above the fourth floor
    above_fourth_floor_nodes = nodes_df[nodes_df['Z (m)'] > fourth_floor_z]['Node ID'].tolist()
    
    # Identify braces on fourth floor
    # Braces have one node on the fourth floor and another node above it
    braces_to_remove = []
    
    for idx, row in elements_df.iterrows():
        node1 = row['Node 1']
        node2 = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = nodes_df[nodes_df['Node ID'] == node1][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = nodes_df[nodes_df['Node ID'] == node2][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Check if element is a brace (diagonal element)
        x_change = node1_coords['X (m)'] != node2_coords['X (m)']
        y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        
        is_brace = z_change and (x_change or y_change)
        
        # Check if brace is connected to fourth floor
        if is_brace:
            node1_on_fourth = node1 in fourth_floor_nodes
            node2_above_fourth = node2 in above_fourth_floor_nodes
            node2_on_fourth = node2 in fourth_floor_nodes
            node1_above_fourth = node1 in above_fourth_floor_nodes
            
            if (node1_on_fourth and node2_above_fourth) or (node2_on_fourth and node1_above_fourth):
                braces_to_remove.append(row['Element ID'])
    
    # Remove identified braces
    elements_df = elements_df[~elements_df['Element ID'].isin(braces_to_remove)]
    
    # Sort by Element ID
    elements_df = elements_df.sort_values('Element ID').reset_index(drop=True)
    
    # Save updated Element.csv
    elements_df.to_csv('Task_30_out/Element.csv', index=False)
    
    print(f"Removed {len(braces_to_remove)} braces from fourth floor")
    print(f"Removed brace IDs: {braces_to_remove}")
else:
    print("Model does not have a fourth floor")
    # Still save the original file
    elements_df.to_csv('Task_30_out/Element.csv', index=False)