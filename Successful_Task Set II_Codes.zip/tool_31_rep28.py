import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
if len(floor_elevations) > 2:
    third_floor_z = floor_elevations[2]
else:
    third_floor_z = None

if third_floor_z is not None:
    # Find beams on the third floor (both nodes at same z-coordinate = third_floor_z)
    third_floor_beams = []
    
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if it's a beam (both nodes at same z-coordinate and at third floor level)
        if (node1_coords['Z (m)'] == node2_coords['Z (m)'] == third_floor_z):
            third_floor_beams.append(element['Element ID'])
    
    # Find columns on third floor (elements with one node at third floor and other above)
    third_floor_columns = []
    
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if it's a column (vertical element with one node at third floor)
        node1_z = node1_coords['Z (m)']
        node2_z = node2_coords['Z (m)']
        
        if ((node1_z == third_floor_z and node2_z > third_floor_z) or 
            (node2_z == third_floor_z and node1_z > third_floor_z)):
            # Check if it's vertical (same x,y coordinates)
            if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                node1_coords['Y (m)'] == node2_coords['Y (m)']):
                third_floor_columns.append(element['Element ID'])
    
    # Get column node IDs at third floor level
    column_nodes_at_third_floor = set()
    
    for col_id in third_floor_columns:
        element = element_df[element_df['Element ID'] == col_id].iloc[0]
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        node1_z = node_df[node_df['Node ID'] == node1_id].iloc[0]['Z (m)']
        node2_z = node_df[node_df['Node ID'] == node2_id].iloc[0]['Z (m)']
        
        # Add the node that's at third floor level
        if node1_z == third_floor_z:
            column_nodes_at_third_floor.add(node1_id)
        if node2_z == third_floor_z:
            column_nodes_at_third_floor.add(node2_id)
    
    # Identify sub-beams (beams not directly connected to columns)
    sub_beams = []
    
    for beam_id in third_floor_beams:
        element = element_df[element_df['Element ID'] == beam_id].iloc[0]
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Check if beam is connected to any column nodes
        if node1_id not in column_nodes_at_third_floor and node2_id not in column_nodes_at_third_floor:
            sub_beams.append(beam_id)
    
    # Create output data for sub-beams
    output_data = []
    
    for beam_id in sorted(sub_beams):
        # Check if beam has release in beam_end_release_df
        release_row = beam_end_release_df[beam_end_release_df['Element ID'] == beam_id]
        
        if not release_row.empty:
            i_release = release_row.iloc[0]['i-end release']
            j_release = release_row.iloc[0]['j-end release']
            
            # Convert release codes to 0 (released) or 1 (fixed)
            # '11' means released, '10' means fixed
            i_status = 0 if str(i_release) == '11' else 1
            j_status = 0 if str(j_release) == '11' else 1
        else:
            # No release specified means fixed
            i_status = 1
            j_status = 1
        
        output_data.append([beam_id, i_status, j_status])
    
    # Create DataFrame and save to CSV
    output_df = pd.DataFrame(output_data, columns=['Element Number', 'i-end (0=released, 1=fixed)', 'j-end (0=released, 1=fixed)'])
    output_df.to_csv('Task_31_out.csv', index=False)

else:
    # Create empty DataFrame if no third floor exists
    output_df = pd.DataFrame(columns=['Element Number', 'i-end (0=released, 1=fixed)', 'j-end (0=released, 1=fixed)'])
    output_df.to_csv('Task_31_out.csv', index=False)