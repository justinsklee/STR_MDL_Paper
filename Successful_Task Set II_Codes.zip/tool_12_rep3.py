import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Extract supporting beam elements for residential loads
supporting_beams = []

for _, load in residential_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create beam connections for the 4-node load area
    # Beams connect: (node1,node2), (node2,node3), (node3,node4), (node4,node1)
    beam_connections = [
        (nodes[0], nodes[1]),
        (nodes[1], nodes[2]), 
        (nodes[2], nodes[3]),
        (nodes[3], nodes[0])
    ]
    
    # Find elements that match these beam connections
    for node1, node2 in beam_connections:
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            # Check if it's a beam (horizontal element - same Z coordinate)
            z1 = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
            z2 = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
            
            if z1 == z2:  # Beam condition
                supporting_beams.append({
                    'Element ID': element['Element ID'],
                    'Section': element['Section']
                })

# Remove duplicates
supporting_beams_df = pd.DataFrame(supporting_beams).drop_duplicates()

# Get section names
supporting_beams_df = supporting_beams_df.merge(
    long_section_df[['Section Number', 'Section Name']], 
    left_on='Section', 
    right_on='Section Number'
)

# Create output with only requested information
output_df = supporting_beams_df[['Element ID', 'Section Name']].sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_12_out.csv', index=False)