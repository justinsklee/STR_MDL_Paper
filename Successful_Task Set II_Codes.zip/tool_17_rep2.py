import pandas as pd

# Load the Floor_Load.csv file
floor_load_df = pd.read_csv('Floor_Load.csv')

# Extract the required information
# Parse the nodes from the "Nodes for Loading Area" column
result_data = []

for index, row in floor_load_df.iterrows():
    load_name = row['Load Type']
    nodes_str = row['Nodes for Loading Area']
    
    # Parse the nodes string to extract individual node numbers
    nodes_list = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Ensure we have exactly 4 nodes, pad with None if necessary
    while len(nodes_list) < 4:
        nodes_list.append(None)
    
    result_data.append([load_name, nodes_list[0], nodes_list[1], nodes_list[2], nodes_list[3]])

# Create DataFrame with the required columns
result_df = pd.DataFrame(result_data, columns=['Load Name', 'Node 1', 'Node 2', 'Node 3', 'Node 4'])

# Save to CSV file
result_df.to_csv('Task_17_out.csv', index=False)