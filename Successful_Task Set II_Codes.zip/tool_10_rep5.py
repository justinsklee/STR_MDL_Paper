import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')
node_df = pd.read_csv('Node.csv')

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    z1, z2 = node1['Z (m)'], node2['Z (m)']
    x1, x2 = node1['X (m)'], node2['X (m)']
    y1, y2 = node1['Y (m)'], node2['Y (m)']
    
    # Column: only z changes
    if z1 != z2 and x1 == x2 and y1 == y2:
        return 'Column'
    # Beam: no z change
    elif z1 == z2:
        return 'Beam'
    # Brace: z changes and (x or y) changes
    else:
        return 'Brace'

element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Get all beams
beams_df = element_df[element_df['Element_Type'] == 'Beam'].copy()

# Find columns and their connected nodes
columns_df = element_df[element_df['Element_Type'] == 'Column']
column_nodes = set()
for _, col in columns_df.iterrows():
    column_nodes.add(col['Node 1'])
    column_nodes.add(col['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for _, beam in beams_df.iterrows():
    node1 = beam['Node 1']
    node2 = beam['Node 2']
    
    # If neither node is connected to a column, it's a sub-beam
    if node1 not in column_nodes and node2 not in column_nodes:
        sub_beams.append(beam['Element ID'])

# Get beam-end-released elements
released_elements = set(beam_end_release_df['Element ID'].tolist())

# Find sub-beams that are NOT beam-end-released
unreleased_sub_beams = [elem_id for elem_id in sub_beams if elem_id not in released_elements]
unreleased_sub_beams.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': unreleased_sub_beams})

# Save to CSV
output_df.to_csv('Task_10_out.csv', index=False)