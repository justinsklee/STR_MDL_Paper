import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_40_out'
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Find unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Find second floor elevation (index 1 since ground is index 0)
second_floor_z = floor_elevations[1]

# Find Y-1 grid coordinate (minimum Y coordinate)
y1_coord = nodes_df['Y (m)'].min()

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    if z_change and (x_change or y_change):
        return 'brace'
    elif z_change and not x_change and not y_change:
        return 'column'
    elif not z_change:
        return 'beam'
    else:
        return 'unknown'

# Function to check if element is on Y-1 grid
def is_on_y1_grid(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    return (abs(node1['Y (m)'] - y1_coord) < 1e-6 and 
            abs(node2['Y (m)'] - y1_coord) < 1e-6)

# Function to check if brace is associated with second floor
def is_second_floor_brace(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # For braces, one node should be at second floor and other above
    node1_z = node1['Z (m)']
    node2_z = node2['Z (m)']
    
    return (abs(node1_z - second_floor_z) < 1e-6 and node2_z > second_floor_z) or \
           (abs(node2_z - second_floor_z) < 1e-6 and node1_z > second_floor_z)

# Identify elements to remove
elements_to_remove = []

for idx, row in elements_df.iterrows():
    element_type = classify_element(row)
    
    if (element_type == 'brace' and 
        is_on_y1_grid(row) and 
        is_second_floor_brace(row)):
        elements_to_remove.append(row['Element ID'])

# Remove identified elements
updated_elements_df = elements_df[~elements_df['Element ID'].isin(elements_to_remove)]

# Sort by Element ID
updated_elements_df = updated_elements_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_elements_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Removed {len(elements_to_remove)} second floor braces along grid Y-1")
if elements_to_remove:
    print(f"Removed element IDs: {elements_to_remove}")