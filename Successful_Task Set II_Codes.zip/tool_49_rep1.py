import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find the highest floor elevation (roof level)
max_z = node_df['Z (m)'].max()

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Filter beams on the roof level
roof_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in z-coordinate)
    if node1['Z (m)'] == node2['Z (m)']:
        # Check if it's on the roof level
        if node1['Z (m)'] == max_z:
            # Check if it's on grid X-1 (both nodes have same x-coordinate as X-1)
            if node1['X (m)'] == x1_coord and node2['X (m)'] == x1_coord:
                # Calculate beam length
                length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                               (node2['Y (m)'] - node1['Y (m)'])**2 + 
                               (node2['Z (m)'] - node1['Z (m)'])**2)
                
                # Check if length > 1.3m
                if length > 1.3:
                    # Get section name
                    section_num = element['Section']
                    section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
                    
                    roof_beams.append({
                        'Element ID': element['Element ID'],
                        'Section Name': section_name
                    })

# Create output dataframe
output_df = pd.DataFrame(roof_beams)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_49_out.csv', index=False)

print(f"Found {len(output_df)} roof beams longer than 1.3m along grid X-1")
print(output_df)