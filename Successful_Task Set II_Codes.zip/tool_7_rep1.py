import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get section number for H 100x100x6/8
target_section = section_df[section_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    if z_change and not x_change and not y_change:
        return 'Column'
    elif not z_change:
        return 'Beam'
    elif z_change and (x_change or y_change):
        return 'Brace'
    
element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Find braces with section H 100x100x6/8
braces_with_target_section = element_df[
    (element_df['Element_Type'] == 'Brace') & 
    (element_df['Section'] == target_section)
]

# Get all nodes connected to these braces
brace_nodes = set()
for _, brace in braces_with_target_section.iterrows():
    brace_nodes.add(brace['Node 1'])
    brace_nodes.add(brace['Node 2'])

# Find beams connected to these nodes
beams = element_df[element_df['Element_Type'] == 'Beam']
connected_beams = []

for _, beam in beams.iterrows():
    if beam['Node 1'] in brace_nodes or beam['Node 2'] in brace_nodes:
        connected_beams.append(beam['Element ID'])

# Create output dataframe
result_df = pd.DataFrame({
    'Element ID': sorted(connected_beams)
})

# Save to CSV
result_df.to_csv('Task_7_out.csv', index=False)