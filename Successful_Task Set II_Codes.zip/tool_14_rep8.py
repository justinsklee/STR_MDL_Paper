import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
material_df = pd.read_csv('Material.csv')
node_df = pd.read_csv('Node.csv')

# Find the maximum Z coordinate to identify the roof level
max_z = node_df['Z (m)'].max()

# Get nodes at the roof level
roof_nodes = node_df[node_df['Z (m)'] == max_z]['Node ID'].tolist()

# Find roof beams (horizontal elements at the highest Z level)
roof_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are at roof level and element is horizontal (beam)
    if (node1['Z (m)'] == max_z and node2['Z (m)'] == max_z and 
        node1['Z (m)'] == node2['Z (m)']):
        
        # Get material name
        material_id = element['Material']
        material_name = material_df[material_df['Material Number'] == material_id]['Name'].iloc[0]
        
        roof_beams.append({
            'Element ID': element['Element ID'],
            'Material Name': material_name
        })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(roof_beams)
result_df = result_df.sort_values('Element ID').reset_index(drop=True)

# Save to CSV
result_df.to_csv('Task_14_out.csv', index=False)

print("Roof beams information:")
print(result_df)