import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_43_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Find X1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify braces: elements with change in both horizontal (x or y) and vertical (z) coordinates
braces = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (change in z AND change in x or y)
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 0.001
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 0.001
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 0.001
    
    if z_change and (x_change or y_change):
        braces.append(element['Element ID'])

# Find braces along grid X1 (both nodes have x-coordinate equal to X1)
braces_on_x1 = []
for brace_id in braces:
    element = element_df[element_df['Element ID'] == brace_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on X1 grid
    if abs(node1['X (m)'] - x1_coord) < 0.001 and abs(node2['X (m)'] - x1_coord) < 0.001:
        braces_on_x1.extend([node1_id, node2_id])

# Get unique support nodes that support braces on X1 grid
support_nodes_for_x1_braces = list(set(braces_on_x1))

# Apply pin support (release rotational constraints) to these nodes
for node_id in support_nodes_for_x1_braces:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated Support.csv
support_df.to_csv('Task_43_out/Support.csv', index=False)