import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_25_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is the 3rd elevation (index 2)
third_floor_elevation = floor_elevations[2]

# Find all columns that have one node at third floor elevation
# Columns are vertical elements (same x,y coordinates, different z coordinates)
columns_on_third_floor = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is at third floor elevation and the other is above
        if ((node1['Z (m)'] == third_floor_elevation and node2['Z (m)'] > third_floor_elevation) or
            (node2['Z (m)'] == third_floor_elevation and node1['Z (m)'] > third_floor_elevation)):
            columns_on_third_floor.append(element['Element ID'])

# Get material number for SS400
ss400_material = material_df[material_df['Name'] == 'SS400']['Material Number'].iloc[0]

# Update material for third floor columns
for col_id in columns_on_third_floor:
    element_df.loc[element_df['Element ID'] == col_id, 'Material'] = ss400_material

# Save updated Element.csv
element_df.to_csv('Task_25_out/Element.csv', index=False)

print(f"Updated {len(columns_on_third_floor)} third floor columns to SS400 material")