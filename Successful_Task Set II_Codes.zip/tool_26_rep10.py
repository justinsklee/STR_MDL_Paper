import pandas as pd
import os

# Create output folder
output_folder = 'Task_26_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Find unique floor elevations
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation (index 1)
second_floor_z = floor_elevations[1]

# Identify beams on second floor
# Beams are elements where both nodes have the same Z coordinate and no change in Z
beam_elements = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in Z coordinate)
    if node1_coords['Z (m)'] == node2_coords['Z (m)']:
        # Check if it's on the second floor
        if node1_coords['Z (m)'] == second_floor_z:
            beam_elements.append(element['Element ID'])

# Update material for second floor beams
element_df.loc[element_df['Element ID'].isin(beam_elements), 'Material'] = shn355_material

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)