import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support node IDs
support_nodes = set(support_df['Node'].values)

# Classify elements
columns = []
braces = []

for _, row in element_df.iterrows():
    element_id = row['Element ID']
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if element is column (vertical: only z changes)
    if x1 == x2 and y1 == y2 and z1 != z2:
        columns.append(element_id)
    # Check if element is brace (diagonal: x or y changes AND z changes)
    elif (x1 != x2 or y1 != y2) and z1 != z2:
        braces.append(element_id)

# Find columns that share support nodes with bracing elements
columns_sharing_supports = []

for col_id in columns:
    col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
    col_node1 = col_row['Node 1']
    col_node2 = col_row['Node 2']
    
    # Check if column has nodes at support level
    col_support_nodes = []
    if col_node1 in support_nodes:
        col_support_nodes.append(col_node1)
    if col_node2 in support_nodes:
        col_support_nodes.append(col_node2)
    
    if col_support_nodes:
        # Check if any brace shares these support nodes
        for brace_id in braces:
            brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
            brace_node1 = brace_row['Node 1']
            brace_node2 = brace_row['Node 2']
            
            # Check if brace shares any support node with column
            if (brace_node1 in col_support_nodes or brace_node2 in col_support_nodes):
                if col_id not in columns_sharing_supports:
                    columns_sharing_supports.append(col_id)

# Create output dataframe
result_df = pd.DataFrame({
    'Element ID': sorted(columns_sharing_supports)
})

# Save to CSV
result_df.to_csv('Task_8_out.csv', index=False)

print(f"Found {len(columns_sharing_supports)} columns sharing supports with bracing elements")
print(result_df)