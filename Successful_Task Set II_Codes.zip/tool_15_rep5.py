import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation level (index 1)
second_floor_elevation = floor_elevations[1]

# Create a mapping of node ID to coordinates
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Find second floor bracing elements
second_floor_braces = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    x1, y1, z1 = node_coords[node1_id]
    x2, y2, z2 = node_coords[node2_id]
    
    # Check if this is a brace (diagonal element with change in x/y AND z coordinates)
    x_change = abs(x2 - x1) > 1e-6
    y_change = abs(y2 - y1) > 1e-6
    z_change = abs(z2 - z1) > 1e-6
    
    is_brace = z_change and (x_change or y_change)
    
    # Check if brace is associated with second floor
    # One node should be at second floor elevation, the other above
    node_at_second_floor = (abs(z1 - second_floor_elevation) < 1e-6 or 
                           abs(z2 - second_floor_elevation) < 1e-6)
    node_above_second_floor = (z1 > second_floor_elevation or z2 > second_floor_elevation)
    
    if is_brace and node_at_second_floor and node_above_second_floor:
        second_floor_braces.append({
            'Element ID': element['Element ID'],
            'Material': element['Material']
        })

# Create output dataframe and sort by Element ID
output_df = pd.DataFrame(second_floor_braces)
if not output_df.empty:
    output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_15_out.csv', index=False)

print(f"Found {len(second_floor_braces)} second floor bracing elements")
print(output_df)