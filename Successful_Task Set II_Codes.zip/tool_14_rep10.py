import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
material_df = pd.read_csv('Material.csv')
node_df = pd.read_csv('Node.csv')

# Find the maximum Z coordinate (roof level)
max_z = node_df['Z (m)'].max()

# Get nodes at the roof level
roof_nodes = node_df[node_df['Z (m)'] == max_z]['Node ID'].tolist()

# Find beams (horizontal elements with no change in Z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in Z coordinates)
    if node1_z == node2_z:
        beams.append(element)

# Filter roof beams (beams at the maximum Z level)
roof_beams = []
for beam in beams:
    node1_id = beam['Node 1']
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    
    if node1_z == max_z:
        roof_beams.append(beam)

# Create result dataframe with element numbers and material names
result_data = []
for beam in roof_beams:
    element_id = beam['Element ID']
    material_id = beam['Material']
    material_name = material_df[material_df['Material Number'] == material_id]['Name'].iloc[0]
    
    result_data.append({
        'Element ID': element_id,
        'Material Name': material_name
    })

# Sort by Element ID
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_14_out.csv', index=False)

print(result_df)