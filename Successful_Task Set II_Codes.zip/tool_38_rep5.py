import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_38_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find second floor elevation (one story above first floor)
second_floor_z = node_df[node_df['Z (m)'] > first_floor_z]['Z (m)'].min()

# Find X-2 grid coordinate (second X grid line)
unique_x_coords = sorted(node_df['X (m)'].unique())
x2_coord = unique_x_coords[1]  # X-2 is the second X grid

# Find material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Identify first floor columns along grid X-2
# Columns are vertical elements with one node at first floor and other node above
first_floor_nodes = node_df[(node_df['Z (m)'] == first_floor_z) & (node_df['X (m)'] == x2_coord)]['Node ID'].tolist()
second_floor_nodes = node_df[(node_df['Z (m)'] == second_floor_z) & (node_df['X (m)'] == x2_coord)]['Node ID'].tolist()

# Find columns connecting first floor to second floor at X-2 grid
target_elements = []
for _, element in element_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Check if this is a column (vertical element) at X-2 grid
    if ((node1 in first_floor_nodes and node2 in second_floor_nodes) or 
        (node2 in first_floor_nodes and node1 in second_floor_nodes)):
        
        # Verify it's actually a column (vertical element)
        node1_coords = node_df[node_df['Node ID'] == node1][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Column: only Z changes, X and Y remain same
        if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
            node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
            node1_coords['Z (m)'] != node2_coords['Z (m)']):
            target_elements.append(element['Element ID'])

# Update material for identified columns
element_df.loc[element_df['Element ID'].isin(target_elements), 'Material'] = shn355_material

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_38_out/Element.csv', index=False)

print(f"Updated {len(target_elements)} first floor columns along grid X-2 to use SHN355 material")
print(f"Updated Element IDs: {target_elements}")