import pandas as pd

# Load the Floor_Load.csv file
floor_load_df = pd.read_csv('Floor_Load.csv')

# Extract load names and defining nodes
result_data = []

for index, row in floor_load_df.iterrows():
    load_name = row['Load Type']
    nodes_str = row['Nodes for Loading Area']
    
    # Parse the nodes string to extract individual node numbers
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Ensure we have exactly 4 nodes, pad with None if necessary
    while len(nodes) < 4:
        nodes.append(None)
    
    result_data.append([load_name, nodes[0], nodes[1], nodes[2], nodes[3]])

# Create DataFrame with the required format
result_df = pd.DataFrame(result_data, columns=['Load Name', 'Node 1', 'Node 2', 'Node 3', 'Node 4'])

# Save to CSV file
result_df.to_csv('Task_17_out.csv', index=False)