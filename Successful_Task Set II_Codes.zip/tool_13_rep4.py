import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_elevation = floor_elevations[0]  # Ground level (z = 0.0m)
second_floor_elevation = floor_elevations[1] if len(floor_elevations) > 1 else None

# Create node coordinate lookup
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = {'x': row['X (m)'], 'y': row['Y (m)'], 'z': row['Z (m)']}

# Find first floor bracing
first_floor_bracing = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_coords[node1_id]
    node2_coords = node_coords[node2_id]
    
    # Check if this is a brace (diagonal element: change in x/y AND z coordinates)
    x_change = abs(node1_coords['x'] - node2_coords['x']) > 1e-6
    y_change = abs(node1_coords['y'] - node2_coords['y']) > 1e-6
    z_change = abs(node1_coords['z'] - node2_coords['z']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if one node is at first floor and the other is above
        node1_at_first_floor = abs(node1_coords['z'] - first_floor_elevation) < 1e-6
        node2_at_first_floor = abs(node2_coords['z'] - first_floor_elevation) < 1e-6
        
        node1_above_first_floor = node1_coords['z'] > first_floor_elevation
        node2_above_first_floor = node2_coords['z'] > first_floor_elevation
        
        # First floor bracing: one node at first floor, other node above first floor
        if (node1_at_first_floor and node2_above_first_floor) or (node2_at_first_floor and node1_above_first_floor):
            first_floor_bracing.append({
                'Element ID': element_id,
                'Section Number': element['Section']
            })

# Sort by Element ID
first_floor_bracing.sort(key=lambda x: x['Element ID'])

# Create DataFrame and save to CSV
result_df = pd.DataFrame(first_floor_bracing)
result_df.to_csv('Task_13_out.csv', index=False)

print(f"Found {len(first_floor_bracing)} first floor bracing elements")
print(result_df)