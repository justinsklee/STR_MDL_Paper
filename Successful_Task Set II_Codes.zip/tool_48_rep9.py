import pandas as pd
import numpy as np
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_48_out', exist_ok=True)

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find Y-1 grid coordinate (minimum y-coordinate)
y1_coord = node_df['Y (m)'].min()

# Find all braces on first floor along grid Y-1
# Braces: elements with change in both (x or y) AND z coordinates
# First floor braces: one node at first floor level, other node above
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (change in x/y AND z)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if brace is on first floor (one node at z=0, other above)
        node1_at_first_floor = abs(node1['Z (m)'] - first_floor_z) < 1e-6
        node2_at_first_floor = abs(node2['Z (m)'] - first_floor_z) < 1e-6
        node1_above_first_floor = node1['Z (m)'] > first_floor_z
        node2_above_first_floor = node2['Z (m)'] > first_floor_z
        
        is_first_floor_brace = (node1_at_first_floor and node2_above_first_floor) or (node2_at_first_floor and node1_above_first_floor)
        
        if is_first_floor_brace:
            # Check if brace is along grid Y-1 (both nodes have same y-coordinate as Y-1)
            node1_on_y1 = abs(node1['Y (m)'] - y1_coord) < 1e-6
            node2_on_y1 = abs(node2['Y (m)'] - y1_coord) < 1e-6
            
            is_on_y1_grid = node1_on_y1 and node2_on_y1
            
            if is_on_y1_grid:
                # Check if current section is 101
                if row['Section'] == 101:
                    # Change section to 103
                    element_df.at[idx, 'Section'] = 103

# Sort by Element ID in ascending order
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv file
element_df.to_csv('Task_48_out/Element.csv', index=False)