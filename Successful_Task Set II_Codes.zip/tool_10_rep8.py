import pandas as pd
import numpy as np

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify columns (vertical elements - change only in z coordinates)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Column: change only in z, no change in x and y
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams (horizontal elements - no change in z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Beam: no change in z coordinates
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Find sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    beam_element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_element['Node 1']
    node2_id = beam_element['Node 2']
    
    # Check if either node is connected to a column
    connected_to_column = False
    for column_id in columns:
        column_element = element_df[element_df['Element ID'] == column_id].iloc[0]
        column_node1 = column_element['Node 1']
        column_node2 = column_element['Node 2']
        
        if node1_id in [column_node1, column_node2] or node2_id in [column_node1, column_node2]:
            connected_to_column = True
            break
    
    if not connected_to_column:
        sub_beams.append(beam_id)

# Find sub-beams that are NOT beam-end-released
# Beam-end-release means 'i-end release' and 'j-end release' entries are '11'
released_elements = set(beam_end_release_df['Element ID'].tolist())

# Sub-beams that are NOT beam-end-released
sub_beams_not_released = [beam_id for beam_id in sub_beams if beam_id not in released_elements]

# Sort in ascending order
sub_beams_not_released.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sub_beams_not_released})

# Save to CSV
output_df.to_csv('Task_10_out.csv', index=False)

print(f"Sub-beams not beam-end-released: {len(sub_beams_not_released)} elements")
print(output_df)