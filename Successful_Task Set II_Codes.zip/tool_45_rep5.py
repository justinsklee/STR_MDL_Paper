import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')
material_df = pd.read_csv('Material.csv')

# Find unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation (index 1)
second_floor_z = floor_elevations[1]

# Find Y-1 grid coordinate (minimum Y coordinate)
y1_coord = node_df['Y (m)'].min()

# Find nodes on second floor at Y-1 grid
second_floor_y1_nodes = node_df[
    (node_df['Z (m)'] == second_floor_z) & 
    (node_df['Y (m)'] == y1_coord)
]['Node ID'].tolist()

# Find columns on second floor along Y-1 grid
# Columns have one node on the floor and another node above the floor
columns_on_second_floor_y1 = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a column (vertical element - only Z changes, X and Y stay same)
    is_column = (node1['X (m)'] == node2['X (m)']) and (node1['Y (m)'] == node2['Y (m)']) and (node1['Z (m)'] != node2['Z (m)'])
    
    if is_column:
        # Check if one node is on second floor at Y-1 grid and the other is above
        node1_on_second_y1 = (node1['Z (m)'] == second_floor_z) and (node1['Y (m)'] == y1_coord)
        node2_on_second_y1 = (node2['Z (m)'] == second_floor_z) and (node2['Y (m)'] == y1_coord)
        
        node1_above_second = node1['Z (m)'] > second_floor_z
        node2_above_second = node2['Z (m)'] > second_floor_z
        
        if (node1_on_second_y1 and node2_above_second) or (node2_on_second_y1 and node1_above_second):
            columns_on_second_floor_y1.append(element)

# Create result dataframe
result_data = []
for column in columns_on_second_floor_y1:
    element_id = column['Element ID']
    section_num = column['Section']
    material_num = column['Material']
    
    # Get section name
    section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
    
    # Get material name
    material_name = material_df[material_df['Material Number'] == material_num]['Name'].iloc[0]
    
    result_data.append({
        'Element ID': element_id,
        'Section Name': section_name,
        'Material Name': material_name
    })

# Sort by Element ID
result_df = pd.DataFrame(result_data).sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_45_out.csv', index=False)

print("Results saved to Task_45_out.csv")
print(result_df)