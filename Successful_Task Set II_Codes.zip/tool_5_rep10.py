import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Filter for residential loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all beam element IDs supporting residential loads
beam_elements = []

for _, load in residential_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # For each load area defined by 4 nodes, find beams connecting them
    # The beams form a rectangle: (node1,node2), (node2,node3), (node3,node4), (node4,node1)
    beam_pairs = [
        (nodes[0], nodes[1]),
        (nodes[1], nodes[2]), 
        (nodes[2], nodes[3]),
        (nodes[3], nodes[0])
    ]
    
    # Find elements that match these node pairs
    for node1, node2 in beam_pairs:
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        beam_elements.extend(matching_elements['Element ID'].tolist())

# Remove duplicates and sort
beam_elements = sorted(list(set(beam_elements)))

# Create output dataframe
output_df = pd.DataFrame({'Element ID': beam_elements})

# Save to CSV
output_df.to_csv('Task_5_out.csv', index=False)