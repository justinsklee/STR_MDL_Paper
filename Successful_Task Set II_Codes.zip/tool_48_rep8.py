import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_48_out', exist_ok=True)

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find Y-1 grid coordinate (first Y-direction grid line)
y_coords = sorted(node_df['Y (m)'].unique())
y1_coord = y_coords[0]  # Y-1 grid coordinate

# Identify braces on first floor along grid Y-1
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal: change in x/y AND z coordinates)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 0.001
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 0.001
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 0.001
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if both nodes are on Y-1 grid
        node1_on_y1 = abs(node1['Y (m)'] - y1_coord) < 0.001
        node2_on_y1 = abs(node2['Y (m)'] - y1_coord) < 0.001
        
        if node1_on_y1 and node2_on_y1:
            # Check if one node is at first floor level
            node1_at_first_floor = abs(node1['Z (m)'] - first_floor_z) < 0.001
            node2_at_first_floor = abs(node2['Z (m)'] - first_floor_z) < 0.001
            
            # Check if the other node is above first floor
            node1_above_first_floor = node1['Z (m)'] > first_floor_z + 0.001
            node2_above_first_floor = node2['Z (m)'] > first_floor_z + 0.001
            
            # Brace on first floor: one node at first floor, other above
            if (node1_at_first_floor and node2_above_first_floor) or (node2_at_first_floor and node1_above_first_floor):
                # Check if current section is 101
                if row['Section'] == 101:
                    element_df.at[idx, 'Section'] = 103

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_48_out/Element.csv', index=False)