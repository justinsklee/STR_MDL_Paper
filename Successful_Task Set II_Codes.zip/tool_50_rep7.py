import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Function to calculate element length
def calculate_length(node1_id, node2_id, node_df):
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = node2['X (m)'] - node1['X (m)']
    dy = node2['Y (m)'] - node1['Y (m)']
    dz = node2['Z (m)'] - node1['Z (m)']
    
    return np.sqrt(dx**2 + dy**2 + dz**2)

# Function to classify elements
def classify_element(element_row, node_df):
    node1_id = element_row['Node 1']
    node2_id = element_row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    tolerance = 1e-6
    
    if dz < tolerance:
        return 'beam'
    elif dx < tolerance and dy < tolerance:
        return 'column'
    else:
        return 'brace'

# Classify all elements
element_df['Element_Type'] = element_df.apply(lambda row: classify_element(row, node_df), axis=1)

# Get beams only
beams_df = element_df[element_df['Element_Type'] == 'beam'].copy()

# Find beams supporting office loads
supporting_beams = []

for _, office_load in office_loads.iterrows():
    nodes_str = office_load['Nodes for Loading Area']
    load_nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create pairs of consecutive nodes (forming the perimeter)
    node_pairs = []
    for i in range(len(load_nodes)):
        node_pairs.append((load_nodes[i], load_nodes[(i+1) % len(load_nodes)]))
    
    # Find beams that connect these node pairs
    for node1, node2 in node_pairs:
        beam = beams_df[
            ((beams_df['Node 1'] == node1) & (beams_df['Node 2'] == node2)) |
            ((beams_df['Node 1'] == node2) & (beams_df['Node 2'] == node1))
        ]
        
        if not beam.empty:
            supporting_beams.append(beam.iloc[0]['Element ID'])

# Remove duplicates
supporting_beams = list(set(supporting_beams))

# Create result dataframe
result_data = []
for beam_id in supporting_beams:
    beam = element_df[element_df['Element ID'] == beam_id].iloc[0]
    section_num = beam['Section']
    length = calculate_length(beam['Node 1'], beam['Node 2'], node_df)
    
    result_data.append({
        'Element ID': beam_id,
        'Section Number': section_num,
        'Length (m)': round(length, 4)
    })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_50_out.csv', index=False)

print(result_df)