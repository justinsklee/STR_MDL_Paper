import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_24_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Find first floor elevation (minimum z-coordinate)
first_floor_z = nodes_df['Z (m)'].min()

# Find second floor elevation (next unique z-coordinate above first floor)
unique_z = sorted(nodes_df['Z (m)'].unique())
second_floor_z = unique_z[1] if len(unique_z) > 1 else first_floor_z + 1

# Identify first floor braces
first_floor_braces = []

for idx, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates of both nodes
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    node1_coords = (node1['X (m)'], node1['Y (m)'], node1['Z (m)'])
    node2_coords = (node2['X (m)'], node2['Y (m)'], node2['Z (m)'])
    
    # Check if element is a brace (changes in x/y AND z coordinates)
    x_change = node1_coords[0] != node2_coords[0]
    y_change = node1_coords[1] != node2_coords[1]
    z_change = node1_coords[2] != node2_coords[2]
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if it's a first floor brace (one node at first floor, other above)
        node1_at_first = node1_coords[2] == first_floor_z
        node2_at_first = node2_coords[2] == first_floor_z
        node1_above_first = node1_coords[2] > first_floor_z
        node2_above_first = node2_coords[2] > first_floor_z
        
        if (node1_at_first and node2_above_first) or (node2_at_first and node1_above_first):
            first_floor_braces.append(element['Element ID'])

# Update material for first floor braces
for brace_id in first_floor_braces:
    elements_df.loc[elements_df['Element ID'] == brace_id, 'Material'] = 1003

# Save updated Element.csv
elements_df.to_csv('Task_24_out/Element.csv', index=False)

print(f"Updated {len(first_floor_braces)} first floor braces to material 1003")
print(f"First floor brace elements: {first_floor_braces}")