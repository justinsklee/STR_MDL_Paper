import pandas as pd

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Find X-1 grid coordinate (minimum X coordinate)
x1_coord = nodes_df['X (m)'].min()

# Get nodes that are on X-1 grid
x1_nodes = nodes_df[nodes_df['X (m)'] == x1_coord]['Node ID'].tolist()

# Filter elements where both nodes are on X-1 grid
elements_on_x1 = elements_df[
    (elements_df['Node 1'].isin(x1_nodes)) & 
    (elements_df['Node 2'].isin(x1_nodes))
]

# Identify braces (elements with change in both horizontal and vertical coordinates)
braces_on_x1 = []

for _, element in elements_on_x1.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if there's change in Z coordinate (vertical)
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    # Check if there's change in Y coordinate (since X is constant on X-1 grid)
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    
    # Brace: change in both Y and Z coordinates
    if z_change and y_change:
        braces_on_x1.append(element['Element ID'])

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(braces_on_x1)})

# Save to CSV
output_df.to_csv('Task_3_out.csv', index=False)