import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
roof_elevation = max(floor_elevations)

# Get unique X coordinates and sort them to identify grids
x_coords = sorted(node_df['X (m)'].unique())
grid_x1_coord = x_coords[0]  # X-1 grid is at the first X coordinate

# Filter nodes at roof level and on grid X-1
roof_nodes = node_df[node_df['Z (m)'] == roof_elevation]
grid_x1_nodes = roof_nodes[roof_nodes['X (m)'] == grid_x1_coord]['Node ID'].tolist()

# Find beams (horizontal elements with no change in Z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in Z coordinates)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element)

# Filter beams at roof level and on grid X-1
roof_grid_x1_beams = []
for beam in beams:
    node1_id = beam['Node 1']
    node2_id = beam['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if beam is at roof level and both nodes are on grid X-1
    if (node1['Z (m)'] == roof_elevation and node2['Z (m)'] == roof_elevation and
        node1['X (m)'] == grid_x1_coord and node2['X (m)'] == grid_x1_coord):
        
        # Calculate beam length
        length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                        (node2['Y (m)'] - node1['Y (m)'])**2 + 
                        (node2['Z (m)'] - node1['Z (m)'])**2)
        
        if length > 1.3:
            roof_grid_x1_beams.append(beam)

# Get section names for the filtered beams
results = []
for beam in roof_grid_x1_beams:
    section_number = beam['Section']
    section_name = section_df[section_df['Section Number'] == section_number]['Section Name'].iloc[0]
    results.append({
        'Element ID': beam['Element ID'],
        'Section Name': section_name
    })

# Create output DataFrame and save to CSV
output_df = pd.DataFrame(results)
output_df = output_df.sort_values('Element ID')
output_df.to_csv('Task_49_out.csv', index=False)

print(f"Found {len(results)} roof beams longer than 1.3m along grid X-1")
print(output_df)