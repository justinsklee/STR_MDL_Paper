import pandas as pd

# Load all relevant CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')
sections_df = pd.read_csv('Long_Section.csv')

# Find section number for H 100x100x6/8
target_section = sections_df[sections_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if coordinates change
    x_change = abs(x2 - x1) > 1e-6
    y_change = abs(y2 - y1) > 1e-6
    z_change = abs(z2 - z1) > 1e-6
    
    if z_change and not x_change and not y_change:
        return 'Column'
    elif not z_change:
        return 'Beam'
    elif z_change and (x_change or y_change):
        return 'Brace'
    else:
        return 'Unknown'

# Add element classification
elements_df['Element_Type'] = elements_df.apply(classify_element, axis=1)

# Find braces with the target section
braces_with_target_section = elements_df[
    (elements_df['Element_Type'] == 'Brace') & 
    (elements_df['Section'] == target_section)
]

# Get all nodes connected to these braces
brace_nodes = set()
for _, brace in braces_with_target_section.iterrows():
    brace_nodes.add(brace['Node 1'])
    brace_nodes.add(brace['Node 2'])

# Find beams connected to these nodes
beams_df = elements_df[elements_df['Element_Type'] == 'Beam']
connected_beams = beams_df[
    (beams_df['Node 1'].isin(brace_nodes)) | 
    (beams_df['Node 2'].isin(brace_nodes))
]

# Get unique beam element numbers and sort
beam_element_numbers = sorted(connected_beams['Element ID'].unique())

# Create output dataframe
output_df = pd.DataFrame({'Element ID': beam_element_numbers})

# Save to CSV
output_df.to_csv('Task_7_out.csv', index=False)