import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_33_out', exist_ok=True)

# Load CSV files
beam_end_release_df = pd.read_csv('Beam_end_release.csv')
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find X-3 grid coordinate (third unique X coordinate)
unique_x_coords = sorted(node_df['X (m)'].unique())
x3_coord = unique_x_coords[2]  # X-3 is the third X coordinate

# Find braces along grid X-3
# Braces are diagonal elements (change in both horizontal and vertical coordinates)
braces_on_x3 = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on X-3 grid
    if node1['X (m)'] == x3_coord and node2['X (m)'] == x3_coord:
        # Check if it's a brace (change in both horizontal and vertical coordinates)
        x_change = abs(node1['X (m)'] - node2['X (m)'])
        y_change = abs(node1['Y (m)'] - node2['Y (m)'])
        z_change = abs(node1['Z (m)'] - node2['Z (m)'])
        
        # Brace: change in (x or y) AND z coordinates
        if z_change > 0 and (x_change > 0 or y_change > 0):
            braces_on_x3.append(element_id)

# Remove beam-end-release for braces along grid X-3
updated_beam_end_release_df = beam_end_release_df[~beam_end_release_df['Element ID'].isin(braces_on_x3)]

# Sort by Element ID in ascending order
updated_beam_end_release_df = updated_beam_end_release_df.sort_values('Element ID').reset_index(drop=True)

# Save updated beam end release file
updated_beam_end_release_df.to_csv('Task_33_out/Beam_end_release.csv', index=False)

print(f"Removed beam-end-release for {len(braces_on_x3)} braces along grid X-3")
if braces_on_x3:
    print(f"Affected elements: {braces_on_x3}")