import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that define residential load areas
residential_nodes = []
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    residential_nodes.extend(nodes)

residential_nodes = list(set(residential_nodes))

# Find beams that connect the nodes defining residential load areas
supporting_beams = []

for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create pairs of consecutive nodes (including wraparound)
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]
        
        # Find beam connecting these nodes (check both directions)
        beam = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        if not beam.empty:
            supporting_beams.extend(beam['Element ID'].tolist())

# Remove duplicates and sort
supporting_beams = sorted(list(set(supporting_beams)))

# Filter for beams only (horizontal elements with same Z coordinates)
beam_elements = []
for elem_id in supporting_beams:
    elem_row = element_df[element_df['Element ID'] == elem_id].iloc[0]
    node1_id = elem_row['Node 1']
    node2_id = elem_row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (same Z coordinate)
    if node1['Z (m)'] == node2['Z (m)']:
        beam_elements.append(elem_id)

# Get section information for the beams
result_data = []
for elem_id in sorted(beam_elements):
    elem_row = element_df[element_df['Element ID'] == elem_id].iloc[0]
    section_num = elem_row['Section']
    section_row = long_section_df[long_section_df['Section Number'] == section_num].iloc[0]
    section_name = section_row['Section Name']
    
    result_data.append({
        'Element ID': elem_id,
        'Section Name': section_name
    })

# Create output DataFrame
output_df = pd.DataFrame(result_data)

# Save to CSV
output_df.to_csv('Task_12_out.csv', index=False)

print(f"Found {len(result_data)} beams supporting residential live load")
print(output_df)