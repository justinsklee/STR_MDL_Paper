import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_33_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Find X-3 grid coordinate (third unique x-coordinate when sorted)
unique_x_coords = sorted(node_df['X (m)'].unique())
if len(unique_x_coords) >= 3:
    x3_coord = unique_x_coords[2]  # Third x-coordinate (X-3 grid)
else:
    x3_coord = None

if x3_coord is not None:
    # Find braces along grid X-3
    braces_x3 = []
    
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates for both nodes
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if both nodes are on X-3 grid
        if (abs(node1['X (m)'] - x3_coord) < 1e-6 and 
            abs(node2['X (m)'] - x3_coord) < 1e-6):
            
            # Check if it's a brace (diagonal element)
            # Brace: change in (x or y) AND z coordinates
            x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
            y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
            z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
            
            if (x_change or y_change) and z_change:
                braces_x3.append(element['Element ID'])

    # Remove beam-end-release entries for braces along X-3 grid
    updated_beam_end_release_df = beam_end_release_df[~beam_end_release_df['Element ID'].isin(braces_x3)]
    
    # Sort by Element ID in ascending order
    updated_beam_end_release_df = updated_beam_end_release_df.sort_values('Element ID').reset_index(drop=True)
    
    # Save updated file
    updated_beam_end_release_df.to_csv(os.path.join(output_folder, 'Beam_end_release.csv'), index=False)
    
    print(f"Removed beam-end-release for {len(braces_x3)} braces along grid X-3")
    if braces_x3:
        print(f"Removed elements: {braces_x3}")
else:
    print("X-3 grid not found in the model")
    # Save original file if no X-3 grid exists
    beam_end_release_df.to_csv(os.path.join(output_folder, 'Beam_end_release.csv'), index=False)