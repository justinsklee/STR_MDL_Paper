import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_32_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Identify third floor elevation (index 2, since 0-indexed)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
    
    # Find all elements that are braces on the third floor
    # Braces have one node at third floor and another node above third floor
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        node1_z = node1_coords['Z (m)']
        node2_z = node2_coords['Z (m)']
        node1_x = node1_coords['X (m)']
        node1_y = node1_coords['Y (m)']
        node2_x = node2_coords['X (m)']
        node2_y = node2_coords['Y (m)']
        
        # Check if this is a brace (diagonal element with change in x/y AND z coordinates)
        has_xy_change = (node1_x != node2_x) or (node1_y != node2_y)
        has_z_change = node1_z != node2_z
        is_brace = has_xy_change and has_z_change
        
        # Check if it's a third floor brace (one node at third floor, other above)
        is_third_floor_brace = False
        if is_brace:
            if (node1_z == third_floor_elevation and node2_z > third_floor_elevation) or \
               (node2_z == third_floor_elevation and node1_z > third_floor_elevation):
                is_third_floor_brace = True
        
        # Update section to 102 for third floor braces
        if is_third_floor_brace:
            element_df.at[idx, 'Section'] = 102

# Sort by Element ID in ascending order
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv file
element_df.to_csv('Task_32_out/Element.csv', index=False)