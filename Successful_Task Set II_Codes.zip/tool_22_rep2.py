import pandas as pd
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Get roof nodes (nodes at the highest elevation)
roof_nodes = node_df[node_df['Z (m)'] == roof_elevation]['Node ID'].tolist()

# Identify columns (vertical elements with same x,y coordinates but different z coordinates)
column_elements = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        column_elements.append(element['Element ID'])

# Identify beams on the roof (horizontal elements at roof elevation)
roof_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam on the roof (horizontal element at roof elevation)
    if (node1['Z (m)'] == roof_elevation and 
        node2['Z (m)'] == roof_elevation and
        node1['Z (m)'] == node2['Z (m)']):
        roof_beams.append(element['Element ID'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams_on_roof = []
for beam_id in roof_beams:
    beam = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam['Node 1']
    node2_id = beam['Node 2']
    
    # Check if either node is connected to a column
    connected_to_column = False
    for col_id in column_elements:
        column = element_df[element_df['Element ID'] == col_id].iloc[0]
        if (node1_id in [column['Node 1'], column['Node 2']] or 
            node2_id in [column['Node 1'], column['Node 2']]):
            connected_to_column = True
            break
    
    # If not connected to column, it's a sub-beam
    if not connected_to_column:
        sub_beams_on_roof.append(beam_id)

# Update section for sub-beams on roof to 104
for sub_beam_id in sub_beams_on_roof:
    element_df.loc[element_df['Element ID'] == sub_beam_id, 'Section'] = 104

# Sort by Element ID in ascending order
element_df = element_df.sort_values('Element ID')

# Save the updated Element.csv file
element_df.to_csv('Task_22_out/Element.csv', index=False)