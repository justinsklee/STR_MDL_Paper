import pandas as pd
import os

# Create output folder
output_folder = 'Task_21_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor elevation (one floor above ground level)
second_floor_elevation = floor_elevations[1]

# Find columns that have one node at second floor elevation and another node above it
second_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element - only z changes, x and y stay same)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        
        # Check if one node is at second floor and the other is above
        if ((node1_coords['Z (m)'] == second_floor_elevation and node2_coords['Z (m)'] > second_floor_elevation) or
            (node2_coords['Z (m)'] == second_floor_elevation and node1_coords['Z (m)'] > second_floor_elevation)):
            second_floor_columns.append(element['Element ID'])

# Update section to 102 for second floor columns
for col_id in second_floor_columns:
    element_df.loc[element_df['Element ID'] == col_id, 'Section'] = 102

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)