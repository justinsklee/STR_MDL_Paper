import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_46_out', exist_ok=True)

# Find the first floor elevation (minimum z value)
first_floor_z = node_df['Z (m)'].min()

# Find X-1 grid coordinate (minimum x value)
x1_coord = node_df['X (m)'].min()

# Identify first floor columns along grid X-1
# Columns are vertical elements with change only in z coordinates
# First floor columns have one node at first floor level and another above
first_floor_nodes = node_df[node_df['Z (m)'] == first_floor_z]['Node ID'].tolist()
nodes_above_first_floor = node_df[node_df['Z (m)'] > first_floor_z]['Node ID'].tolist()

# Find nodes on X-1 grid at first floor
x1_first_floor_nodes = node_df[(node_df['X (m)'] == x1_coord) & (node_df['Z (m)'] == first_floor_z)]['Node ID'].tolist()

# Find nodes on X-1 grid above first floor
x1_above_first_floor_nodes = node_df[(node_df['X (m)'] == x1_coord) & (node_df['Z (m)'] > first_floor_z)]['Node ID'].tolist()

# Find first floor columns on X-1 grid
first_floor_x1_columns = []
for _, element in element_df.iterrows():
    node1, node2 = element['Node 1'], element['Node 2']
    
    # Check if it's a column (vertical element)
    node1_data = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_data = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Column: same x,y coordinates, different z coordinates
    if (node1_data['X (m)'] == node2_data['X (m)'] and 
        node1_data['Y (m)'] == node2_data['Y (m)'] and 
        node1_data['Z (m)'] != node2_data['Z (m)']):
        
        # Check if on X-1 grid
        if node1_data['X (m)'] == x1_coord and node2_data['X (m)'] == x1_coord:
            
            # Check if it's a first floor column (one node at first floor, other above)
            if ((node1 in x1_first_floor_nodes and node2 in x1_above_first_floor_nodes) or
                (node2 in x1_first_floor_nodes and node1 in x1_above_first_floor_nodes)):
                first_floor_x1_columns.append(element['Element ID'])

# Update elements: assign section 105 and material 1002 to first floor X-1 columns
for element_id in first_floor_x1_columns:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = 105
    element_df.loc[element_df['Element ID'] == element_id, 'Material'] = 1002

# Save updated Element.csv
element_df.to_csv('Task_46_out/Element.csv', index=False)