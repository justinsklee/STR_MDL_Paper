import pandas as pd

# Load CSV files
floor_load_df = pd.read_csv('Floor_Load.csv')
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get all nodes that define office load areas
office_nodes = set()
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.update(nodes)

# Find columns that support office loads (columns with one node in office_nodes and standing below)
supporting_columns = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get node coordinates
    node1_coord = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coord = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if element is a column (vertical - only z changes)
    is_column = (node1_coord['X (m)'] == node2_coord['X (m)'] and 
                 node1_coord['Y (m)'] == node2_coord['Y (m)'] and 
                 node1_coord['Z (m)'] != node2_coord['Z (m)'])
    
    if is_column:
        # Determine which node is higher
        if node1_coord['Z (m)'] > node2_coord['Z (m)']:
            upper_node = node1
            lower_node = node2
        else:
            upper_node = node2
            lower_node = node1
        
        # Check if upper node is in office load area (column supports from below)
        if upper_node in office_nodes:
            supporting_columns.append(element_id)

# Sort element IDs in ascending order
supporting_columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': supporting_columns})

# Save to CSV
output_df.to_csv('Task_6_out.csv', index=False)

print(f"Found {len(supporting_columns)} columns supporting office live loads")
print(output_df)