import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_25_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0-based: ground=0, second=1, third=2)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
    
    # Find all columns that have one node at third floor and another node above third floor
    third_floor_columns = []
    
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a column (vertical element - only z changes)
        is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                    node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                    node1_coords['Z (m)'] != node2_coords['Z (m)'])
        
        if is_column:
            # Check if one node is at third floor and the other is above
            node1_z = node1_coords['Z (m)']
            node2_z = node2_coords['Z (m)']
            
            if ((node1_z == third_floor_elevation and node2_z > third_floor_elevation) or
                (node2_z == third_floor_elevation and node1_z > third_floor_elevation)):
                third_floor_columns.append(row['Element ID'])
    
    # Find material number for SS400
    ss400_material = material_df[material_df['Name'] == 'SS400']['Material Number'].iloc[0]
    
    # Update material for third floor columns
    for col_id in third_floor_columns:
        element_df.loc[element_df['Element ID'] == col_id, 'Material'] = ss400_material
    
    # Save updated Element.csv
    element_df.to_csv('Task_25_out/Element.csv', index=False)
    
    print(f"Updated {len(third_floor_columns)} third floor columns to SS400 material")
else:
    print("Model does not have a third floor")