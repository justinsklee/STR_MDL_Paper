import pandas as pd
import os

# Create output folder
os.makedirs('Task_40_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Identify second floor elevation (one story above ground level)
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor is index 1 (first floor is index 0)

# Identify Y-1 grid coordinate (minimum Y coordinate)
y_coordinates = sorted(node_df['Y (m)'].unique())
y1_coordinate = y_coordinates[0]  # Y-1 is the first Y grid line

# Find nodes on second floor and Y-1 grid
second_floor_y1_nodes = node_df[
    (node_df['Z (m)'] == second_floor_z) & 
    (node_df['Y (m)'] == y1_coordinate)
]['Node ID'].tolist()

# Find nodes above second floor and Y-1 grid
above_second_floor_y1_nodes = node_df[
    (node_df['Z (m)'] > second_floor_z) & 
    (node_df['Y (m)'] == y1_coordinate)
]['Node ID'].tolist()

# Identify braces to remove: elements that have one node on second floor Y-1 and another node above
braces_to_remove = []

for _, element in element_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if it's a brace (diagonal element with change in both horizontal and vertical coordinates)
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 0
    horizontal_change = (abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 0 or 
                        abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 0)
    
    if z_change and horizontal_change:  # It's a brace
        # Check if one node is on second floor Y-1 and other is above
        condition1 = (node1 in second_floor_y1_nodes and node2 in above_second_floor_y1_nodes)
        condition2 = (node2 in second_floor_y1_nodes and node1 in above_second_floor_y1_nodes)
        
        if condition1 or condition2:
            braces_to_remove.append(element['Element ID'])

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID in ascending order
element_df_updated = element_df_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df_updated.to_csv('Task_40_out/Element.csv', index=False)

print(f"Removed {len(braces_to_remove)} braces along grid Y-1 on second floor")
if braces_to_remove:
    print(f"Removed element IDs: {braces_to_remove}")