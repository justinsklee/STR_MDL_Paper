import pandas as pd

# Load the CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_elevation = floor_elevations[0]  # Ground level (z = 0.0m)
second_floor_elevation = floor_elevations[1] if len(floor_elevations) > 1 else None

# Find first floor columns
# Columns have one node at first floor and the other node above first floor
first_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a column (vertical element - only z changes, x and y stay same)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        
        # Check if one node is at first floor and other is above
        z1 = node1_coords['Z (m)']
        z2 = node2_coords['Z (m)']
        
        if ((z1 == first_floor_elevation and z2 > first_floor_elevation) or 
            (z2 == first_floor_elevation and z1 > first_floor_elevation)):
            first_floor_columns.append(element['Element ID'])

# Sort element IDs in ascending order
first_floor_columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': first_floor_columns})

# Save to CSV
output_df.to_csv('Task_1_out.csv', index=False)