import pandas as pd
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Identify columns (vertical elements with only z-coordinate change)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only z changes, x and y stay the same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Find nodes that are connected to columns
column_nodes = set()
for _, element in element_df.iterrows():
    if element['Element ID'] in columns:
        column_nodes.add(element['Node 1'])
        column_nodes.add(element['Node 2'])

# Identify beams on the roof (elements with both nodes at roof elevation and no z-change)
roof_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam on the roof (both nodes at roof elevation and no z-change)
    if (node1['Z (m)'] == roof_elevation and 
        node2['Z (m)'] == roof_elevation and 
        node1['Z (m)'] == node2['Z (m)']):
        roof_beams.append(element['Element ID'])

# Identify sub-beams on the roof (roof beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Check if both nodes are NOT connected to columns
    if node1_id not in column_nodes and node2_id not in column_nodes:
        roof_sub_beams.append(beam_id)

# Update section for roof sub-beams to 104
for beam_id in roof_sub_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 104

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_22_out/Element.csv', index=False)