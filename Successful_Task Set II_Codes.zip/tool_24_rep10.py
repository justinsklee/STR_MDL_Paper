import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_24_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get first floor elevation (minimum z-coordinate)
first_floor_z = nodes_df['Z (m)'].min()

# Get second floor elevation (next unique z-coordinate above first floor)
unique_z_coords = sorted(nodes_df['Z (m)'].unique())
second_floor_z = unique_z_coords[1] if len(unique_z_coords) > 1 else first_floor_z + 1

# Identify first floor braces
first_floor_braces = []

for idx, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2_coords = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal element with change in x/y AND z coordinates)
    x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 1e-6
    y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 1e-6
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if it's a first floor brace (one node at first floor, other above)
        node1_at_first_floor = abs(node1_coords['Z (m)'] - first_floor_z) < 1e-6
        node2_at_first_floor = abs(node2_coords['Z (m)'] - first_floor_z) < 1e-6
        node1_above_first_floor = node1_coords['Z (m)'] > first_floor_z
        node2_above_first_floor = node2_coords['Z (m)'] > first_floor_z
        
        if (node1_at_first_floor and node2_above_first_floor) or (node2_at_first_floor and node1_above_first_floor):
            first_floor_braces.append(element['Element ID'])

# Update material for first floor braces
for element_id in first_floor_braces:
    elements_df.loc[elements_df['Element ID'] == element_id, 'Material'] = 1003

# Save updated Element.csv file
elements_df.to_csv('Task_24_out/Element.csv', index=False)

print(f"Updated {len(first_floor_braces)} first floor braces to material 1003")
print(f"First floor brace element IDs: {first_floor_braces}")