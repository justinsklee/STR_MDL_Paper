import pandas as pd
import numpy as np

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
sections_df = pd.read_csv('Long_Section.csv')

# Find the highest floor elevation (roof level)
max_z = nodes_df['Z (m)'].max()

# Find X-coordinate for grid X-1 (first X grid line)
x_coords = sorted(nodes_df['X (m)'].unique())
x1_coord = x_coords[0]  # First X grid coordinate

# Filter beams on the roof level
roof_nodes = nodes_df[nodes_df['Z (m)'] == max_z]['Node ID'].tolist()

# Identify beams (horizontal elements with no change in Z coordinates)
beams = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in Z coordinate)
    if node1['Z (m)'] == node2['Z (m)']:
        # Check if it's on the roof level
        if node1['Z (m)'] == max_z:
            # Check if both nodes are on grid X-1 (same X coordinate as X-1)
            if node1['X (m)'] == x1_coord and node2['X (m)'] == x1_coord:
                # Calculate beam length
                length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                               (node2['Y (m)'] - node1['Y (m)'])**2 + 
                               (node2['Z (m)'] - node1['Z (m)'])**2)
                
                # Check if length > 1.3m
                if length > 1.3:
                    section_name = sections_df[sections_df['Section Number'] == element['Section']]['Section Name'].iloc[0]
                    beams.append({
                        'Element ID': element['Element ID'],
                        'Section Name': section_name
                    })

# Create output dataframe and sort by Element ID
output_df = pd.DataFrame(beams)
if not output_df.empty:
    output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_49_out.csv', index=False)