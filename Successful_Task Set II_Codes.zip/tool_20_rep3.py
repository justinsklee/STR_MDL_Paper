import pandas as pd
import numpy as np
import math

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Identify first floor elevation (ground level)
first_floor_z = 0.0

# Find all columns that have one node at first floor and the other node above
first_floor_columns = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical element)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is at first floor and the other is above
        node1_z = node1['Z (m)']
        node2_z = node2['Z (m)']
        
        if ((node1_z == first_floor_z and node2_z > first_floor_z) or
            (node2_z == first_floor_z and node1_z > first_floor_z)):
            first_floor_columns.append(element_id)

# Calculate total weight
total_weight = 0
steel_density = 7850  # kg/m^3

for column_id in first_floor_columns:
    element = element_df[element_df['Element ID'] == column_id].iloc[0]
    section_num = element['Section']
    
    # Get section properties
    section = section_df[section_df['Section Number'] == section_num].iloc[0]
    area = section['Area']  # m^2
    
    # Get column length
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    length = abs(node2['Z (m)'] - node1['Z (m)'])  # m
    
    # Calculate weight
    volume = area * length  # m^3
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
output_data = {
    'Total Weight (kg)': [total_weight_rounded]
}

output_df = pd.DataFrame(output_data)
output_df.to_csv('Task_20_out.csv', index=False)

print(f"Total weight of first floor columns: {total_weight_rounded} kg")