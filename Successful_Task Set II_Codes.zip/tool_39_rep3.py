import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_39_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Identify first floor elevation (ground level)
first_floor_z = 0.0

# Identify X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify braces on first floor along grid X-1
# Braces are diagonal elements: change in both (x or y) AND z coordinates
# First floor braces have one node at first floor and other node above first floor
# Grid X-1 means both nodes share the same x-coordinate as X-1 grid

elements_to_remove = []

for idx, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace
    # Brace: change in z AND (x or y)
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if brace is on first floor (one node at first floor, other above)
        node1_first_floor = abs(node1['Z (m)'] - first_floor_z) < 1e-6
        node2_first_floor = abs(node2['Z (m)'] - first_floor_z) < 1e-6
        node1_above_first = node1['Z (m)'] > first_floor_z
        node2_above_first = node2['Z (m)'] > first_floor_z
        
        is_first_floor_brace = (node1_first_floor and node2_above_first) or (node2_first_floor and node1_above_first)
        
        # Check if brace is on grid X-1 (both nodes have same x-coordinate as X-1)
        node1_on_x1 = abs(node1['X (m)'] - x1_coord) < 1e-6
        node2_on_x1 = abs(node2['X (m)'] - x1_coord) < 1e-6
        
        is_on_x1_grid = node1_on_x1 and node2_on_x1
        
        if is_first_floor_brace and is_on_x1_grid:
            elements_to_remove.append(element['Element ID'])

# Remove identified braces
updated_element_df = element_df[~element_df['Element ID'].isin(elements_to_remove)]

# Save updated Element.csv file
updated_element_df.to_csv('Task_39_out/Element.csv', index=False)

print(f"Removed {len(elements_to_remove)} braces on first floor along grid X-1")
if elements_to_remove:
    print(f"Removed element IDs: {elements_to_remove}")