import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_46_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find the X-coordinate for grid X-1 (minimum X-coordinate)
x_coords = sorted(node_df['X (m)'].unique())
x1_coord = x_coords[0]  # X-1 grid coordinate

# Find first floor elevation (minimum Z-coordinate)
z_coords = sorted(node_df['Z (m)'].unique())
first_floor_z = z_coords[0]  # First floor elevation
second_floor_z = z_coords[1]  # Second floor elevation (one level above first floor)

# Identify columns: vertical elements with change only in Z coordinates
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element)
    x_diff = abs(node1['X (m)'] - node2['X (m)'])
    y_diff = abs(node1['Y (m)'] - node2['Y (m)'])
    z_diff = abs(node1['Z (m)'] - node2['Z (m)'])
    
    if x_diff == 0 and y_diff == 0 and z_diff > 0:
        columns.append(element['Element ID'])

# Find first floor columns along grid X-1 with section 105
first_floor_x1_columns = []
for element_id in columns:
    element = element_df[element_df['Element ID'] == element_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if column is on grid X-1 and has one node at first floor with other above
    node1_on_x1 = abs(node1['X (m)'] - x1_coord) < 1e-6
    node2_on_x1 = abs(node2['X (m)'] - x1_coord) < 1e-6
    
    node1_at_first_floor = abs(node1['Z (m)'] - first_floor_z) < 1e-6
    node2_at_first_floor = abs(node2['Z (m)'] - first_floor_z) < 1e-6
    
    # Column should have one node at first floor and other above
    first_floor_column = (node1_at_first_floor and node2['Z (m)'] > first_floor_z) or \
                        (node2_at_first_floor and node1['Z (m)'] > first_floor_z)
    
    # Check if column is on X-1 grid, at first floor, and has section 105
    if node1_on_x1 and node2_on_x1 and first_floor_column and element['Section'] == 105:
        first_floor_x1_columns.append(element_id)

# Update material for identified columns
for element_id in first_floor_x1_columns:
    element_df.loc[element_df['Element ID'] == element_id, 'Material'] = 1002

# Save updated Element.csv
element_df.to_csv('Task_46_out/Element.csv', index=False)

print(f"Updated {len(first_floor_x1_columns)} first floor columns along grid X-1 with section 105 to material 1002")
print(f"Updated elements: {first_floor_x1_columns}")