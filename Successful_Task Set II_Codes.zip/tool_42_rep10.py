import pandas as pd
import os

# Create output folder
os.makedirs('Task_42_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof level (highest z-coordinate)
roof_level = node_df['Z (m)'].max()

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    z1, z2 = node1['Z (m)'], node2['Z (m)']
    x1, x2 = node1['X (m)'], node2['X (m)']
    y1, y2 = node1['Y (m)'], node2['Y (m)']
    
    # Columns: change in ONLY 'z' coordinates
    if z1 != z2 and x1 == x2 and y1 == y2:
        return 'column'
    # Beams: NO change in 'z' coordinates
    elif z1 == z2:
        return 'beam'
    # Braces: change in ('x' or 'y') coordinates AND 'z' coordinates
    elif (x1 != x2 or y1 != y2) and z1 != z2:
        return 'brace'
    else:
        return 'other'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find roof beams (beams at roof level)
roof_beams = []
for _, row in element_df.iterrows():
    if row['element_type'] == 'beam':
        node1_id = row['Node 1']
        node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
        if node1_z == roof_level:
            roof_beams.append(row['Element ID'])

# Find all braces
braces = element_df[element_df['element_type'] == 'brace']['Element ID'].tolist()

# Get all nodes connected to braces
brace_nodes = set()
for brace_id in braces:
    brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
    brace_nodes.add(brace_row['Node 1'])
    brace_nodes.add(brace_row['Node 2'])

# Find roof beams not connected to any braces
roof_beams_no_braces = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_nodes = {beam_row['Node 1'], beam_row['Node 2']}
    
    # Check if beam shares any nodes with braces
    if not beam_nodes.intersection(brace_nodes):
        roof_beams_no_braces.append(beam_id)

# Update section to 104 for roof beams not connected to braces
element_df.loc[element_df['Element ID'].isin(roof_beams_no_braces), 'Section'] = 104

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Save updated Element.csv
element_df.to_csv('Task_42_out/Element.csv', index=False)

print(f"Roof beams not connected to braces: {roof_beams_no_braces}")
print(f"Updated {len(roof_beams_no_braces)} beams to section 104")