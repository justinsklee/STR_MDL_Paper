import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')
node_df = pd.read_csv('Node.csv')

# Identify columns (vertical elements)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (only z coordinates change)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams (horizontal elements)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is horizontal (no change in z coordinates)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Find nodes that are connected to columns
column_connected_nodes = set()
for column_id in columns:
    element = element_df[element_df['Element ID'] == column_id].iloc[0]
    column_connected_nodes.add(element['Node 1'])
    column_connected_nodes.add(element['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Check if both nodes are NOT connected to columns
    if node1_id not in column_connected_nodes and node2_id not in column_connected_nodes:
        sub_beams.append(beam_id)

# Find sub-beams that are NOT beam-end-released
# Beam-end-release means both 'i-end release' and 'j-end release' are '11'
released_elements = set()
for _, release in beam_end_release_df.iterrows():
    if release['i-end release'] == 11 and release['j-end release'] == 11:
        released_elements.add(release['Element ID'])

# Get sub-beams that are NOT released
non_released_sub_beams = [beam_id for beam_id in sub_beams if beam_id not in released_elements]

# Sort in ascending order
non_released_sub_beams.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': non_released_sub_beams})

# Save to CSV
output_df.to_csv('Task_10_out.csv', index=False)