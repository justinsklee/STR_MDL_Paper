import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_23_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find the section number for H 100x100x6/8
target_section = section_df[section_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_z = floor_elevations[0]  # Ground level (z = 0.0)
second_floor_z = floor_elevations[1]  # First floor above ground

# Identify first floor braces
first_floor_braces = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    node1_coords = (node1['X (m)'], node1['Y (m)'], node1['Z (m)'])
    node2_coords = (node2['X (m)'], node2['Y (m)'], node2['Z (m)'])
    
    # Check if it's a brace (diagonal element)
    x_change = node1_coords[0] != node2_coords[0]
    y_change = node1_coords[1] != node2_coords[1]
    z_change = node1_coords[2] != node2_coords[2]
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if it's a first floor brace
        # One node at first floor, other node above first floor
        node_elevations = [node1_coords[2], node2_coords[2]]
        
        if (first_floor_z in node_elevations and 
            any(z > first_floor_z for z in node_elevations)):
            first_floor_braces.append(row['Element ID'])

# Update section for first floor braces
for element_id in first_floor_braces:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = target_section

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)