import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')
node_df = pd.read_csv('Node.csv')

# Identify columns (vertical elements - change only in z coordinates)
columns = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams (horizontal elements - no change in z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Find nodes that are connected to columns
column_nodes = set()
for _, element in element_df.iterrows():
    if element['Element ID'] in columns:
        column_nodes.add(element['Node 1'])
        column_nodes.add(element['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    beam_element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1 = beam_element['Node 1']
    node2 = beam_element['Node 2']
    
    # Check if beam is connected to column nodes
    if node1 not in column_nodes and node2 not in column_nodes:
        sub_beams.append(beam_id)

# Get beam-end-released elements
released_elements = set(beam_end_release_df['Element ID'].tolist())

# Find sub-beams that are NOT beam-end-released
non_released_sub_beams = []
for sub_beam in sub_beams:
    if sub_beam not in released_elements:
        non_released_sub_beams.append(sub_beam)

# Sort in ascending order
non_released_sub_beams.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': non_released_sub_beams})

# Save to CSV
output_df.to_csv('Task_10_out.csv', index=False)

print(f"Found {len(non_released_sub_beams)} sub-beams that are not beam-end-released")
print(output_df)