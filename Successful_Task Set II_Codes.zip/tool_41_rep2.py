import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
roof_elevation = max(floor_elevations)

# Filter roof beams with section 101
roof_beams = element_df[
    (element_df['Section'] == 101)
].copy()

# Function to check if element is a beam (no change in Z coordinates)
def is_beam(row):
    node1_z = node_df[node_df['Node ID'] == row['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == row['Node 2']]['Z (m)'].iloc[0]
    return node1_z == node2_z

# Function to check if element is at roof level
def is_at_roof(row):
    node1_z = node_df[node_df['Node ID'] == row['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == row['Node 2']]['Z (m)'].iloc[0]
    return node1_z == roof_elevation and node2_z == roof_elevation

# Filter for roof beams only
roof_beams = roof_beams[roof_beams.apply(is_beam, axis=1) & roof_beams.apply(is_at_roof, axis=1)]

# Calculate length of each beam
def calculate_length(row):
    node1 = node_df[node_df['Node ID'] == row['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == row['Node 2']].iloc[0]
    
    dx = node2['X (m)'] - node1['X (m)']
    dy = node2['Y (m)'] - node1['Y (m)']
    dz = node2['Z (m)'] - node1['Z (m)']
    
    return np.sqrt(dx**2 + dy**2 + dz**2)

roof_beams['Length'] = roof_beams.apply(calculate_length, axis=1)

# Get section properties for section 101
section_101 = section_df[section_df['Section Number'] == 101]
area = section_101['Area'].iloc[0]  # m²

# Calculate total volume
total_length = roof_beams['Length'].sum()
total_volume = total_length * area  # m³

# Calculate weight
density = 7850  # kg/m³
total_weight = total_volume * density  # kg

# Round up to nearest 10 kg
total_weight_rounded = np.ceil(total_weight / 10) * 10

# Create output dataframe
output_df = pd.DataFrame({
    'Total Weight (kg)': [int(total_weight_rounded)]
})

# Save to CSV
output_df.to_csv('Task_41_out.csv', index=False)