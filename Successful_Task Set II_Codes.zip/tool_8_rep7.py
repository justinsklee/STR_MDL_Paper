import pandas as pd
import numpy as np

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Create a dictionary for node coordinates
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Classify elements
columns = []
beams = []
braces = []

for _, row in element_df.iterrows():
    element_id = row['Element ID']
    node1 = row['Node 1']
    node2 = row['Node 2']
    
    coord1 = node_coords[node1]
    coord2 = node_coords[node2]
    
    x_change = abs(coord1[0] - coord2[0]) > 1e-6
    y_change = abs(coord1[1] - coord2[1]) > 1e-6
    z_change = abs(coord1[2] - coord2[2]) > 1e-6
    
    if z_change and not x_change and not y_change:
        columns.append(element_id)
    elif not z_change:
        beams.append(element_id)
    elif (x_change or y_change) and z_change:
        braces.append(element_id)

# Get supported nodes
supported_nodes = set(support_df['Node'].tolist())

# Find bracing elements connected to supported nodes
bracing_at_supports = []
for brace_id in braces:
    brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
    node1 = brace_row['Node 1']
    node2 = brace_row['Node 2']
    
    if node1 in supported_nodes or node2 in supported_nodes:
        bracing_at_supports.append(brace_id)

# Find columns that share supports with bracing elements
columns_sharing_supports = []
for col_id in columns:
    col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
    node1 = col_row['Node 1']
    node2 = col_row['Node 2']
    
    # Check if column is connected to any supported node where bracing is also connected
    col_supported_nodes = []
    if node1 in supported_nodes:
        col_supported_nodes.append(node1)
    if node2 in supported_nodes:
        col_supported_nodes.append(node2)
    
    # Check if any bracing element shares the same supported nodes
    for brace_id in bracing_at_supports:
        brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
        brace_node1 = brace_row['Node 1']
        brace_node2 = brace_row['Node 2']
        
        brace_supported_nodes = []
        if brace_node1 in supported_nodes:
            brace_supported_nodes.append(brace_node1)
        if brace_node2 in supported_nodes:
            brace_supported_nodes.append(brace_node2)
        
        # Check if there's any common supported node
        if any(node in brace_supported_nodes for node in col_supported_nodes):
            if col_id not in columns_sharing_supports:
                columns_sharing_supports.append(col_id)

# Sort the column numbers in ascending order
columns_sharing_supports.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': columns_sharing_supports})

# Save to CSV
output_df.to_csv('Task_8_out.csv', index=False)