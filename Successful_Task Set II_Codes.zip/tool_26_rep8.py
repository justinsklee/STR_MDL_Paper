import pandas as pd
import os

# Create output folder
output_folder = 'Task_26_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find second floor elevation (one floor above ground level z=0.0)
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor is index 1 (ground is index 0)

# Find SHN355 material number
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Identify beams on second floor
# Beams are horizontal elements (no change in z coordinates between nodes)
# and lie on the same elevation as the floor
second_floor_beams = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (horizontal element) on second floor
    if node1_z == node2_z == second_floor_z:
        second_floor_beams.append(row['Element ID'])

# Update material for second floor beams
element_df.loc[element_df['Element ID'].isin(second_floor_beams), 'Material'] = shn355_material

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Updated {len(second_floor_beams)} second floor beams to SHN355 material")
print(f"Second floor beam elements: {second_floor_beams}")