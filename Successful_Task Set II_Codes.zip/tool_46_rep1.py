import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_46_out'
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify first floor columns along grid X-1
# Columns are vertical elements (only z changes, x and y stay same)
# For first floor columns: one node at first floor, other node above first floor
# Along X-1 grid: both nodes have same x-coordinate as X-1 grid

first_floor_x1_columns = []

for idx, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on X-1 grid
    if (abs(node1['X (m)'] - x1_coord) < 1e-6 and 
        abs(node2['X (m)'] - x1_coord) < 1e-6):
        
        # Check if it's a column (vertical element)
        if (abs(node1['X (m)'] - node2['X (m)']) < 1e-6 and 
            abs(node1['Y (m)'] - node2['Y (m)']) < 1e-6 and
            abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6):
            
            # Check if it's a first floor column
            # One node at first floor, other node above first floor
            node1_z = node1['Z (m)']
            node2_z = node2['Z (m)']
            
            if ((abs(node1_z - first_floor_z) < 1e-6 and node2_z > first_floor_z) or
                (abs(node2_z - first_floor_z) < 1e-6 and node1_z > first_floor_z)):
                
                first_floor_x1_columns.append(element['Element ID'])

# Update section number to 105 and material to 1002 for identified columns
for element_id in first_floor_x1_columns:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = 105
    element_df.loc[element_df['Element ID'] == element_id, 'Material'] = 1002

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Updated {len(first_floor_x1_columns)} first floor columns along grid X-1")
print(f"Column Element IDs: {first_floor_x1_columns}")