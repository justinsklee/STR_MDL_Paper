import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_48_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (z = 0.0)
first_floor_z = 0.0

# Get Y-1 grid coordinate (minimum y coordinate)
y1_coord = node_df['Y (m)'].min()

# Find braces on first floor along grid Y-1
# Braces are diagonal elements: change in (x or y) AND z coordinates
# For first floor braces: one node at first floor, other node above first floor
# For grid Y-1: both nodes have same Y coordinate as Y-1 grid

updated_elements = []

for idx, row in element_df.iterrows():
    element_id = row['Element ID']
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    # Check if brace is on first floor (one node at first floor, other above)
    node1_first_floor = abs(node1['Z (m)'] - first_floor_z) < 1e-6
    node2_first_floor = abs(node2['Z (m)'] - first_floor_z) < 1e-6
    node1_above_first = node1['Z (m)'] > first_floor_z
    node2_above_first = node2['Z (m)'] > first_floor_z
    
    is_first_floor_brace = (node1_first_floor and node2_above_first) or (node2_first_floor and node1_above_first)
    
    # Check if both nodes are on grid Y-1
    node1_on_y1 = abs(node1['Y (m)'] - y1_coord) < 1e-6
    node2_on_y1 = abs(node2['Y (m)'] - y1_coord) < 1e-6
    is_on_y1_grid = node1_on_y1 and node2_on_y1
    
    # Check if current section is 101
    current_section = row['Section']
    
    # Update section if all conditions are met
    if is_brace and is_first_floor_brace and is_on_y1_grid and current_section == 101:
        row['Section'] = 103
    
    updated_elements.append(row)

# Create updated dataframe
updated_element_df = pd.DataFrame(updated_elements)

# Sort by Element ID
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_48_out/Element.csv', index=False)