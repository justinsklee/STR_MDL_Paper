import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Get all unique z coordinates and sort them to find floor elevations
unique_z = sorted(node_df['Z (m)'].unique())
first_floor_z = unique_z[0]  # Ground level
second_floor_z = unique_z[1] if len(unique_z) > 1 else first_floor_z + 1

# Find first floor columns
# Columns are vertical elements with one node at first floor and other node above first floor
first_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    x_same = node1['X (m)'] == node2['X (m)']
    y_same = node1['Y (m)'] == node2['Y (m)']
    z_different = node1['Z (m)'] != node2['Z (m)']
    
    if x_same and y_same and z_different:
        # Check if one node is at first floor and other is above
        z1, z2 = node1['Z (m)'], node2['Z (m)']
        if (z1 == first_floor_z and z2 > first_floor_z) or (z2 == first_floor_z and z1 > first_floor_z):
            first_floor_columns.append(element['Element ID'])

# Sort element IDs in ascending order
first_floor_columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': first_floor_columns})

# Save to CSV
output_df.to_csv('Task_1_out.csv', index=False)