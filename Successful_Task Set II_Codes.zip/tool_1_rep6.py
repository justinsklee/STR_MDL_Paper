import pandas as pd

# Load CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Get all unique z coordinates to find the next floor elevation
z_coords = sorted(nodes_df['Z (m)'].unique())
second_floor_z = None
for z in z_coords:
    if z > first_floor_z:
        second_floor_z = z
        break

# Find first floor columns
# Columns are vertical elements with one node at first floor and one node above first floor
first_floor_columns = []

for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (same x,y coordinates, different z)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is at first floor and the other is above
        z1, z2 = node1['Z (m)'], node2['Z (m)']
        if ((z1 == first_floor_z and z2 > first_floor_z) or 
            (z2 == first_floor_z and z1 > first_floor_z)):
            first_floor_columns.append(element['Element ID'])

# Sort element IDs in ascending order
first_floor_columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': first_floor_columns})

# Save to CSV
output_df.to_csv('Task_1_out.csv', index=False)