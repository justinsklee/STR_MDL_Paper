import pandas as pd
import numpy as np
import math

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find all nodes at first floor level
first_floor_nodes = node_df[node_df['Z (m)'] == first_floor_z]['Node ID'].tolist()

# Find columns: elements that are vertical (change only in z-coordinate)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    # Column: only change in z-coordinate, no change in x and y
    if dx == 0 and dy == 0 and dz > 0:
        columns.append(element)

# Filter first floor columns: columns with one node at first floor and other node above
first_floor_columns = []
for element in columns:
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if one node is at first floor and other is above
    if ((node1['Z (m)'] == first_floor_z and node2['Z (m)'] > first_floor_z) or 
        (node2['Z (m)'] == first_floor_z and node1['Z (m)'] > first_floor_z)):
        first_floor_columns.append(element)

# Calculate total weight
total_weight = 0
steel_density = 7850  # kg/m^3

for element in first_floor_columns:
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    section_num = element['Section']
    
    # Get nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Calculate length
    length = abs(node2['Z (m)'] - node1['Z (m)'])
    
    # Get cross-sectional area
    section_info = section_df[section_df['Section Number'] == section_num].iloc[0]
    area = section_info['Area']  # in m^2
    
    # Calculate weight
    volume = area * length  # m^3
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
output_data = {
    'Total Weight of First Floor Columns (kg)': [total_weight_rounded]
}
output_df = pd.DataFrame(output_data)
output_df.to_csv('Task_20_out.csv', index=False)