import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find X-1 grid coordinate (minimum X coordinate)
x1_coord = node_df['X (m)'].min()

# Create node coordinate lookup
node_coords = node_df.set_index('Node ID')[['X (m)', 'Y (m)', 'Z (m)']]

# Function to classify elements
def classify_element(row):
    node1_coords = node_coords.loc[row['Node 1']]
    node2_coords = node_coords.loc[row['Node 2']]
    
    # Check coordinate changes
    x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 1e-6
    y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 1e-6
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
    
    # Classify element
    if z_change and not x_change and not y_change:
        return 'Column'
    elif not z_change:
        return 'Beam'
    elif z_change and (x_change or y_change):
        return 'Brace'
    else:
        return 'Unknown'

# Add element classification
element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Find braces along grid X-1
braces_x1 = []

for _, row in element_df.iterrows():
    if row['Element_Type'] == 'Brace':
        node1_coords = node_coords.loc[row['Node 1']]
        node2_coords = node_coords.loc[row['Node 2']]
        
        # Check if both nodes are on X-1 grid
        if (abs(node1_coords['X (m)'] - x1_coord) < 1e-6 and 
            abs(node2_coords['X (m)'] - x1_coord) < 1e-6):
            braces_x1.append(row['Element ID'])

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(braces_x1)})

# Save to CSV
output_df.to_csv('Task_3_out.csv', index=False)