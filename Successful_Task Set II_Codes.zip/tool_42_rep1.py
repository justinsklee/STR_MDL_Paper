import pandas as pd
import os

# Create output folder
os.makedirs('Task_42_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    z1, z2 = node1['Z (m)'], node2['Z (m)']
    x1, x2 = node1['X (m)'], node2['X (m)']
    y1, y2 = node1['Y (m)'], node2['Y (m)']
    
    # Column: vertical elements (only z changes)
    if z1 != z2 and x1 == x2 and y1 == y2:
        return 'column'
    # Beam: horizontal elements (no z change)
    elif z1 == z2:
        return 'beam'
    # Brace: diagonal elements (z changes and x or y changes)
    elif z1 != z2 and (x1 != x2 or y1 != y2):
        return 'brace'
    else:
        return 'unknown'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find beams on the roof
roof_beams = element_df[
    (element_df['element_type'] == 'beam') &
    (element_df.apply(lambda row: node_df[node_df['Node ID'] == row['Node 1']]['Z (m)'].iloc[0] == roof_elevation, axis=1))
]

# Find all braces
braces = element_df[element_df['element_type'] == 'brace']

# Get nodes connected to braces
brace_nodes = set()
for _, brace in braces.iterrows():
    brace_nodes.add(brace['Node 1'])
    brace_nodes.add(brace['Node 2'])

# Find roof beams not connected to any braces
roof_beams_not_connected_to_braces = []
for _, beam in roof_beams.iterrows():
    beam_node1 = beam['Node 1']
    beam_node2 = beam['Node 2']
    
    # Check if neither node of the beam is connected to any brace
    if beam_node1 not in brace_nodes and beam_node2 not in brace_nodes:
        roof_beams_not_connected_to_braces.append(beam['Element ID'])

# Update section to 104 for these beams
element_df.loc[element_df['Element ID'].isin(roof_beams_not_connected_to_braces), 'Section'] = 104

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Save updated Element.csv
element_df.to_csv('Task_42_out/Element.csv', index=False)

print(f"Updated {len(roof_beams_not_connected_to_braces)} roof beams not connected to braces with section 104")
print(f"Element IDs updated: {roof_beams_not_connected_to_braces}")