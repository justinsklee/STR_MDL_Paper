import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_44_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the top floor elevation (maximum z-coordinate)
top_floor_elevation = node_df['Z (m)'].max()

# Filter beams on the top floor
# Beams are elements where both nodes have the same z-coordinate (horizontal elements)
beams_on_top_floor = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates of both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (same z-coordinate for both nodes)
    if node1_coords['Z (m)'] == node2_coords['Z (m)']:
        # Check if it's on the top floor
        if node1_coords['Z (m)'] == top_floor_elevation:
            # Calculate beam length
            length = np.sqrt((node2_coords['X (m)'] - node1_coords['X (m)'])**2 + 
                           (node2_coords['Y (m)'] - node1_coords['Y (m)'])**2)
            
            # Check if length > 1.65 meters
            if length > 1.65:
                beams_on_top_floor.append(row['Element ID'])

# Update section numbers for qualifying beams
for element_id in beams_on_top_floor:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = 105

# Save updated Element.csv file
element_df.to_csv('Task_44_out/Element.csv', index=False)