import pandas as pd

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Third floor is at index 2 (0: ground, 1: second, 2: third)
third_floor_elevation = floor_elevations[2]

# Find beams on third floor (beams have same Z coordinate for both nodes)
third_floor_beams = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (same Z coordinate) on third floor
    if node1['Z (m)'] == node2['Z (m)'] == third_floor_elevation:
        third_floor_beams.append(element['Element ID'])

# Find columns on third floor (vertical elements with one node on third floor)
third_floor_columns = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (different Z coordinates, same X and Y)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        # Check if one node is on third floor and the other is above
        if ((node1['Z (m)'] == third_floor_elevation and node2['Z (m)'] > third_floor_elevation) or
            (node2['Z (m)'] == third_floor_elevation and node1['Z (m)'] > third_floor_elevation)):
            third_floor_columns.append(element['Element ID'])

# Find nodes that are connected to columns on third floor
column_connected_nodes = set()
for col_id in third_floor_columns:
    element = elements_df[elements_df['Element ID'] == col_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Add the node that's on the third floor
    if node1['Z (m)'] == third_floor_elevation:
        column_connected_nodes.add(node1_id)
    if node2['Z (m)'] == third_floor_elevation:
        column_connected_nodes.add(node2_id)

# Find sub-beams (beams not directly connected to columns)
third_floor_sub_beams = []
for beam_id in third_floor_beams:
    element = elements_df[elements_df['Element ID'] == beam_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Check if neither node is connected to a column
    if node1_id not in column_connected_nodes and node2_id not in column_connected_nodes:
        third_floor_sub_beams.append(beam_id)

# Create output data
output_data = []
for beam_id in sorted(third_floor_sub_beams):
    # Check if beam has release in beam_end_release_df
    release_row = beam_end_release_df[beam_end_release_df['Element ID'] == beam_id]
    
    if not release_row.empty:
        i_release = release_row.iloc[0]['i-end release']
        j_release = release_row.iloc[0]['j-end release']
        
        # Convert release codes to 0/1 (0 for released, 1 for fixed)
        # '11' means released, '10' means fixed
        i_status = 0 if str(i_release) == '11' else 1
        j_status = 0 if str(j_release) == '11' else 1
    else:
        # No release specified means fixed
        i_status = 1
        j_status = 1
    
    output_data.append([beam_id, i_status, j_status])

# Create DataFrame and save to CSV
output_df = pd.DataFrame(output_data, columns=['Element Number', 'i-end Status', 'j-end Status'])
output_df.to_csv('Task_31_out.csv', index=False)