import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_23_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
sections_df = pd.read_csv('Long_Section.csv')

# Find the first floor elevation (minimum z-coordinate)
first_floor_z = nodes_df['Z (m)'].min()

# Find the second floor elevation (next unique z-coordinate above first floor)
unique_z_coords = sorted(nodes_df['Z (m)'].unique())
second_floor_z = unique_z_coords[1] if len(unique_z_coords) > 1 else first_floor_z + 1

# Find section number for H 100x100x6/8
target_section = sections_df[sections_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Identify first floor braces
first_floor_braces = []

for idx, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates of both nodes
    node1_coords = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2_coords = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    z1 = node1_coords['Z (m)']
    z2 = node2_coords['Z (m)']
    x1 = node1_coords['X (m)']
    x2 = node2_coords['X (m)']
    y1 = node1_coords['Y (m)']
    y2 = node2_coords['Y (m)']
    
    # Check if element is a brace (diagonal: changes in x/y AND z coordinates)
    has_x_change = abs(x1 - x2) > 1e-6
    has_y_change = abs(y1 - y2) > 1e-6
    has_z_change = abs(z1 - z2) > 1e-6
    
    is_brace = (has_x_change or has_y_change) and has_z_change
    
    # Check if it's a first floor brace (one node at first floor, other above)
    if is_brace:
        node_at_first_floor = (abs(z1 - first_floor_z) < 1e-6) or (abs(z2 - first_floor_z) < 1e-6)
        node_above_first_floor = (z1 > first_floor_z + 1e-6) or (z2 > first_floor_z + 1e-6)
        
        if node_at_first_floor and node_above_first_floor:
            first_floor_braces.append(element['Element ID'])

# Update section for first floor braces
for element_id in first_floor_braces:
    elements_df.loc[elements_df['Element ID'] == element_id, 'Section'] = target_section

# Save updated Element.csv file
elements_df.to_csv('Task_23_out/Element.csv', index=False)