import pandas as pd
import os

# Create output folder
os.makedirs('Task_34_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get all beams supporting office loads
supporting_beams = set()

for _, load in office_loads.iterrows():
    # Parse nodes from the load area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # Create beam connections for the 4 nodes (forming a rectangle)
    # Beams connect: (node1,node2), (node2,node3), (node3,node4), (node4,node1)
    beam_connections = [
        (nodes[0], nodes[1]),
        (nodes[1], nodes[2]), 
        (nodes[2], nodes[3]),
        (nodes[3], nodes[0])
    ]
    
    # Find elements that match these beam connections
    for node1, node2 in beam_connections:
        # Check both directions since beam could be defined either way
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            # Verify this is actually a beam (horizontal element - same Z coordinate)
            n1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
            n2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
            
            if n1_z == n2_z:  # This is a beam
                supporting_beams.add(element['Element ID'])

# Update section numbers for supporting beams
for beam_id in supporting_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 101

# Save updated Element.csv
element_df.to_csv('Task_34_out/Element.csv', index=False)