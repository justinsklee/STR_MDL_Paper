import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=first, 1=second, 2=third)
third_floor_elevation = floor_elevations[2]

# Find columns: elements where only Z coordinates change between nodes
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only Z changes, X and Y stay the same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is at third floor and the other is above it
        if ((node1['Z (m)'] == third_floor_elevation and node2['Z (m)'] > third_floor_elevation) or
            (node2['Z (m)'] == third_floor_elevation and node1['Z (m)'] > third_floor_elevation)):
            columns.append(element)

# Get section names
result_data = []
for column in columns:
    section_num = column['Section']
    section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
    result_data.append({
        'Element ID': column['Element ID'],
        'Section Name': section_name
    })

# Sort by Element ID
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_11_out.csv', index=False)