import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')
node_df = pd.read_csv('Node.csv')

# Identify columns (vertical elements - change only in z-coordinate)
columns = []
for _, elem in element_df.iterrows():
    node1_id = elem['Node 1']
    node2_id = elem['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(elem['Element ID'])

# Identify beams (horizontal elements - no change in z-coordinate)
beams = []
for _, elem in element_df.iterrows():
    node1_id = elem['Node 1']
    node2_id = elem['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(elem['Element ID'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    beam_elem = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_node1 = beam_elem['Node 1']
    beam_node2 = beam_elem['Node 2']
    
    # Check if beam is connected to any column
    connected_to_column = False
    for column_id in columns:
        column_elem = element_df[element_df['Element ID'] == column_id].iloc[0]
        column_node1 = column_elem['Node 1']
        column_node2 = column_elem['Node 2']
        
        if (beam_node1 in [column_node1, column_node2] or 
            beam_node2 in [column_node1, column_node2]):
            connected_to_column = True
            break
    
    if not connected_to_column:
        sub_beams.append(beam_id)

# Find sub-beams that are NOT beam-end-released
# Beam-end-release means 'i-end release' and 'j-end release' entries are '11'
released_elements = set(beam_end_release_df['Element ID'].tolist())

# Sub-beams that are NOT beam-end-released
sub_beams_not_released = [beam_id for beam_id in sub_beams if beam_id not in released_elements]

# Sort in ascending order
sub_beams_not_released.sort()

# Create output dataframe
output_df = pd.DataFrame({
    'Element ID': sub_beams_not_released
})

# Save to CSV
output_df.to_csv('Task_10_out.csv', index=False)