import pandas as pd
import os

# Create output folder
os.makedirs('Task_37_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify columns (vertical elements with same x,y coordinates but different z)
columns = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams (horizontal elements with same z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Find nodes that are connected to columns
column_nodes = set()
for col_id in columns:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    column_nodes.add(element['Node 1'])
    column_nodes.add(element['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # If neither node is connected to a column, it's a sub-beam
    if node1 not in column_nodes and node2 not in column_nodes:
        sub_beams.append(beam_id)

# Get list of beam-end-released elements
released_elements = set(beam_end_release_df['Element ID'].tolist())

# Find sub-beams that are NOT beam-end-released
sub_beams_to_remove = [beam_id for beam_id in sub_beams if beam_id not in released_elements]

# Remove these sub-beams from the element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_to_remove)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save the updated Element.csv file
updated_element_df.to_csv('Task_37_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_to_remove)} sub-beams that were not beam-end-released")
print(f"Sub-beams removed: {sub_beams_to_remove}")