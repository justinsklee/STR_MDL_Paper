import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_39_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the first floor elevation (minimum z-coordinate)
first_floor_elevation = node_df['Z (m)'].min()

# Find the X-coordinate for grid X-1 (minimum x-coordinate)
x1_coordinate = node_df['X (m)'].min()

# Identify braces on first floor along grid X-1
elements_to_remove = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (change in x/y AND z coordinates)
    x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 1e-6
    y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 1e-6
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if brace is on grid X-1 (both nodes have X-1 coordinate)
        on_x1_grid = (abs(node1_coords['X (m)'] - x1_coordinate) < 1e-6 and 
                      abs(node2_coords['X (m)'] - x1_coordinate) < 1e-6)
        
        # Check if brace is on first floor (one node at first floor, other above)
        node1_at_first_floor = abs(node1_coords['Z (m)'] - first_floor_elevation) < 1e-6
        node2_at_first_floor = abs(node2_coords['Z (m)'] - first_floor_elevation) < 1e-6
        node1_above_first_floor = node1_coords['Z (m)'] > first_floor_elevation + 1e-6
        node2_above_first_floor = node2_coords['Z (m)'] > first_floor_elevation + 1e-6
        
        on_first_floor = ((node1_at_first_floor and node2_above_first_floor) or 
                         (node2_at_first_floor and node1_above_first_floor))
        
        if on_x1_grid and on_first_floor:
            elements_to_remove.append(row['Element ID'])

# Remove identified braces
updated_element_df = element_df[~element_df['Element ID'].isin(elements_to_remove)].copy()

# Save updated Element.csv file
updated_element_df.to_csv('Task_39_out/Element.csv', index=False)

print(f"Removed {len(elements_to_remove)} braces on first floor along grid X-1")
print(f"Removed element IDs: {elements_to_remove}")