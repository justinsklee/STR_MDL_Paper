import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
third_floor_elevation = floor_elevations[2]

# Find all beams on third floor (beams have same Z coordinate for both nodes)
third_floor_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam on third floor
    if node1_z == node2_z == third_floor_elevation:
        third_floor_beams.append(element['Element ID'])

# Find columns (vertical elements with nodes on third floor)
columns_on_third_floor = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_data = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_data = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element)
    if (node1_data['X (m)'] == node2_data['X (m)'] and 
        node1_data['Y (m)'] == node2_data['Y (m)'] and 
        node1_data['Z (m)'] != node2_data['Z (m)']):
        
        # Check if one node is on third floor
        if node1_data['Z (m)'] == third_floor_elevation or node2_data['Z (m)'] == third_floor_elevation:
            columns_on_third_floor.append(element['Element ID'])

# Find column nodes on third floor
column_nodes_on_third_floor = set()
for col_id in columns_on_third_floor:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    if node1_z == third_floor_elevation:
        column_nodes_on_third_floor.add(node1_id)
    if node2_z == third_floor_elevation:
        column_nodes_on_third_floor.add(node2_id)

# Find sub-beams (beams not directly connected to columns)
third_floor_sub_beams = []
for beam_id in third_floor_beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Check if beam is connected to any column node
    if node1_id not in column_nodes_on_third_floor and node2_id not in column_nodes_on_third_floor:
        third_floor_sub_beams.append(beam_id)

# Create output data
output_data = []
for beam_id in sorted(third_floor_sub_beams):
    # Check if beam has end releases
    release_info = beam_end_release_df[beam_end_release_df['Element ID'] == beam_id]
    
    if not release_info.empty:
        i_release = release_info.iloc[0]['i-end release']
        j_release = release_info.iloc[0]['j-end release']
        
        # Convert release codes to 0/1 (0 for released, 1 for fixed)
        # Release code '10' means moment release, '11' means full release
        i_status = 0 if str(i_release) in ['10', '11'] else 1
        j_status = 0 if str(j_release) in ['10', '11'] else 1
    else:
        # No release means fully fixed
        i_status = 1
        j_status = 1
    
    output_data.append([beam_id, i_status, j_status])

# Create DataFrame and save to CSV
output_df = pd.DataFrame(output_data, columns=['Element Number', 'i-end (0=released, 1=fixed)', 'j-end (0=released, 1=fixed)'])
output_df.to_csv('Task_31_out.csv', index=False)

print("Task_31_out.csv has been created with third floor sub-beam end release status.")