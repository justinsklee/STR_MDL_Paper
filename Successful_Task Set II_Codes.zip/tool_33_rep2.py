import pandas as pd
import os

# Create output folder
os.makedirs('Task_33_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Find X-3 grid coordinate (third unique X coordinate)
unique_x_coords = sorted(nodes_df['X (m)'].unique())
x3_coord = unique_x_coords[2]  # X-3 is the third X coordinate

# Find braces along grid X-3
# Braces are diagonal elements: change in both (x or y) AND z coordinates
braces_on_x3 = []

for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on X-3 grid
    if node1['X (m)'] == x3_coord and node2['X (m)'] == x3_coord:
        # Check if it's a brace (diagonal element)
        x_change = abs(node1['X (m)'] - node2['X (m)'])
        y_change = abs(node1['Y (m)'] - node2['Y (m)'])
        z_change = abs(node1['Z (m)'] - node2['Z (m)'])
        
        # Brace: change in z AND (x or y)
        if z_change > 0 and (x_change > 0 or y_change > 0):
            braces_on_x3.append(element['Element ID'])

# Remove beam-end-release for braces along grid X-3
updated_beam_end_release_df = beam_end_release_df[~beam_end_release_df['Element ID'].isin(braces_on_x3)]

# Sort by Element ID in ascending order
updated_beam_end_release_df = updated_beam_end_release_df.sort_values('Element ID').reset_index(drop=True)

# Save updated file
updated_beam_end_release_df.to_csv('Task_33_out/Beam_end_release.csv', index=False)

print(f"Removed beam-end-release for braces on grid X-3: {braces_on_x3}")