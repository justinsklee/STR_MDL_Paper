import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_39_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Find first floor elevation (minimum z-coordinate)
first_floor_z = nodes_df['Z (m)'].min()

# Find X-1 grid coordinate (minimum x-coordinate)
x1_grid_coord = nodes_df['X (m)'].min()

# Find second floor elevation (second lowest unique z-coordinate)
unique_z_coords = sorted(nodes_df['Z (m)'].unique())
second_floor_z = unique_z_coords[1] if len(unique_z_coords) > 1 else first_floor_z + 1

# Identify braces on first floor along grid X-1
elements_to_remove = []

for idx, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on X-1 grid
    if node1['X (m)'] == x1_grid_coord and node2['X (m)'] == x1_grid_coord:
        # Check if element is a brace (diagonal: change in x/y AND z coordinates)
        x_change = abs(node1['X (m)'] - node2['X (m)'])
        y_change = abs(node1['Y (m)'] - node2['Y (m)'])
        z_change = abs(node1['Z (m)'] - node2['Z (m)'])
        
        is_brace = z_change > 0 and (x_change > 0 or y_change > 0)
        
        if is_brace:
            # Check if brace is on first floor (one node at first floor, other above)
            node1_first_floor = node1['Z (m)'] == first_floor_z
            node2_first_floor = node2['Z (m)'] == first_floor_z
            node1_above_first = node1['Z (m)'] > first_floor_z
            node2_above_first = node2['Z (m)'] > first_floor_z
            
            if (node1_first_floor and node2_above_first) or (node2_first_floor and node1_above_first):
                elements_to_remove.append(element['Element ID'])

# Remove identified braces
updated_elements_df = elements_df[~elements_df['Element ID'].isin(elements_to_remove)]

# Sort by Element ID
updated_elements_df = updated_elements_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_elements_df.to_csv('Task_39_out/Element.csv', index=False)

print(f"Removed {len(elements_to_remove)} braces from first floor along grid X-1")
if elements_to_remove:
    print(f"Removed element IDs: {elements_to_remove}")