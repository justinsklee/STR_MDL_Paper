import pandas as pd
import os

# Create output folder
os.makedirs('Task_37_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify columns (vertical elements with same x,y coordinates but different z)
columns = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']]
    node2 = node_df[node_df['Node ID'] == element['Node 2']]
    
    if len(node1) > 0 and len(node2) > 0:
        x1, y1, z1 = node1.iloc[0]['X (m)'], node1.iloc[0]['Y (m)'], node1.iloc[0]['Z (m)']
        x2, y2, z2 = node2.iloc[0]['X (m)'], node2.iloc[0]['Y (m)'], node2.iloc[0]['Z (m)']
        
        # Column: same x,y but different z
        if x1 == x2 and y1 == y2 and z1 != z2:
            columns.append(element['Element ID'])

# Identify beams (horizontal elements with same z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']]
    node2 = node_df[node_df['Node ID'] == element['Node 2']]
    
    if len(node1) > 0 and len(node2) > 0:
        z1 = node1.iloc[0]['Z (m)']
        z2 = node2.iloc[0]['Z (m)']
        
        # Beam: same z coordinates
        if z1 == z2:
            beams.append(element['Element ID'])

# Find which beams are directly connected to columns
beams_connected_to_columns = set()
for beam_id in beams:
    beam_element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_node1 = beam_element['Node 1']
    beam_node2 = beam_element['Node 2']
    
    for column_id in columns:
        column_element = element_df[element_df['Element ID'] == column_id].iloc[0]
        column_node1 = column_element['Node 1']
        column_node2 = column_element['Node 2']
        
        # Check if beam shares a node with column
        if beam_node1 in [column_node1, column_node2] or beam_node2 in [column_node1, column_node2]:
            beams_connected_to_columns.add(beam_id)
            break

# Identify sub-beams (beams not directly connected to columns)
sub_beams = [beam_id for beam_id in beams if beam_id not in beams_connected_to_columns]

# Get beam-end-released elements
beam_end_released_elements = set(beam_end_release_df['Element ID'].tolist())

# Find sub-beams that are NOT beam-end-released
sub_beams_not_released = [sub_beam for sub_beam in sub_beams if sub_beam not in beam_end_released_elements]

# Remove these sub-beams from the element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_not_released)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv file
updated_element_df.to_csv('Task_37_out/Element.csv', index=False)