import pandas as pd

# Load the Node data
nodes_df = pd.read_csv('Node.csv')

# Get unique Z coordinates (floor elevations) and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Create a DataFrame with the floor elevations
result_df = pd.DataFrame({
    'Floor Elevation (m)': floor_elevations
})

# Save to CSV file
result_df.to_csv('Task_18_out.csv', index=False)

print("Floor elevations saved to Task_18_out.csv")
print(result_df)