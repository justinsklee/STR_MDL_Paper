import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the maximum Z coordinate to identify the roof level
max_z = node_df['Z (m)'].max()

# Get nodes at the roof level
roof_nodes = node_df[node_df['Z (m)'] == max_z]['Node ID'].tolist()

# Find beams (horizontal elements with no change in Z coordinates)
roof_beams = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a beam (no change in Z coordinates)
    if node1_coords['Z (m)'] == node2_coords['Z (m)']:
        # Check if both nodes are at roof level
        if node1_id in roof_nodes and node2_id in roof_nodes:
            material_id = element['Material']
            material_name = material_df[material_df['Material Number'] == material_id]['Name'].iloc[0]
            
            roof_beams.append({
                'Element ID': element['Element ID'],
                'Material Name': material_name
            })

# Create output dataframe and sort by Element ID
output_df = pd.DataFrame(roof_beams)
output_df = output_df.sort_values('Element ID').reset_index(drop=True)

# Save to CSV
output_df.to_csv('Task_14_out.csv', index=False)

print(f"Found {len(roof_beams)} roof beams")
print(output_df)