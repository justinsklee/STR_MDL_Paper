import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_39_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find first floor elevation (minimum z coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find X-1 grid coordinate (minimum x coordinate)
x1_grid_coord = node_df['X (m)'].min()

# Identify braces on first floor along grid X-1
elements_to_remove = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (change in x/y AND z coordinates)
    x_change = node1_coords['X (m)'] != node2_coords['X (m)']
    y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
    z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if both nodes are on X-1 grid
        node1_on_x1 = node1_coords['X (m)'] == x1_grid_coord
        node2_on_x1 = node2_coords['X (m)'] == x1_grid_coord
        
        # Check if one node is on first floor and other is above
        node1_on_first_floor = node1_coords['Z (m)'] == first_floor_z
        node2_on_first_floor = node2_coords['Z (m)'] == first_floor_z
        node1_above_first_floor = node1_coords['Z (m)'] > first_floor_z
        node2_above_first_floor = node2_coords['Z (m)'] > first_floor_z
        
        # Brace on first floor has one node on first floor and other above
        is_first_floor_brace = (node1_on_first_floor and node2_above_first_floor) or \
                              (node2_on_first_floor and node1_above_first_floor)
        
        if node1_on_x1 and node2_on_x1 and is_first_floor_brace:
            elements_to_remove.append(row['Element ID'])

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(elements_to_remove)]

# Save updated Element.csv file
element_df_updated.to_csv('Task_39_out/Element.csv', index=False)