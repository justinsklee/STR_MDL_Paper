import pandas as pd
import os

# Create output folder
output_folder = 'Task_34_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get nodes for office loading areas
office_nodes = []
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.extend(nodes)

office_nodes = list(set(office_nodes))  # Remove duplicates

# Find beams supporting office loads
# For each office load area defined by 4 nodes, find the 4 beams connecting them
supporting_beams = set()

for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # Create pairs for the 4 beams: (node1,node2), (node2,node3), (node3,node4), (node4,node1)
    beam_pairs = [(nodes[0], nodes[1]), (nodes[1], nodes[2]), (nodes[2], nodes[3]), (nodes[3], nodes[0])]
    
    # Find elements that match these node pairs
    for pair in beam_pairs:
        node1, node2 = pair
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        supporting_beams.update(matching_elements['Element ID'].tolist())

# Update section numbers for supporting beams to 101
element_df.loc[element_df['Element ID'].isin(supporting_beams), 'Section'] = 101

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)