import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_30_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Fourth floor is at index 3 (0-indexed: ground=0, 2nd=1, 3rd=2, 4th=3)
if len(floor_elevations) >= 4:
    fourth_floor_z = floor_elevations[3]
    
    # Find braces on fourth floor
    # Braces have one node on the floor and another node above the floor
    braces_to_remove = []
    
    for idx, row in elements_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        node1_x, node1_y, node1_z = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
        node2_x, node2_y, node2_z = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
        
        # Check if this is a brace (change in x or y AND change in z)
        has_xy_change = (node1_x != node2_x) or (node1_y != node2_y)
        has_z_change = node1_z != node2_z
        
        is_brace = has_xy_change and has_z_change
        
        # Check if brace is on fourth floor (one node on fourth floor, other above)
        if is_brace:
            node_on_fourth_floor = (node1_z == fourth_floor_z) or (node2_z == fourth_floor_z)
            node_above_fourth_floor = (node1_z > fourth_floor_z) or (node2_z > fourth_floor_z)
            
            if node_on_fourth_floor and node_above_fourth_floor:
                braces_to_remove.append(row['Element ID'])
    
    # Remove braces from elements dataframe
    elements_df = elements_df[~elements_df['Element ID'].isin(braces_to_remove)]
    
    # Sort by Element ID
    elements_df = elements_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
elements_df.to_csv('Task_30_out/Element.csv', index=False)