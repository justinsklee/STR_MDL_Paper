import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get supported nodes (nodes with supports)
supported_nodes = set(support_df['Node'].tolist())

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    # Columns: vertical elements (only z changes)
    if dz > 0 and dx == 0 and dy == 0:
        return 'Column'
    # Beams: horizontal elements (no z change)
    elif dz == 0:
        return 'Beam'
    # Braces: diagonal elements (z changes AND x or y changes)
    elif dz > 0 and (dx > 0 or dy > 0):
        return 'Brace'
    else:
        return 'Other'

# Classify all elements
element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Get columns and braces
columns = element_df[element_df['Element_Type'] == 'Column']
braces = element_df[element_df['Element_Type'] == 'Brace']

# Find columns that share supports with bracing elements
columns_sharing_supports = []

for _, column in columns.iterrows():
    column_nodes = {column['Node 1'], column['Node 2']}
    column_supported_nodes = column_nodes.intersection(supported_nodes)
    
    if column_supported_nodes:  # If column has supported nodes
        # Check if any brace also shares these supported nodes
        for _, brace in braces.iterrows():
            brace_nodes = {brace['Node 1'], brace['Node 2']}
            brace_supported_nodes = brace_nodes.intersection(supported_nodes)
            
            # If there's overlap in supported nodes between column and brace
            if column_supported_nodes.intersection(brace_supported_nodes):
                columns_sharing_supports.append(column['Element ID'])
                break

# Remove duplicates and sort
columns_sharing_supports = sorted(list(set(columns_sharing_supports)))

# Create output dataframe
output_df = pd.DataFrame({
    'Element ID': columns_sharing_supports
})

# Save to CSV
output_df.to_csv('Task_8_out.csv', index=False)

print("Task completed. Results saved to Task_8_out.csv")
print(f"Found {len(columns_sharing_supports)} columns sharing supports with bracing elements")