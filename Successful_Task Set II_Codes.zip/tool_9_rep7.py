import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Merge element data with node coordinates to get start and end coordinates
element_with_coords = element_df.merge(
    node_df.rename(columns={'Node ID': 'Node 1', 'X (m)': 'X1', 'Y (m)': 'Y1', 'Z (m)': 'Z1'}),
    on='Node 1'
).merge(
    node_df.rename(columns={'Node ID': 'Node 2', 'X (m)': 'X2', 'Y (m)': 'Y2', 'Z (m)': 'Z2'}),
    on='Node 2'
)

# Identify braces: elements with change in both (x or y) AND z coordinates
element_with_coords['is_brace'] = (
    ((element_with_coords['X1'] != element_with_coords['X2']) | 
     (element_with_coords['Y1'] != element_with_coords['Y2'])) &
    (element_with_coords['Z1'] != element_with_coords['Z2'])
)

# Get all brace element IDs
brace_elements = element_with_coords[element_with_coords['is_brace']]['Element ID'].tolist()

# Get brace elements that have beam-end-release
released_brace_elements = beam_end_release_df[
    beam_end_release_df['Element ID'].isin(brace_elements)
]['Element ID'].tolist()

# Get braces that are NOT beam-end-released
non_released_braces = [elem for elem in brace_elements if elem not in released_brace_elements]

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(non_released_braces)})

# Save to CSV
output_df.to_csv('Task_9_out.csv', index=False)

print(f"Found {len(non_released_braces)} braces that are not beam-end-released")
print(output_df)