import pandas as pd
import os

# Create output folder
os.makedirs('Task_29_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Identify columns (vertical elements with only z-coordinate change)
columns = []
for _, elem in element_df.iterrows():
    node1_id = elem['Node 1']
    node2_id = elem['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (only z changes, x and y remain same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(elem['Element ID'])

# Find beams on the roof (elements at roof elevation with no z change)
roof_beams = []
for _, elem in element_df.iterrows():
    node1_id = elem['Node 1']
    node2_id = elem['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a beam on the roof (no z change and at roof elevation)
    if (node1['Z (m)'] == node2['Z (m)'] and 
        node1['Z (m)'] == roof_elevation):
        roof_beams.append(elem['Element ID'])

# Find nodes that are connected to columns on the roof
column_connected_nodes = set()
for _, elem in element_df.iterrows():
    if elem['Element ID'] in columns:
        node1_id = elem['Node 1']
        node2_id = elem['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Add the node that is at roof elevation
        if node1['Z (m)'] == roof_elevation:
            column_connected_nodes.add(node1_id)
        if node2['Z (m)'] == roof_elevation:
            column_connected_nodes.add(node2_id)

# Identify sub-beams on roof (roof beams not directly connected to columns)
sub_beams_to_remove = []
for beam_id in roof_beams:
    elem = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = elem['Node 1']
    node2_id = elem['Node 2']
    
    # If neither node is connected to a column, it's a sub-beam
    if (node1_id not in column_connected_nodes and 
        node2_id not in column_connected_nodes):
        sub_beams_to_remove.append(beam_id)

# Remove sub-beams from element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_to_remove)]

# Sort by Element ID
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_29_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_to_remove)} sub-beams from roof: {sub_beams_to_remove}")