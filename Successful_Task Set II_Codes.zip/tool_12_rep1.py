import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all supporting beam element IDs for residential loads
supporting_beam_ids = []

for _, load in residential_loads.iterrows():
    # Parse the nodes string to get node IDs
    nodes_str = load['Nodes for Loading Area']
    node_ids = [int(x.strip()) for x in nodes_str.split(',')]
    
    # For each load area defined by 4 nodes, find the 4 connecting beams
    # The beams connect: (node1,node2), (node2,node3), (node3,node4), (node4,node1)
    beam_pairs = []
    for i in range(len(node_ids)):
        node1 = node_ids[i]
        node2 = node_ids[(i + 1) % len(node_ids)]  # Wrap around to first node
        beam_pairs.append((min(node1, node2), max(node1, node2)))  # Sort to match element data
    
    # Find elements that connect these node pairs and are beams (horizontal elements)
    for node1, node2 in beam_pairs:
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        # Check if elements are beams (horizontal - same Z coordinate for both nodes)
        for _, elem in matching_elements.iterrows():
            elem_node1 = elem['Node 1']
            elem_node2 = elem['Node 2']
            
            node1_z = node_df[node_df['Node ID'] == elem_node1]['Z (m)'].iloc[0]
            node2_z = node_df[node_df['Node ID'] == elem_node2]['Z (m)'].iloc[0]
            
            # If both nodes have same Z coordinate, it's a beam
            if node1_z == node2_z:
                supporting_beam_ids.append(elem['Element ID'])

# Remove duplicates
supporting_beam_ids = list(set(supporting_beam_ids))

# Get beam information with section names
beam_info = []
for beam_id in supporting_beam_ids:
    beam_data = element_df[element_df['Element ID'] == beam_id].iloc[0]
    section_num = beam_data['Section']
    section_name = long_section_df[long_section_df['Section Number'] == section_num]['Section Name'].iloc[0]
    
    beam_info.append({
        'Element ID': beam_id,
        'Section Name': section_name
    })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(beam_info)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_12_out.csv', index=False)

print("Results saved to Task_12_out.csv")
print(result_df)