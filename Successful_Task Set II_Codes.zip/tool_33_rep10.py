import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_33_out', exist_ok=True)

# Load CSV files
beam_end_release = pd.read_csv('Beam_end_release.csv')
element = pd.read_csv('Element.csv')
node = pd.read_csv('Node.csv')

# Find X-3 grid coordinate
x_coords = sorted(node['X (m)'].unique())
if len(x_coords) >= 3:
    x3_coord = x_coords[2]  # Third unique X coordinate (X-3)
else:
    x3_coord = None

if x3_coord is not None:
    # Find braces along grid X-3
    braces_on_x3 = []
    
    for _, elem in element.iterrows():
        elem_id = elem['Element ID']
        node1_id = elem['Node 1']
        node2_id = elem['Node 2']
        
        # Get coordinates of both nodes
        node1 = node[node['Node ID'] == node1_id].iloc[0]
        node2 = node[node['Node ID'] == node2_id].iloc[0]
        
        # Check if both nodes are on X-3 grid
        if (abs(node1['X (m)'] - x3_coord) < 1e-6 and 
            abs(node2['X (m)'] - x3_coord) < 1e-6):
            
            # Check if it's a brace (diagonal element)
            x_change = abs(node2['X (m)'] - node1['X (m)']) > 1e-6
            y_change = abs(node2['Y (m)'] - node1['Y (m)']) > 1e-6
            z_change = abs(node2['Z (m)'] - node1['Z (m)']) > 1e-6
            
            # Brace: change in (x or y) AND z coordinates
            if z_change and (x_change or y_change):
                braces_on_x3.append(elem_id)
    
    # Remove beam-end-release entries for braces on X-3
    beam_end_release = beam_end_release[~beam_end_release['Element ID'].isin(braces_on_x3)]
    
    # Sort by Element ID
    beam_end_release = beam_end_release.sort_values('Element ID').reset_index(drop=True)

# Save updated beam end release file
beam_end_release.to_csv('Task_33_out/Beam_end_release.csv', index=False)