import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_elevation = floor_elevations[0]  # Ground level (z = 0.0m)
second_floor_elevation = floor_elevations[1] if len(floor_elevations) > 1 else None

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if it's a column (vertical: only z changes)
    if x1 == x2 and y1 == y2 and z1 != z2:
        return 'Column'
    # Check if it's a beam (horizontal: no z change)
    elif z1 == z2:
        return 'Beam'
    # Check if it's a brace (diagonal: x or y changes AND z changes)
    elif (x1 != x2 or y1 != y2) and z1 != z2:
        return 'Brace'
    else:
        return 'Unknown'

# Classify all elements
element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Find first floor braces
# First floor braces have one node at first floor elevation and the other node above first floor
first_floor_braces = []

for _, row in element_df.iterrows():
    if row['Element_Type'] == 'Brace':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        z1, z2 = node1['Z (m)'], node2['Z (m)']
        
        # Check if one node is at first floor and the other is above first floor
        if (z1 == first_floor_elevation and z2 > first_floor_elevation) or \
           (z2 == first_floor_elevation and z1 > first_floor_elevation):
            first_floor_braces.append({
                'Element ID': row['Element ID'],
                'Section': row['Section']
            })

# Create output dataframe
output_df = pd.DataFrame(first_floor_braces)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_13_out.csv', index=False)

print(f"Found {len(first_floor_braces)} first floor braces")
print(output_df)