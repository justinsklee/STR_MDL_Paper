import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_40_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Identify floor elevations
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor (index 1)

# Identify Y-1 grid coordinate (minimum Y coordinate)
y_grid_coords = sorted(node_df['Y (m)'].unique())
y1_coord = y_grid_coords[0]  # Y-1 grid coordinate

# Identify braces: elements with change in both (x or y) and z coordinates
braces_to_remove = []

for idx, row in element_df.iterrows():
    element_id = row['Element ID']
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates of both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if element is a brace (change in x or y AND change in z)
    has_xy_change = (x1 != x2) or (y1 != y2)
    has_z_change = (z1 != z2)
    is_brace = has_xy_change and has_z_change
    
    if is_brace:
        # Check if brace is on Y-1 grid (both nodes have Y-1 coordinate)
        on_y1_grid = (y1 == y1_coord) and (y2 == y1_coord)
        
        if on_y1_grid:
            # Check if brace is associated with second floor
            # (one node at second floor, other node above)
            is_second_floor_brace = ((z1 == second_floor_z and z2 > second_floor_z) or 
                                   (z2 == second_floor_z and z1 > second_floor_z))
            
            if is_second_floor_brace:
                braces_to_remove.append(element_id)

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID
element_df_updated = element_df_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df_updated.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Removed {len(braces_to_remove)} second floor braces along grid Y-1")
if braces_to_remove:
    print(f"Removed elements: {braces_to_remove}")