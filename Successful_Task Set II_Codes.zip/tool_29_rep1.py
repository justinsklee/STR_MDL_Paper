import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_29_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Find all beams on the roof (elements with both nodes at roof elevation and no change in z)
roof_beams = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in z coordinates) and on roof
    if node1_z == node2_z and node1_z == roof_elevation:
        roof_beams.append(row['Element ID'])

# Find all columns (elements that connect to roof nodes from below)
roof_nodes = node_df[node_df['Z (m)'] == roof_elevation]['Node ID'].tolist()
columns_connected_to_roof = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a column (change only in z coordinates)
    node1_x = node_df[node_df['Node ID'] == node1_id]['X (m)'].iloc[0]
    node1_y = node_df[node_df['Node ID'] == node1_id]['Y (m)'].iloc[0]
    node2_x = node_df[node_df['Node ID'] == node2_id]['X (m)'].iloc[0]
    node2_y = node_df[node_df['Node ID'] == node2_id]['Y (m)'].iloc[0]
    
    if (node1_x == node2_x and node1_y == node2_y and node1_z != node2_z):
        # This is a column - check if it connects to roof
        if node1_id in roof_nodes or node2_id in roof_nodes:
            columns_connected_to_roof.append(row['Element ID'])

# Find nodes that are directly connected to columns on the roof
nodes_connected_to_columns = set()
for col_id in columns_connected_to_roof:
    col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
    node1_id = col_row['Node 1']
    node2_id = col_row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Add the roof-level node
    if node1_z == roof_elevation:
        nodes_connected_to_columns.add(node1_id)
    if node2_z == roof_elevation:
        nodes_connected_to_columns.add(node2_id)

# Identify sub-beams on roof (beams not directly connected to columns)
sub_beams_on_roof = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_row['Node 1']
    node2_id = beam_row['Node 2']
    
    # Check if both nodes are NOT directly connected to columns
    if node1_id not in nodes_connected_to_columns and node2_id not in nodes_connected_to_columns:
        sub_beams_on_roof.append(beam_id)

# Remove sub-beams from element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_on_roof)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv file
updated_element_df.to_csv('Task_29_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_on_roof)} sub-beams from roof: {sub_beams_on_roof}")