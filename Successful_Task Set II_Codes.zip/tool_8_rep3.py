import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support nodes
support_nodes = set(support_df['Node'].tolist())

# Classify elements
columns = []
braces = []

for _, row in element_df.iterrows():
    element_id = row['Element ID']
    node1 = row['Node 1']
    node2 = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    x1, y1, z1 = node1_coords['X (m)'], node1_coords['Y (m)'], node1_coords['Z (m)']
    x2, y2, z2 = node2_coords['X (m)'], node2_coords['Y (m)'], node2_coords['Z (m)']
    
    # Classify elements
    if x1 == x2 and y1 == y2 and z1 != z2:  # Column: only z changes
        columns.append(element_id)
    elif (x1 != x2 or y1 != y2) and z1 != z2:  # Brace: x or y changes AND z changes
        braces.append(element_id)

# Find columns that share support nodes with bracing elements
columns_sharing_supports_with_braces = []

for col_id in columns:
    col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
    col_node1 = col_row['Node 1']
    col_node2 = col_row['Node 2']
    col_nodes = {col_node1, col_node2}
    
    # Check if column has nodes at supports
    col_support_nodes = col_nodes.intersection(support_nodes)
    
    if col_support_nodes:
        # Check if any brace shares these support nodes
        for brace_id in braces:
            brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
            brace_node1 = brace_row['Node 1']
            brace_node2 = brace_row['Node 2']
            brace_nodes = {brace_node1, brace_node2}
            
            # Check if brace shares any support node with this column
            if col_support_nodes.intersection(brace_nodes):
                columns_sharing_supports_with_braces.append(col_id)
                break

# Remove duplicates and sort
columns_sharing_supports_with_braces = sorted(list(set(columns_sharing_supports_with_braces)))

# Create output dataframe
output_df = pd.DataFrame({
    'Element ID': columns_sharing_supports_with_braces
})

# Save to CSV
output_df.to_csv('Task_8_out.csv', index=False)

print(f"Found {len(columns_sharing_supports_with_braces)} columns that share supports with bracing elements")
print(output_df)