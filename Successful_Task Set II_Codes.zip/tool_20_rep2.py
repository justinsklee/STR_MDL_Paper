import pandas as pd
import numpy as np
import math

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Find all columns that have one node at first floor and another node above first floor
first_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates of both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only z changes, x and y stay same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is at first floor and other is above
        if ((node1['Z (m)'] == first_floor_z and node2['Z (m)'] > first_floor_z) or
            (node2['Z (m)'] == first_floor_z and node1['Z (m)'] > first_floor_z)):
            first_floor_columns.append(element)

# Calculate total weight
total_weight = 0.0
steel_density = 7850  # kg/m^3

for column in first_floor_columns:
    # Get section properties
    section_num = column['Section']
    section_info = section_df[section_df['Section Number'] == section_num].iloc[0]
    area = section_info['Area']  # m^2
    
    # Get column length
    node1_id = column['Node 1']
    node2_id = column['Node 2']
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    length = abs(node2['Z (m)'] - node1['Z (m)'])  # m
    
    # Calculate volume and weight
    volume = area * length  # m^3
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
output_df = pd.DataFrame({
    'Total Weight of First Floor Columns (kg)': [total_weight_rounded]
})

output_df.to_csv('Task_20_out.csv', index=False)

print(f"Total weight of first floor columns: {total_weight_rounded} kg")