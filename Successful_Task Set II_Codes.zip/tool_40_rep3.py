import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_40_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Identify second floor elevation
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor (first floor is index 0)

# Find Y-1 grid coordinate (minimum y-coordinate)
y_grid_1 = node_df['Y (m)'].min()

# Identify braces on second floor along grid Y-1
braces_to_remove = []

for idx, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (change in x/y AND z coordinates)
    x_change = node1['X (m)'] != node2['X (m)']
    y_change = node1['Y (m)'] != node2['Y (m)']
    z_change = node1['Z (m)'] != node2['Z (m)']
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if brace is on grid Y-1 (both nodes have same Y coordinate as Y-1 grid)
        on_y_grid_1 = (node1['Y (m)'] == y_grid_1) and (node2['Y (m)'] == y_grid_1)
        
        # Check if brace is connected to second floor
        # One node should be at second floor, other above second floor
        node_elevations = [node1['Z (m)'], node2['Z (m)']]
        has_second_floor_connection = second_floor_z in node_elevations
        has_node_above_second_floor = any(z > second_floor_z for z in node_elevations)
        
        if on_y_grid_1 and has_second_floor_connection and has_node_above_second_floor:
            braces_to_remove.append(element['Element ID'])

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID
element_df_updated = element_df_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df_updated.to_csv('Task_40_out/Element.csv', index=False)

print(f"Removed {len(braces_to_remove)} second floor braces along grid Y-1")
print(f"Removed brace Element IDs: {braces_to_remove}")