import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Function to calculate element length
def calculate_length(node1_id, node2_id, node_df):
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = node2['X (m)'] - node1['X (m)']
    dy = node2['Y (m)'] - node1['Y (m)']
    dz = node2['Z (m)'] - node1['Z (m)']
    
    return np.sqrt(dx**2 + dy**2 + dz**2)

# Function to check if element is a beam (no change in z coordinates)
def is_beam(element_row, node_df):
    node1_id = element_row['Node 1']
    node2_id = element_row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    return node1_z == node2_z

# Collect supporting beams for office loads
supporting_beams = []

for _, office_load in office_loads.iterrows():
    # Parse nodes from the load area
    nodes_str = office_load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # Create pairs for the 4 beams that form the load area boundary
    beam_pairs = [(nodes[0], nodes[1]), (nodes[1], nodes[2]), (nodes[2], nodes[3]), (nodes[3], nodes[0])]
    
    for node1, node2 in beam_pairs:
        # Find element connecting these nodes
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            if is_beam(element, node_df):
                length = calculate_length(element['Node 1'], element['Node 2'], node_df)
                supporting_beams.append({
                    'Element ID': element['Element ID'],
                    'Section': element['Section'],
                    'Length (m)': round(length, 3)
                })

# Remove duplicates and sort by Element ID
supporting_beams_df = pd.DataFrame(supporting_beams).drop_duplicates().sort_values('Element ID')

# Save to CSV
supporting_beams_df.to_csv('Task_50_out.csv', index=False)

print(supporting_beams_df)