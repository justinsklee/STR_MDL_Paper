import pandas as pd
import os

# Create output folder
os.makedirs('Task_37_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Classify elements into columns, beams, and braces
def classify_elements(element_df, node_df):
    classifications = []
    
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check coordinate differences
        dx = abs(node2['X (m)'] - node1['X (m)'])
        dy = abs(node2['Y (m)'] - node1['Y (m)'])
        dz = abs(node2['Z (m)'] - node1['Z (m)'])
        
        if dz > 0 and dx == 0 and dy == 0:
            classifications.append('column')
        elif dz == 0:
            classifications.append('beam')
        elif dz > 0 and (dx > 0 or dy > 0):
            classifications.append('brace')
        else:
            classifications.append('unknown')
    
    return classifications

# Get element classifications
element_df['classification'] = classify_elements(element_df, node_df)

# Get all beams
beams_df = element_df[element_df['classification'] == 'beam'].copy()

# Get all columns
columns_df = element_df[element_df['classification'] == 'column'].copy()

# Find nodes that are connected to columns
column_nodes = set()
for _, column in columns_df.iterrows():
    column_nodes.add(column['Node 1'])
    column_nodes.add(column['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for _, beam in beams_df.iterrows():
    node1 = beam['Node 1']
    node2 = beam['Node 2']
    
    # If neither node is connected to a column, it's a sub-beam
    if node1 not in column_nodes and node2 not in column_nodes:
        sub_beams.append(beam['Element ID'])

# Get beam-end-released elements
released_elements = set(beam_end_release_df['Element ID'].tolist())

# Find sub-beams that are NOT beam-end-released
sub_beams_to_remove = []
for sub_beam_id in sub_beams:
    if sub_beam_id not in released_elements:
        sub_beams_to_remove.append(sub_beam_id)

# Remove sub-beams that are not beam-end-released
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_to_remove)].copy()

# Drop the classification column as it's not part of the original data
updated_element_df = updated_element_df.drop('classification', axis=1)

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save the updated Element.csv file
updated_element_df.to_csv('Task_37_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_to_remove)} sub-beams that were not beam-end-released:")
print(f"Element IDs removed: {sub_beams_to_remove}")
print(f"Updated Element.csv saved with {len(updated_element_df)} elements")