import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_48_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique Y coordinates to identify Y grids
y_coords = sorted(node_df['Y (m)'].unique())
y1_coord = y_coords[0]  # First Y grid (Y-1)

# Get first floor elevation (z = 0.0)
first_floor_z = 0.0

# Get second floor elevation
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor elevation

# Find braces on first floor along grid Y-1 with section 101
braces_to_update = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    section = row['Section']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on Y-1 grid
    if node1['Y (m)'] == y1_coord and node2['Y (m)'] == y1_coord:
        # Check if it's a brace (diagonal element with z-coordinate change)
        z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 0
        x_or_y_change = abs(node1['X (m)'] - node2['X (m)']) > 0
        
        if z_change and x_or_y_change:
            # Check if one node is on first floor
            node_z_coords = [node1['Z (m)'], node2['Z (m)']]
            if first_floor_z in node_z_coords:
                # Check if other node is above first floor
                other_z = [z for z in node_z_coords if z != first_floor_z][0]
                if other_z > first_floor_z and section == 101:
                    braces_to_update.append(idx)

# Update section for identified braces
for idx in braces_to_update:
    element_df.at[idx, 'Section'] = 103

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Updated {len(braces_to_update)} first floor braces along grid Y-1 from section 101 to section 103")