import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all beam elements (horizontal elements - no change in Z coordinates)
beam_elements = []
for _, element in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
    
    if node1_z == node2_z:  # Beam (horizontal element)
        beam_elements.append(element)

beam_elements_df = pd.DataFrame(beam_elements)

# Find beams supporting residential loads
supporting_beams = []

for _, res_load in residential_loads.iterrows():
    # Parse nodes for loading area
    load_nodes = [int(x.strip()) for x in res_load['Nodes for Loading Area'].split(',')]
    
    # Find beams connecting these nodes in sequence (forming the perimeter)
    for i in range(len(load_nodes)):
        node1 = load_nodes[i]
        node2 = load_nodes[(i + 1) % len(load_nodes)]  # Next node (wraps around to first)
        
        # Find beam connecting these two nodes
        supporting_beam = beam_elements_df[
            ((beam_elements_df['Node 1'] == node1) & (beam_elements_df['Node 2'] == node2)) |
            ((beam_elements_df['Node 1'] == node2) & (beam_elements_df['Node 2'] == node1))
        ]
        
        if not supporting_beam.empty:
            supporting_beams.append(supporting_beam.iloc[0])

# Remove duplicates and create DataFrame
supporting_beams_df = pd.DataFrame(supporting_beams).drop_duplicates(subset=['Element ID'])

# Get section names
result_data = []
for _, beam in supporting_beams_df.iterrows():
    section_num = beam['Section']
    section_name = long_section_df[long_section_df['Section Number'] == section_num]['Section Name'].iloc[0]
    result_data.append({
        'Element ID': beam['Element ID'],
        'Section Name': section_name
    })

# Create result DataFrame and sort by Element ID
result_df = pd.DataFrame(result_data).sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_12_out.csv', index=False)