import pandas as pd
import os

# Create output folder
output_folder = 'Task_30_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Determine fourth floor elevation (index 3 since we start from 0)
if len(floor_elevations) >= 4:
    fourth_floor_z = floor_elevations[3]
else:
    print(f"Model only has {len(floor_elevations)} floors. Cannot remove braces from fourth floor.")
    fourth_floor_z = None

if fourth_floor_z is not None:
    # Create node coordinate lookup
    node_coords = {}
    for _, row in nodes_df.iterrows():
        node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])
    
    # Identify braces to remove (braces on fourth floor)
    elements_to_remove = []
    
    for _, row in elements_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        if node1_id in node_coords and node2_id in node_coords:
            x1, y1, z1 = node_coords[node1_id]
            x2, y2, z2 = node_coords[node2_id]
            
            # Check if this is a brace (diagonal element with change in x/y AND z coordinates)
            has_xy_change = (x1 != x2) or (y1 != y2)
            has_z_change = z1 != z2
            is_brace = has_xy_change and has_z_change
            
            # Check if brace is on fourth floor (one node at fourth floor, other above)
            if is_brace:
                if (z1 == fourth_floor_z and z2 > fourth_floor_z) or (z2 == fourth_floor_z and z1 > fourth_floor_z):
                    elements_to_remove.append(row['Element ID'])
    
    # Remove identified braces
    updated_elements_df = elements_df[~elements_df['Element ID'].isin(elements_to_remove)]
    
    # Save updated Element.csv
    updated_elements_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)
    
    print(f"Removed {len(elements_to_remove)} braces from fourth floor")
    if elements_to_remove:
        print(f"Removed element IDs: {elements_to_remove}")