import pandas as pd

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Find unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
else:
    # If there's no third floor, use the highest elevation
    third_floor_elevation = max(floor_elevations)

# Find all beams on the third floor (elements where both nodes have same Z coordinate as third floor)
third_floor_beams = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_z = nodes_df[nodes_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = nodes_df[nodes_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (horizontal element at third floor level)
    if node1_z == third_floor_elevation and node2_z == third_floor_elevation:
        third_floor_beams.append(element['Element ID'])

# Find columns (vertical elements) - elements where nodes have same X,Y but different Z
column_elements = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (same X,Y coordinates, different Z)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        column_elements.append(element['Element ID'])

# Find nodes that are connected to columns on third floor
column_connected_nodes = set()
for _, element in elements_df.iterrows():
    if element['Element ID'] in column_elements:
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        node1_z = nodes_df[nodes_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
        node2_z = nodes_df[nodes_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
        
        # Add the node that's at third floor elevation
        if node1_z == third_floor_elevation:
            column_connected_nodes.add(node1_id)
        if node2_z == third_floor_elevation:
            column_connected_nodes.add(node2_id)

# Find sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in third_floor_beams:
    element = elements_df[elements_df['Element ID'] == beam_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Check if neither node is connected to a column
    if node1_id not in column_connected_nodes and node2_id not in column_connected_nodes:
        sub_beams.append(beam_id)

# Create output data for sub-beams with release status
output_data = []
for beam_id in sorted(sub_beams):
    # Check if beam has release in beam_end_release_df
    release_row = beam_end_release_df[beam_end_release_df['Element ID'] == beam_id]
    
    if not release_row.empty:
        i_release = release_row.iloc[0]['i-end release']
        j_release = release_row.iloc[0]['j-end release']
        
        # Convert release codes to 0 (released) or 1 (fixed)
        # Release code 11 means released, 10 means fixed
        i_status = 0 if str(i_release) == '11' else 1
        j_status = 0 if str(j_release) == '11' else 1
    else:
        # If not in release table, assume fixed (1)
        i_status = 1
        j_status = 1
    
    output_data.append([beam_id, i_status, j_status])

# Create DataFrame and save to CSV
output_df = pd.DataFrame(output_data, columns=['Element Number', 'i-end (0=released, 1=fixed)', 'j-end (0=released, 1=fixed)'])
output_df.to_csv('Task_31_out.csv', index=False)