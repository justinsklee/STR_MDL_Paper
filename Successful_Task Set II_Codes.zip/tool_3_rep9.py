import pandas as pd

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = nodes_df['X (m)'].min()

# Get nodes that are on grid X-1
x1_nodes = nodes_df[nodes_df['X (m)'] == x1_coord]['Node ID'].tolist()

# Filter elements where both nodes are on grid X-1
elements_on_x1 = elements_df[
    (elements_df['Node 1'].isin(x1_nodes)) & 
    (elements_df['Node 2'].isin(x1_nodes))
]

# For each element on X-1, check if it's a brace
braces_x1 = []

for _, element in elements_on_x1.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (changes in x/y AND z coordinates)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    # Brace: change in (x or y) AND z coordinates
    if (x_change or y_change) and z_change:
        braces_x1.append(element['Element ID'])

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(braces_x1)})

# Save to CSV
output_df.to_csv('Task_3_out.csv', index=False)

print(f"Found {len(braces_x1)} braces along grid X-1")
print(output_df)