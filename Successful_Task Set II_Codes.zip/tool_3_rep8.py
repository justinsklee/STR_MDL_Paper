import pandas as pd
import numpy as np

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find X-1 grid coordinate (first unique X coordinate when sorted)
x_coords = sorted(node_df['X (m)'].unique())
x1_coord = x_coords[0]  # X-1 grid coordinate

# Create node coordinate lookup
node_coords = node_df.set_index('Node ID')[['X (m)', 'Y (m)', 'Z (m)']]

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1_coords = node_coords.loc[node1_id]
    node2_coords = node_coords.loc[node2_id]
    
    # Check coordinate changes
    x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 1e-6
    y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 1e-6
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
    
    # Classify based on coordinate changes
    if z_change and not x_change and not y_change:
        return 'Column'
    elif not z_change:
        return 'Beam'
    elif (x_change or y_change) and z_change:
        return 'Brace'
    else:
        return 'Unknown'

# Add element classification
element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Find braces along grid X-1
braces_x1 = []

for _, row in element_df.iterrows():
    if row['Element_Type'] == 'Brace':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1_x = node_coords.loc[node1_id, 'X (m)']
        node2_x = node_coords.loc[node2_id, 'X (m)']
        
        # Check if both nodes are on grid X-1
        if abs(node1_x - x1_coord) < 1e-6 and abs(node2_x - x1_coord) < 1e-6:
            braces_x1.append(row['Element ID'])

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(braces_x1)})

# Save to CSV
output_df.to_csv('Task_3_out.csv', index=False)

print(f"Found {len(braces_x1)} braces along grid X-1")
print(output_df)