import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_36_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support node IDs
support_nodes = set(support_df['Node'].tolist())

# Identify columns (vertical elements)
columns = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Identify bracing elements (diagonal elements)
braces = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is diagonal (brace)
    if ((node1['X (m)'] != node2['X (m)'] or node1['Y (m)'] != node2['Y (m)']) and 
        node1['Z (m)'] != node2['Z (m)']):
        braces.append(row['Element ID'])

# Find nodes that are shared between support nodes and bracing elements
nodes_with_braces = set()
for idx, row in element_df.iterrows():
    if row['Element ID'] in braces:
        nodes_with_braces.add(row['Node 1'])
        nodes_with_braces.add(row['Node 2'])

# Find nodes that have both supports and bracing
shared_nodes = support_nodes.intersection(nodes_with_braces)

# Find columns that are connected to these shared nodes
columns_to_update = []
for idx, row in element_df.iterrows():
    if row['Element ID'] in columns:
        if row['Node 1'] in shared_nodes or row['Node 2'] in shared_nodes:
            columns_to_update.append(row['Element ID'])

# Update section for these columns to 101
for idx, row in element_df.iterrows():
    if row['Element ID'] in columns_to_update:
        element_df.at[idx, 'Section'] = 101

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv file
element_df.to_csv('Task_36_out/Element.csv', index=False)

print(f"Updated sections for columns {columns_to_update} to section 101")
print(f"These columns share supports with bracing elements at nodes {shared_nodes}")