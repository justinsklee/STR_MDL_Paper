import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_23_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
sections_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find second floor elevation
second_floor_z = nodes_df[nodes_df['Z (m)'] > first_floor_z]['Z (m)'].min()

# Find section number for H 100x100x6/8
target_section = sections_df[sections_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Identify first floor braces
first_floor_braces = []

for idx, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a brace (diagonal element)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if this is a first floor brace
        # One node at first floor, other node above first floor
        node1_at_first = abs(node1['Z (m)'] - first_floor_z) < 1e-6
        node2_at_first = abs(node2['Z (m)'] - first_floor_z) < 1e-6
        node1_above_first = node1['Z (m)'] > first_floor_z
        node2_above_first = node2['Z (m)'] > first_floor_z
        
        if (node1_at_first and node2_above_first) or (node2_at_first and node1_above_first):
            first_floor_braces.append(element['Element ID'])

# Update section for first floor braces
for brace_id in first_floor_braces:
    elements_df.loc[elements_df['Element ID'] == brace_id, 'Section'] = target_section

# Save updated Element.csv
elements_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Updated {len(first_floor_braces)} first floor braces to section H 100x100x6/8")
print(f"First floor brace IDs: {first_floor_braces}")