import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create node coordinate lookup
node_coords = node_df.set_index('Node ID')[['X (m)', 'Y (m)', 'Z (m)']].to_dict('index')

# Find X-1 grid coordinate (minimum X coordinate)
x1_coord = node_df['X (m)'].min()

# Identify braces and filter for X-1 grid
braces_x1 = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_coords[node1_id]
    node2_coords = node_coords[node2_id]
    
    # Check if element is a brace (diagonal: change in x/y AND z coordinates)
    x_change = node1_coords['X (m)'] != node2_coords['X (m)']
    y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
    z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
    
    is_brace = (x_change or y_change) and z_change
    
    # Check if both nodes are on X-1 grid
    on_x1_grid = (node1_coords['X (m)'] == x1_coord and node2_coords['X (m)'] == x1_coord)
    
    if is_brace and on_x1_grid:
        braces_x1.append(element_id)

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(braces_x1)})

# Save to CSV
output_df.to_csv('Task_3_out.csv', index=False)