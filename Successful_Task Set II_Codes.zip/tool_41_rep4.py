import pandas as pd
import numpy as np

# Load the relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Identify roof level (highest z-coordinate)
roof_level = node_df['Z (m)'].max()

# Filter elements with section 101
section_101_elements = element_df[element_df['Section'] == 101].copy()

# For each element, get node coordinates and check if it's a roof beam
roof_beams = []
for _, element in section_101_elements.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are at roof level and z-coordinates are the same (horizontal beam)
    if node1['Z (m)'] == roof_level and node2['Z (m)'] == roof_level:
        # Calculate beam length
        length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                        (node2['Y (m)'] - node1['Y (m)'])**2 + 
                        (node2['Z (m)'] - node1['Z (m)'])**2)
        
        roof_beams.append({
            'Element ID': element['Element ID'],
            'Length (m)': length
        })

# Get section 101 properties
section_101 = section_df[section_df['Section Number'] == 101].iloc[0]
area = section_101['Area']  # m^2

# Calculate total weight
density = 7850  # kg/m^3
total_length = sum([beam['Length (m)'] for beam in roof_beams])
total_weight = total_length * area * density

# Round up to nearest 10 kg
total_weight_rounded = np.ceil(total_weight / 10) * 10

# Create output dataframe
output_df = pd.DataFrame({
    'Total Weight of Roof Beams with Section 101 (kg)': [int(total_weight_rounded)]
})

# Save to CSV
output_df.to_csv('Task_41_out.csv', index=False)