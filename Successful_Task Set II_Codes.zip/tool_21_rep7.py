import pandas as pd
import numpy as np
import os

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Create output folder
os.makedirs('Task_21_out', exist_ok=True)

# Find unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Second floor is at index 1 (first floor is index 0)
if len(floor_elevations) >= 2:
    second_floor_elevation = floor_elevations[1]
    
    # Find all columns that have one node at second floor elevation and another node above it
    second_floor_columns = []
    
    for idx, element in elements_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2_coords = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a column (vertical element - same x,y but different z)
        is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                    node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                    node1_coords['Z (m)'] != node2_coords['Z (m)'])
        
        if is_column:
            # Check if one node is at second floor and the other is above
            node1_z = node1_coords['Z (m)']
            node2_z = node2_coords['Z (m)']
            
            if ((node1_z == second_floor_elevation and node2_z > second_floor_elevation) or
                (node2_z == second_floor_elevation and node1_z > second_floor_elevation)):
                second_floor_columns.append(element['Element ID'])
    
    # Update section for second floor columns
    for col_id in second_floor_columns:
        elements_df.loc[elements_df['Element ID'] == col_id, 'Section'] = 102
    
    # Save updated Element.csv
    elements_df.to_csv('Task_21_out/Element.csv', index=False)
    
    print(f"Updated {len(second_floor_columns)} second floor columns to section 102")
    print(f"Second floor column IDs: {second_floor_columns}")