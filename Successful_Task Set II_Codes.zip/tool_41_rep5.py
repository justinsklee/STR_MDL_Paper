import pandas as pd
import numpy as np

# Load relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get the highest z-coordinate to identify roof level
max_z = node_df['Z (m)'].max()

# Filter elements with section 101
section_101_elements = element_df[element_df['Section'] == 101].copy()

# For each element, check if it's a roof beam (both nodes at max z-level)
roof_beams = []
for _, element in section_101_elements.iterrows():
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in z coordinates) and at roof level
    if node1_z == node2_z == max_z:
        roof_beams.append(element['Element ID'])

# Filter roof beams with section 101
roof_beam_elements = element_df[element_df['Element ID'].isin(roof_beams)].copy()

# Calculate length of each roof beam
total_length = 0
for _, element in roof_beam_elements.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                     (node2['Y (m)'] - node1['Y (m)'])**2 + 
                     (node2['Z (m)'] - node1['Z (m)'])**2)
    total_length += length

# Get section properties for section 101
section_101 = section_df[section_df['Section Number'] == 101].iloc[0]
area = section_101['Area']  # m²

# Calculate total weight
density = 7850  # kg/m³
total_weight = total_length * area * density

# Round up to nearest 10 kg
total_weight_rounded = np.ceil(total_weight / 10) * 10

# Create output dataframe
result_df = pd.DataFrame({
    'Total Weight of Roof Beams with Section 101 (kg)': [int(total_weight_rounded)]
})

# Save to CSV
result_df.to_csv('Task_41_out.csv', index=False)