import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique z-coordinates to identify floors
z_coords = sorted(node_df['Z (m)'].unique())

# Identify beams (horizontal elements - no change in z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in z coordinates)
    if node1['Z (m)'] == node2['Z (m)']:
        # Calculate length
        dx = node2['X (m)'] - node1['X (m)']
        dy = node2['Y (m)'] - node1['Y (m)']
        dz = node2['Z (m)'] - node1['Z (m)']
        length = np.sqrt(dx**2 + dy**2 + dz**2)
        
        beams.append({
            'Element ID': element['Element ID'],
            'Length': length
        })

# Convert to DataFrame
beams_df = pd.DataFrame(beams)

# Filter beams shorter than 1.3m
short_beams = beams_df[beams_df['Length'] < 1.3].copy()

# Sort by Element ID
short_beams = short_beams.sort_values('Element ID')

# Select only required columns and rename
result_df = short_beams[['Element ID', 'Length']].copy()
result_df.columns = ['Element Number', 'Length']

# Save to CSV
result_df.to_csv('Task_19_out.csv', index=False)

print(f"Found {len(result_df)} beams shorter than 1.3m")
print(result_df)