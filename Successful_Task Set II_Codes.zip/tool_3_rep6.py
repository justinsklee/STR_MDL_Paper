import pandas as pd

# Load CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')

# Find X-1 grid coordinate (first unique X coordinate when sorted)
x_coordinates = sorted(nodes_df['X (m)'].unique())
x1_coord = x_coordinates[0]  # X-1 grid coordinate

# Create node coordinate lookup
node_coords = nodes_df.set_index('Node ID')[['X (m)', 'Y (m)', 'Z (m)']]

# Find braces along grid X-1
braces_x1 = []

for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_coords.loc[node1_id]
    node2_coords = node_coords.loc[node2_id]
    
    # Check if both nodes are on X-1 grid
    if node1_coords['X (m)'] == x1_coord and node2_coords['X (m)'] == x1_coord:
        # Check if it's a brace (diagonal: change in both horizontal and vertical coordinates)
        x_change = node1_coords['X (m)'] != node2_coords['X (m)']
        y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        
        # Brace: change in (x or y) AND z coordinates
        if (x_change or y_change) and z_change:
            braces_x1.append(element['Element ID'])

# Create output dataframe
result_df = pd.DataFrame({'Element ID': sorted(braces_x1)})

# Save to CSV
result_df.to_csv('Task_3_out.csv', index=False)