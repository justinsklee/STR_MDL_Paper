import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create node coordinate lookup
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Identify beams and calculate lengths
beam_data = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get coordinates
    x1, y1, z1 = node_coords[node1]
    x2, y2, z2 = node_coords[node2]
    
    # Check if it's a beam (no change in z coordinates)
    if z1 == z2:
        # Calculate length
        length = np.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)
        
        # Check if length is shorter than 1.3m
        if length < 1.3:
            beam_data.append([element_id, length])

# Create DataFrame and sort by element number
result_df = pd.DataFrame(beam_data, columns=['Element Number', 'Length'])
result_df = result_df.sort_values('Element Number')

# Save to CSV
result_df.to_csv('Task_19_out.csv', index=False)

print(f"Found {len(result_df)} beams shorter than 1.3m")
print(result_df)