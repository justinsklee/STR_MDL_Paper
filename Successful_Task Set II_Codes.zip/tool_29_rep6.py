import pandas as pd
import os

# Create output folder
os.makedirs('Task_29_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the highest floor elevation (roof level)
roof_elevation = node_df['Z (m)'].max()

# Get nodes at roof level
roof_nodes = node_df[node_df['Z (m)'] == roof_elevation]['Node ID'].tolist()

# Identify columns (vertical elements with only z-coordinate change)
columns = []
for _, elem in element_df.iterrows():
    node1_coords = node_df[node_df['Node ID'] == elem['Node 1']][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == elem['Node 2']][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    
    # Check if it's a column (only z changes, x and y stay the same)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        columns.append(elem['Element ID'])

# Find beams at roof level (both nodes at roof elevation)
roof_beams = []
for _, elem in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == elem['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == elem['Node 2']]['Z (m)'].iloc[0]
    
    # Check if it's a beam at roof level (both nodes at same z, and at roof elevation)
    if node1_z == node2_z == roof_elevation:
        roof_beams.append(elem['Element ID'])

# Find nodes that are connected to columns at roof level
column_connected_roof_nodes = set()
for _, elem in element_df.iterrows():
    if elem['Element ID'] in columns:
        node1_z = node_df[node_df['Node ID'] == elem['Node 1']]['Z (m)'].iloc[0]
        node2_z = node_df[node_df['Node ID'] == elem['Node 2']]['Z (m)'].iloc[0]
        
        # Add the roof-level node of the column
        if node1_z == roof_elevation:
            column_connected_roof_nodes.add(elem['Node 1'])
        if node2_z == roof_elevation:
            column_connected_roof_nodes.add(elem['Node 2'])

# Identify sub-beams on roof (beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1 = beam_row['Node 1']
    node2 = beam_row['Node 2']
    
    # If neither node is connected to a column, it's a sub-beam
    if node1 not in column_connected_roof_nodes and node2 not in column_connected_roof_nodes:
        roof_sub_beams.append(beam_id)

# Remove sub-beams from roof
updated_element_df = element_df[~element_df['Element ID'].isin(roof_sub_beams)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID')

# Save updated Element.csv
updated_element_df.to_csv('Task_29_out/Element.csv', index=False)