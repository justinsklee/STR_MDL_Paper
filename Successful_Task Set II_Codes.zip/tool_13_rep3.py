import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_idx = floor_elevations.index(first_floor_z)

# Get the elevation above first floor
if first_floor_idx + 1 < len(floor_elevations):
    above_first_floor_z = floor_elevations[first_floor_idx + 1]
else:
    above_first_floor_z = None

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if it's a column (vertical: only z changes)
    if x1 == x2 and y1 == y2 and z1 != z2:
        return 'column'
    # Check if it's a beam (horizontal: no z change)
    elif z1 == z2:
        return 'beam'
    # Check if it's a brace (diagonal: x or y changes AND z changes)
    elif (x1 != x2 or y1 != y2) and z1 != z2:
        return 'brace'
    else:
        return 'unknown'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Filter for first floor bracing
# Braces have one node at first floor and the other node above first floor
first_floor_braces = []

for _, row in element_df.iterrows():
    if row['element_type'] == 'brace':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
        node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
        
        # Check if one node is at first floor and the other is above
        if ((node1_z == first_floor_z and node2_z == above_first_floor_z) or 
            (node2_z == first_floor_z and node1_z == above_first_floor_z)):
            first_floor_braces.append({
                'Element ID': row['Element ID'],
                'Section': row['Section']
            })

# Create output dataframe
output_df = pd.DataFrame(first_floor_braces)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_13_out.csv', index=False)

print(f"First floor bracing elements found: {len(output_df)}")
print(output_df)