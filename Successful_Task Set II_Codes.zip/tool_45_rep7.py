import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation (index 1)
second_floor_z = floor_elevations[1]

# Get unique Y coordinates and sort them to identify grids
y_coordinates = sorted(node_df['Y (m)'].unique())

# Grid Y-1 is the first Y coordinate (index 0)
grid_y1_coord = y_coordinates[0]

# Find nodes on second floor and grid Y-1
second_floor_nodes = node_df[node_df['Z (m)'] == second_floor_z]['Node ID'].tolist()
grid_y1_nodes = node_df[node_df['Y (m)'] == grid_y1_coord]['Node ID'].tolist()

# Find columns (vertical elements with only Z coordinate change)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only Z changes, X and Y stay the same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Find columns on second floor along grid Y-1
# Columns have one node on the floor and one node above the floor
second_floor_y1_columns = []

for col_id in columns:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on grid Y-1
    if (node1['Y (m)'] == grid_y1_coord and node2['Y (m)'] == grid_y1_coord):
        # Check if one node is on second floor and the other is above
        if ((node1['Z (m)'] == second_floor_z and node2['Z (m)'] > second_floor_z) or
            (node2['Z (m)'] == second_floor_z and node1['Z (m)'] > second_floor_z)):
            second_floor_y1_columns.append(col_id)

# Get the requested information for these columns
result_data = []
for col_id in sorted(second_floor_y1_columns):
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    section_num = element['Section']
    material_num = element['Material']
    
    # Get section name
    section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
    
    # Get material name
    material_name = material_df[material_df['Material Number'] == material_num]['Name'].iloc[0]
    
    result_data.append({
        'Element ID': col_id,
        'Section Name': section_name,
        'Material Name': material_name
    })

# Create DataFrame and save to CSV
result_df = pd.DataFrame(result_data)
result_df.to_csv('Task_45_out.csv', index=False)

print(result_df)