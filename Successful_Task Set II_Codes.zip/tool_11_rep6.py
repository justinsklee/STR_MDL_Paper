import pandas as pd

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
sections_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Third floor is at index 2 (0-indexed: ground=0, second=1, third=2)
if len(floor_elevations) < 3:
    print("Model does not have a third floor")
    third_floor_columns = pd.DataFrame(columns=['Element ID', 'Section Name'])
else:
    third_floor_elevation = floor_elevations[2]
    
    # Find all columns that have one node at third floor and another node above third floor
    third_floor_columns = []
    
    for _, element in elements_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2_coords = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a column (vertical element - only z changes, x and y remain same)
        is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                    node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                    node1_coords['Z (m)'] != node2_coords['Z (m)'])
        
        if is_column:
            # Check if one node is at third floor and the other is above
            node1_z = node1_coords['Z (m)']
            node2_z = node2_coords['Z (m)']
            
            if ((node1_z == third_floor_elevation and node2_z > third_floor_elevation) or
                (node2_z == third_floor_elevation and node1_z > third_floor_elevation)):
                
                # Get section name
                section_num = element['Section']
                section_name = sections_df[sections_df['Section Number'] == section_num]['Section Name'].iloc[0]
                
                third_floor_columns.append({
                    'Element ID': element['Element ID'],
                    'Section Name': section_name
                })
    
    # Convert to DataFrame and sort by Element ID
    third_floor_columns_df = pd.DataFrame(third_floor_columns)
    if not third_floor_columns_df.empty:
        third_floor_columns_df = third_floor_columns_df.sort_values('Element ID')

# Save to CSV
third_floor_columns_df.to_csv('Task_11_out.csv', index=False)