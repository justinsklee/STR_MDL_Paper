import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_36_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support nodes
support_nodes = set(support_df['Node'].values)

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check coordinate differences
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    # Classification logic
    if dz > 0 and dx == 0 and dy == 0:
        return 'column'
    elif dz == 0:
        return 'beam'
    else:
        return 'brace'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find columns that share supports with bracing elements
columns_with_braces = set()

for support_node in support_nodes:
    # Get all elements connected to this support node
    elements_at_node = element_df[
        (element_df['Node 1'] == support_node) | 
        (element_df['Node 2'] == support_node)
    ]
    
    # Check if there are both columns and braces at this node
    element_types = set(elements_at_node['element_type'].values)
    
    if 'column' in element_types and 'brace' in element_types:
        # Add all columns at this node to the set
        columns_at_node = elements_at_node[elements_at_node['element_type'] == 'column']['Element ID'].values
        columns_with_braces.update(columns_at_node)

# Update section for columns that share supports with bracing elements
element_df.loc[element_df['Element ID'].isin(columns_with_braces), 'Section'] = 101

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_36_out/Element.csv', index=False)