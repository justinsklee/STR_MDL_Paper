import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_46_out', exist_ok=True)

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify first floor columns along grid X-1
# Columns are vertical elements with change only in z-coordinates
# First floor columns have one node at first floor level and another node above

first_floor_columns_x1 = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_data = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_data = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1_data['X (m)'], node1_data['Y (m)'], node1_data['Z (m)']
    x2, y2, z2 = node2_data['X (m)'], node2_data['Y (m)'], node2_data['Z (m)']
    
    # Check if element is a column (vertical: only z changes, x and y stay same)
    is_column = (x1 == x2) and (y1 == y2) and (z1 != z2)
    
    # Check if column is on X-1 grid
    is_on_x1_grid = (x1 == x1_coord) and (x2 == x1_coord)
    
    # Check if it's a first floor column (one node at z=0, other node above z=0)
    is_first_floor = ((z1 == first_floor_z and z2 > first_floor_z) or 
                     (z2 == first_floor_z and z1 > first_floor_z))
    
    if is_column and is_on_x1_grid and is_first_floor:
        first_floor_columns_x1.append(idx)

# Update section number to 105 and material to 1002 for identified columns
for idx in first_floor_columns_x1:
    element_df.at[idx, 'Section'] = 105
    element_df.at[idx, 'Material'] = 1002

# Save updated Element.csv file
element_df.to_csv('Task_46_out/Element.csv', index=False)