import pandas as pd
import os

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
materials_df = pd.read_csv('Material.csv')

# Create output folder
os.makedirs('Task_25_out', exist_ok=True)

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Third floor is at index 2 (0-based: ground=0, second=1, third=2)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
    
    # Find material number for SS400
    ss400_material = materials_df[materials_df['Name'] == 'SS400']['Material Number'].iloc[0]
    
    # Find third floor columns
    # Columns are vertical elements with one node at third floor and other node above
    third_floor_nodes = nodes_df[nodes_df['Z (m)'] == third_floor_elevation]['Node ID'].tolist()
    
    for idx, row in elements_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = nodes_df[nodes_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = nodes_df[nodes_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Check if element is a column (vertical: same x,y but different z)
        is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                    node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                    node1_coords['Z (m)'] != node2_coords['Z (m)'])
        
        # Check if one node is at third floor and the other is above
        node_at_third_floor = (node1_id in third_floor_nodes and node2_coords['Z (m)'] > third_floor_elevation) or \
                             (node2_id in third_floor_nodes and node1_coords['Z (m)'] > third_floor_elevation)
        
        if is_column and node_at_third_floor:
            elements_df.at[idx, 'Material'] = ss400_material

# Save updated Element.csv
elements_df.to_csv('Task_25_out/Element.csv', index=False)