import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=first, 1=second, 2=third)
third_floor_elevation = floor_elevations[2]

# Find all columns (vertical elements)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical: only z changes, x and y stay same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is at third floor and the other is above
        if ((node1['Z (m)'] == third_floor_elevation and node2['Z (m)'] > third_floor_elevation) or
            (node2['Z (m)'] == third_floor_elevation and node1['Z (m)'] > third_floor_elevation)):
            
            # Get section name
            section_num = element['Section']
            section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
            
            columns.append({
                'Element ID': element['Element ID'],
                'Section Name': section_name
            })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(columns)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_11_out.csv', index=False)

print(result_df)