import pandas as pd
import os

# Create output folder
os.makedirs('Task_26_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation (index 1)
second_floor_elevation = floor_elevations[1]

# Find beams on second floor
# Beams are horizontal elements (no change in Z coordinates between nodes)
second_floor_beams = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates of both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a beam (same Z coordinate) and on second floor
    if (node1_coords['Z (m)'] == node2_coords['Z (m)'] and 
        node1_coords['Z (m)'] == second_floor_elevation):
        second_floor_beams.append(row['Element ID'])

# Update material to SHN355 (material 1003) for second floor beams
for beam_id in second_floor_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Material'] = 1003

# Save updated Element.csv
element_df.to_csv('Task_26_out/Element.csv', index=False)

print(f"Updated {len(second_floor_beams)} second floor beams to material SHN355")
print(f"Second floor beam IDs: {second_floor_beams}")