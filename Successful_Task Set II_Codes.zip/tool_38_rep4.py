import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_38_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Identify first floor (z = 0.0) and second floor elevations
first_floor_z = 0.0
unique_z_values = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z_values[1]  # Next elevation after ground level

# Find grid X-2 coordinate (second X-grid line)
unique_x_values = sorted(node_df['X (m)'].unique())
x2_coordinate = unique_x_values[1]  # Second X-grid coordinate

# Find first floor columns along grid X-2
# Columns are vertical elements with one node at first floor and one node above
first_floor_columns_x2 = []

for idx, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only z changes, x and y same)
    is_column = (node1['X (m)'] == node2['X (m)'] and 
                node1['Y (m)'] == node2['Y (m)'] and 
                node1['Z (m)'] != node2['Z (m)'])
    
    if is_column:
        # Check if column is on grid X-2
        on_grid_x2 = (node1['X (m)'] == x2_coordinate and node2['X (m)'] == x2_coordinate)
        
        if on_grid_x2:
            # Check if one node is at first floor and other is above
            z_values = [node1['Z (m)'], node2['Z (m)']]
            has_first_floor_node = first_floor_z in z_values
            has_above_first_floor_node = any(z > first_floor_z for z in z_values)
            
            if has_first_floor_node and has_above_first_floor_node:
                first_floor_columns_x2.append(element['Element ID'])

# Update material for identified columns
for element_id in first_floor_columns_x2:
    element_df.loc[element_df['Element ID'] == element_id, 'Material'] = shn355_material

# Save updated Element.csv
element_df.to_csv('Task_38_out/Element.csv', index=False)

print(f"Updated {len(first_floor_columns_x2)} first floor columns along grid X-2 to material SHN355")
print(f"Column Element IDs: {first_floor_columns_x2}")