import pandas as pd
import os

# Create output folder
os.makedirs('Task_46_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find the X-coordinate for grid X-1 (minimum X coordinate)
x_grid_1 = node_df['X (m)'].min()

# Find first floor elevation (minimum Z coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find all nodes on grid X-1 at first floor level
grid_x1_first_floor_nodes = node_df[(node_df['X (m)'] == x_grid_1) & (node_df['Z (m)'] == first_floor_z)]['Node ID'].tolist()

# Find columns (vertical elements) that have one node at first floor on grid X-1 and the other node above
first_floor_columns_x1 = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_data = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_data = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only Z changes, X and Y stay same)
    if (node1_data['X (m)'] == node2_data['X (m)'] and 
        node1_data['Y (m)'] == node2_data['Y (m)'] and 
        node1_data['Z (m)'] != node2_data['Z (m)']):
        
        # Check if one node is on grid X-1 at first floor and other is above
        if ((node1_id in grid_x1_first_floor_nodes and node2_data['Z (m)'] > first_floor_z) or
            (node2_id in grid_x1_first_floor_nodes and node1_data['Z (m)'] > first_floor_z)):
            first_floor_columns_x1.append(element['Element ID'])

# Update material and section for identified columns
for element_id in first_floor_columns_x1:
    element_df.loc[element_df['Element ID'] == element_id, 'Material'] = 1002
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = 105

# Save updated Element.csv
element_df.to_csv('Task_46_out/Element.csv', index=False)