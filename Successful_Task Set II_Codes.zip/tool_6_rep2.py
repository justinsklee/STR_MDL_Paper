import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')

# Get office load areas
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Find all nodes involved in office loads
office_nodes = set()
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.update(nodes)

# Find columns that support office loads (columns with bottom node in office load area)
supporting_columns = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if element is a column (vertical - only z changes)
    is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                 node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                 node1_coords['Z (m)'] != node2_coords['Z (m)'])
    
    if is_column:
        # Determine which node is at the bottom (lower z)
        if node1_coords['Z (m)'] < node2_coords['Z (m)']:
            bottom_node = node1
            top_node = node2
        else:
            bottom_node = node2
            top_node = node1
        
        # Check if the top node is in office load area (column supports from below)
        if top_node in office_nodes:
            supporting_columns.append(element_id)

# Create output dataframe
result_df = pd.DataFrame({'Element ID': sorted(supporting_columns)})

# Save to CSV
result_df.to_csv('Task_6_out.csv', index=False)

print("Task completed. Results saved to Task_6_out.csv")
print(f"Found {len(supporting_columns)} columns supporting office loads:")
print(result_df)