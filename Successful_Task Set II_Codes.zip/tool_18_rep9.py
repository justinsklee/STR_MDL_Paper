import pandas as pd
import numpy as np

# Load the Node data
nodes_df = pd.read_csv('Node.csv')

# Get all unique Z coordinates and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Create a DataFrame with the floor elevations
floor_df = pd.DataFrame({
    'Floor Elevation (m)': floor_elevations
})

# Save to CSV file
floor_df.to_csv('Task_18_out.csv', index=False)