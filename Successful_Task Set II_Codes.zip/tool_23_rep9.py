import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_23_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find the section number for H 100x100x6/8
target_section = section_df[section_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_elevation = floor_elevations[0]  # Ground level (z = 0.0m)
second_floor_elevation = floor_elevations[1] if len(floor_elevations) > 1 else first_floor_elevation + 1

# Identify first floor braces
first_floor_braces = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    
    # Check if element is a brace (change in x/y AND z coordinates)
    x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 1e-6
    y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 1e-6
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if it's a first floor brace (one node at first floor, other above)
        node1_at_first_floor = abs(node1_coords['Z (m)'] - first_floor_elevation) < 1e-6
        node2_at_first_floor = abs(node2_coords['Z (m)'] - first_floor_elevation) < 1e-6
        node1_above_first_floor = node1_coords['Z (m)'] > first_floor_elevation
        node2_above_first_floor = node2_coords['Z (m)'] > first_floor_elevation
        
        if (node1_at_first_floor and node2_above_first_floor) or (node2_at_first_floor and node1_above_first_floor):
            first_floor_braces.append(row['Element ID'])

# Update section for first floor braces
for element_id in first_floor_braces:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = target_section

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_23_out/Element.csv', index=False)

print(f"Updated {len(first_floor_braces)} first floor braces with section H 100x100x6/8")
print(f"First floor brace elements: {first_floor_braces}")