import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_48_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (z = 0.0m)
first_floor_z = 0.0

# Get Y-1 grid coordinate (minimum y coordinate)
y1_coord = node_df['Y (m)'].min()

# Find first floor braces along grid Y-1
# Braces are diagonal elements (change in x/y AND z coordinates)
# First floor braces have one node at first floor and other node above

first_floor_braces_y1 = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a brace (diagonal element)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if both nodes are on Y-1 grid
        node1_on_y1 = abs(node1['Y (m)'] - y1_coord) < 1e-6
        node2_on_y1 = abs(node2['Y (m)'] - y1_coord) < 1e-6
        
        if node1_on_y1 and node2_on_y1:
            # Check if one node is at first floor and other is above
            node1_at_first = abs(node1['Z (m)'] - first_floor_z) < 1e-6
            node2_at_first = abs(node2['Z (m)'] - first_floor_z) < 1e-6
            
            node1_above_first = node1['Z (m)'] > first_floor_z
            node2_above_first = node2['Z (m)'] > first_floor_z
            
            if (node1_at_first and node2_above_first) or (node2_at_first and node1_above_first):
                # Check if current section is 101
                if row['Section'] == 101:
                    first_floor_braces_y1.append(idx)

# Update section for identified braces
for idx in first_floor_braces_y1:
    element_df.loc[idx, 'Section'] = 103

# Save updated Element.csv file
element_df.to_csv('Task_48_out/Element.csv', index=False)

print(f"Updated {len(first_floor_braces_y1)} first floor braces along grid Y-1 from section 101 to section 103")