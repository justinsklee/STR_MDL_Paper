import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_21_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation level (index 1)
second_floor_elevation = floor_elevations[1]

# Find columns that have one node at second floor elevation and the other node above
second_floor_columns = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element - only z coordinates change)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        
        # Check if one node is at second floor and the other is above
        node1_z = node1_coords['Z (m)']
        node2_z = node2_coords['Z (m)']
        
        if ((node1_z == second_floor_elevation and node2_z > second_floor_elevation) or
            (node2_z == second_floor_elevation and node1_z > second_floor_elevation)):
            second_floor_columns.append(row['Element ID'])

# Update section for second floor columns
for element_id in second_floor_columns:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = 102

# Save updated Element.csv
element_df.to_csv('Task_21_out/Element.csv', index=False)