import pandas as pd
import numpy as np
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Create output folder
os.makedirs('Task_25_out', exist_ok=True)

# Find all unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0-based indexing: 0=first, 1=second, 2=third)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
    fourth_floor_elevation = floor_elevations[3] if len(floor_elevations) > 3 else None
    
    # Find columns on third floor (one node at third floor, other node above)
    third_floor_columns = []
    
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        node1_z = node1_coords['Z (m)']
        node2_z = node2_coords['Z (m)']
        node1_x = node1_coords['X (m)']
        node2_x = node2_coords['X (m)']
        node1_y = node1_coords['Y (m)']
        node2_y = node2_coords['Y (m)']
        
        # Check if it's a column (vertical element with same x,y coordinates)
        is_column = (node1_x == node2_x and node1_y == node2_y and node1_z != node2_z)
        
        # Check if one node is at third floor and the other is above
        has_third_floor_node = (node1_z == third_floor_elevation or node2_z == third_floor_elevation)
        has_node_above_third = (node1_z > third_floor_elevation or node2_z > third_floor_elevation)
        
        if is_column and has_third_floor_node and has_node_above_third:
            third_floor_columns.append(row['Element ID'])
    
    # Get material number for SS400
    ss400_material = material_df[material_df['Name'] == 'SS400']['Material Number'].iloc[0]
    
    # Update material for third floor columns
    for col_id in third_floor_columns:
        element_df.loc[element_df['Element ID'] == col_id, 'Material'] = ss400_material

# Save updated Element.csv file
element_df.to_csv('Task_25_out/Element.csv', index=False)

print(f"Updated {len(third_floor_columns)} third floor columns with SS400 material")
print(f"Third floor column IDs: {third_floor_columns}")