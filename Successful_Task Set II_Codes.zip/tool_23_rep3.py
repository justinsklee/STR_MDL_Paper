import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_23_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find the section number for H 100x100x6/8
target_section = section_df[section_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Find first floor elevation (minimum z value)
first_floor_z = node_df['Z (m)'].min()

# Find second floor elevation (next unique z value above first floor)
unique_z = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z[1] if len(unique_z) > 1 else first_floor_z + 1

# Identify first floor braces
first_floor_braces = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    node1_x, node1_y, node1_z = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    node2_x, node2_y, node2_z = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if this is a brace (diagonal element with change in x/y AND z coordinates)
    has_xy_change = (node1_x != node2_x) or (node1_y != node2_y)
    has_z_change = (node1_z != node2_z)
    
    if has_xy_change and has_z_change:
        # Check if this is a first floor brace
        # One node should be at first floor, other node should be above first floor
        if ((node1_z == first_floor_z and node2_z > first_floor_z) or 
            (node2_z == first_floor_z and node1_z > first_floor_z)):
            first_floor_braces.append(row['Element ID'])

# Update section for first floor braces
for element_id in first_floor_braces:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = target_section

# Save updated Element.csv
element_df.to_csv('Task_23_out/Element.csv', index=False)