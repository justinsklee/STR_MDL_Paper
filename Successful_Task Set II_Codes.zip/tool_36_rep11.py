import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_36_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get supported node IDs
supported_nodes = set(support_df['Node'].values)

# Identify columns (vertical elements with change only in z-coordinate)
columns = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Identify bracing elements (diagonal elements with change in x/y AND z coordinates)
braces = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is diagonal (brace)
    xy_change = (node1['X (m)'] != node2['X (m)'] or node1['Y (m)'] != node2['Y (m)'])
    z_change = node1['Z (m)'] != node2['Z (m)']
    
    if xy_change and z_change:
        braces.append(row['Element ID'])

# Find columns that share supports with bracing elements
columns_with_shared_supports = []

for col_id in columns:
    col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
    col_nodes = [col_row['Node 1'], col_row['Node 2']]
    
    # Check if any column node is supported
    col_has_support = any(node in supported_nodes for node in col_nodes)
    
    if col_has_support:
        # Check if any bracing element shares a supported node with this column
        for brace_id in braces:
            brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
            brace_nodes = [brace_row['Node 1'], brace_row['Node 2']]
            
            # Check if brace and column share any supported node
            shared_supported_nodes = set(col_nodes) & set(brace_nodes) & supported_nodes
            if shared_supported_nodes:
                columns_with_shared_supports.append(col_id)
                break

# Update section to 101 for columns that share supports with bracing elements
for col_id in columns_with_shared_supports:
    element_df.loc[element_df['Element ID'] == col_id, 'Section'] = 101

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv file
element_df.to_csv('Task_36_out/Element.csv', index=False)