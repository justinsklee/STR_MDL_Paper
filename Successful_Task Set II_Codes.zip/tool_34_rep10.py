import pandas as pd
import os

# Create output folder
os.makedirs('Task_34_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get all nodes that define office load areas
office_nodes = set()
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.update(nodes)

# Find beams that support office loads
# These are beams that connect the nodes defining the office load areas
supporting_beams = set()

for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # Create pairs of consecutive nodes (forming the perimeter of the load area)
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]  # Wrap around to first node
        
        # Find beam connecting these nodes
        beam = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        if not beam.empty:
            supporting_beams.add(beam.iloc[0]['Element ID'])

# Update section numbers for supporting beams
element_df.loc[element_df['Element ID'].isin(supporting_beams), 'Section'] = 101

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_34_out/Element.csv', index=False)