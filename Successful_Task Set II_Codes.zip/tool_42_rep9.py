import pandas as pd
import os

# Create output folder
os.makedirs('Task_42_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get the maximum z-coordinate to identify roof level
max_z = node_df['Z (m)'].max()

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 0.001
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 0.001
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 0.001
    
    if z_change and not (x_change or y_change):
        return 'column'
    elif not z_change:
        return 'beam'
    elif z_change and (x_change or y_change):
        return 'brace'
    else:
        return 'unknown'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Identify roof beams (beams at maximum z-coordinate)
roof_beams = []
for _, row in element_df.iterrows():
    if row['element_type'] == 'beam':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
        node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
        
        if abs(node1_z - max_z) < 0.001 and abs(node2_z - max_z) < 0.001:
            roof_beams.append(row['Element ID'])

# Get all braces
braces = element_df[element_df['element_type'] == 'brace']['Element ID'].tolist()

# Get all nodes connected to braces
nodes_connected_to_braces = set()
for brace_id in braces:
    brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
    nodes_connected_to_braces.add(brace_row['Node 1'])
    nodes_connected_to_braces.add(brace_row['Node 2'])

# Identify roof beams not connected to any braces
roof_beams_not_connected_to_braces = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_node1 = beam_row['Node 1']
    beam_node2 = beam_row['Node 2']
    
    if beam_node1 not in nodes_connected_to_braces and beam_node2 not in nodes_connected_to_braces:
        roof_beams_not_connected_to_braces.append(beam_id)

# Update section to 104 for identified beams
element_df.loc[element_df['Element ID'].isin(roof_beams_not_connected_to_braces), 'Section'] = 104

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Save updated Element.csv
element_df.to_csv('Task_42_out/Element.csv', index=False)

print(f"Updated {len(roof_beams_not_connected_to_braces)} roof beams not connected to braces with section 104")
print(f"Beam IDs updated: {roof_beams_not_connected_to_braces}")