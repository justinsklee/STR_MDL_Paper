import pandas as pd
import os

# Create output folder
os.makedirs('Task_26_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find unique floor elevations
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation (index 1)
if len(floor_elevations) >= 2:
    second_floor_elevation = floor_elevations[1]
else:
    print("Error: Not enough floor elevations found")
    exit()

# Identify beams on second floor
# Beams are horizontal elements (no change in Z coordinates)
# and lie on the same elevation as the floor
beam_elements = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in Z) and on second floor
    if (node1_coords['Z (m)'] == node2_coords['Z (m)'] and 
        node1_coords['Z (m)'] == second_floor_elevation):
        beam_elements.append(row['Element ID'])

# Update material to SHN355 (material 1003) for second floor beams
for element_id in beam_elements:
    element_df.loc[element_df['Element ID'] == element_id, 'Material'] = 1003

# Save updated Element.csv
element_df.to_csv('Task_26_out/Element.csv', index=False)

print(f"Updated {len(beam_elements)} second floor beams to SHN355 material")
print(f"Second floor elevation: {second_floor_elevation}m")
print(f"Updated beam elements: {beam_elements}")