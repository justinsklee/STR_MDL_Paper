import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')
material_df = pd.read_csv('Material.csv')

# Find the second floor elevation (one story above ground level z=0.0)
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor is index 1 (ground is index 0)

# Find Y-1 grid coordinate (minimum Y coordinate)
y_coordinates = sorted(node_df['Y (m)'].unique())
y1_grid_coord = y_coordinates[0]  # Y-1 is the first Y grid

# Get nodes on second floor along Y-1 grid
second_floor_y1_nodes = node_df[
    (node_df['Z (m)'] == second_floor_z) & 
    (node_df['Y (m)'] == y1_grid_coord)
]['Node ID'].tolist()

# Find columns on second floor along Y-1 grid
# Columns have one node on the floor and another node above the floor
columns_on_second_floor_y1 = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element - only Z changes, X and Y same)
    is_column = (node1['X (m)'] == node2['X (m)']) and (node1['Y (m)'] == node2['Y (m)']) and (node1['Z (m)'] != node2['Z (m)'])
    
    if is_column:
        # Check if one node is on second floor Y-1 grid and the other is above
        node1_on_second_floor_y1 = (node1['Z (m)'] == second_floor_z) and (node1['Y (m)'] == y1_grid_coord)
        node2_on_second_floor_y1 = (node2['Z (m)'] == second_floor_z) and (node2['Y (m)'] == y1_grid_coord)
        
        node1_above_second_floor = node1['Z (m)'] > second_floor_z
        node2_above_second_floor = node2['Z (m)'] > second_floor_z
        
        # Column on second floor Y-1 grid: one node on second floor Y-1, other node above
        if (node1_on_second_floor_y1 and node2_above_second_floor) or (node2_on_second_floor_y1 and node1_above_second_floor):
            columns_on_second_floor_y1.append(element)

# Create result dataframe
result_data = []
for element in columns_on_second_floor_y1:
    element_id = element['Element ID']
    section_num = element['Section']
    material_num = element['Material']
    
    # Get section name
    section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
    
    # Get material name
    material_name = material_df[material_df['Material Number'] == material_num]['Name'].iloc[0]
    
    result_data.append({
        'Element ID': element_id,
        'Section Name': section_name,
        'Material Name': material_name
    })

# Create and sort result dataframe
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_45_out.csv', index=False)

print("Results saved to Task_45_out.csv")
print(result_df)