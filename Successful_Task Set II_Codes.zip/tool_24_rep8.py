import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_24_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Find first floor elevation (ground level)
first_floor_z = nodes_df['Z (m)'].min()

# Find second floor elevation
second_floor_z = nodes_df['Z (m)'].unique()
second_floor_z = sorted(second_floor_z)[1]  # Second lowest elevation

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if it's a column (vertical: only z changes)
    if abs(x1 - x2) < 1e-6 and abs(y1 - y2) < 1e-6 and abs(z1 - z2) > 1e-6:
        return 'column'
    # Check if it's a beam (horizontal: no z change)
    elif abs(z1 - z2) < 1e-6:
        return 'beam'
    # Otherwise it's a brace (diagonal: x or y changes AND z changes)
    elif (abs(x1 - x2) > 1e-6 or abs(y1 - y2) > 1e-6) and abs(z1 - z2) > 1e-6:
        return 'brace'
    else:
        return 'unknown'

# Classify all elements
elements_df['element_type'] = elements_df.apply(classify_element, axis=1)

# Find first floor braces (one node at first floor, other node above)
first_floor_braces = []

for idx, row in elements_df.iterrows():
    if row['element_type'] == 'brace':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        z1, z2 = node1['Z (m)'], node2['Z (m)']
        
        # Check if one node is at first floor and other is above
        if (abs(z1 - first_floor_z) < 1e-6 and z2 > first_floor_z) or \
           (abs(z2 - first_floor_z) < 1e-6 and z1 > first_floor_z):
            first_floor_braces.append(row['Element ID'])

# Update material for first floor braces
for element_id in first_floor_braces:
    elements_df.loc[elements_df['Element ID'] == element_id, 'Material'] = 1003

# Drop the temporary classification column
elements_df = elements_df.drop('element_type', axis=1)

# Save updated Element.csv
elements_df.to_csv('Task_24_out/Element.csv', index=False)

print(f"Updated {len(first_floor_braces)} first floor braces with material 1003")
print(f"First floor brace elements: {first_floor_braces}")