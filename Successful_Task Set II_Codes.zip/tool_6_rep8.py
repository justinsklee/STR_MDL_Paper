import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get all nodes that define office load areas
office_nodes = set()
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.update(nodes)

# Find columns supporting office loads
# Columns are vertical elements (only z coordinates change)
# They support loads from BELOW the floor, so we need columns that have one node 
# at the office load nodes and extend downward

supporting_columns = []

for node_id in office_nodes:
    # Get the coordinates of the office load node
    office_node = node_df[node_df['Node ID'] == node_id].iloc[0]
    office_z = office_node['Z (m)']
    office_x = office_node['X (m)']
    office_y = office_node['Y (m)']
    
    # Find columns that have one end at this node and extend below
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates of both nodes
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a column (vertical element)
        x_change = abs(node1['X (m)'] - node2['X (m)']) < 1e-6
        y_change = abs(node1['Y (m)'] - node2['Y (m)']) < 1e-6
        z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
        
        if x_change and y_change and z_change:  # This is a column
            # Check if one node is at the office load location and the other is below
            node1_at_office = (node1_id == node_id)
            node2_at_office = (node2_id == node_id)
            
            if node1_at_office and node2['Z (m)'] < office_z:
                supporting_columns.append(element['Element ID'])
            elif node2_at_office and node1['Z (m)'] < office_z:
                supporting_columns.append(element['Element ID'])

# Remove duplicates and sort
supporting_columns = sorted(list(set(supporting_columns)))

# Create output DataFrame
output_df = pd.DataFrame({'Element ID': supporting_columns})

# Save to CSV
output_df.to_csv('Task_6_out.csv', index=False)