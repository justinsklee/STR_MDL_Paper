import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique Z coordinates and sort them to identify floor levels
unique_z = sorted(node_df['Z (m)'].unique())
first_floor_z = unique_z[0]  # Ground level (z = 0.0m)
second_floor_z = unique_z[1] if len(unique_z) > 1 else None

# Create a dictionary for node coordinates
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Find first floor bracing elements
first_floor_braces = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    if node1_id in node_coords and node2_id in node_coords:
        x1, y1, z1 = node_coords[node1_id]
        x2, y2, z2 = node_coords[node2_id]
        
        # Check if it's a brace (diagonal element with changes in x/y AND z coordinates)
        x_change = abs(x2 - x1) > 1e-6
        y_change = abs(y2 - y1) > 1e-6
        z_change = abs(z2 - z1) > 1e-6
        
        # Brace condition: change in (x or y) AND z coordinates
        is_brace = (x_change or y_change) and z_change
        
        # First floor brace condition: one node at first floor, other node above
        first_floor_brace = False
        if is_brace:
            if (abs(z1 - first_floor_z) < 1e-6 and z2 > first_floor_z) or \
               (abs(z2 - first_floor_z) < 1e-6 and z1 > first_floor_z):
                first_floor_brace = True
        
        if first_floor_brace:
            first_floor_braces.append({
                'Element ID': element['Element ID'],
                'Section': element['Section']
            })

# Create output dataframe and sort by Element ID
output_df = pd.DataFrame(first_floor_braces)
if not output_df.empty:
    output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_13_out.csv', index=False)

print(f"Found {len(first_floor_braces)} first floor bracing elements")
if not output_df.empty:
    print(output_df)
else:
    print("No first floor bracing elements found")