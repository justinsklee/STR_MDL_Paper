import pandas as pd
import os

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_35_out', exist_ok=True)

# Find residential load areas
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that define residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    residential_nodes.update(nodes)

# Find columns that support residential loads (columns attached to residential nodes from below)
columns_supporting_residential = []

for _, element in element_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if this is a column (vertical element - only z changes)
    is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                node1_coords['Z (m)'] != node2_coords['Z (m)'])
    
    if is_column:
        # For columns supporting a floor, one node should be on the floor and the other below
        # Check if the higher node is in residential nodes
        if node1_coords['Z (m)'] > node2_coords['Z (m)']:
            higher_node = node1
        else:
            higher_node = node2
            
        if higher_node in residential_nodes:
            columns_supporting_residential.append(element['Element ID'])

# Update material for columns supporting residential loads to SHN355 (material 1003)
element_df.loc[element_df['Element ID'].isin(columns_supporting_residential), 'Material'] = 1003

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_35_out/Element.csv', index=False)

print(f"Updated {len(columns_supporting_residential)} columns supporting residential loads to SHN355 material")
print(f"Column IDs updated: {sorted(columns_supporting_residential)}")