import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get the maximum z-coordinate (roof level)
max_z = node_df['Z (m)'].max()

# Filter elements that are beams (no change in z-coordinate between nodes)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in z-coordinate)
    if node1_z == node2_z:
        beams.append({
            'Element ID': element['Element ID'],
            'Node 1': node1_id,
            'Node 2': node2_id,
            'Z': node1_z
        })

# Filter roof beams (beams at maximum z-coordinate)
roof_beams = [beam for beam in beams if beam['Z'] == max_z]

# Get all nodes that are connected to columns
column_nodes = set()
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a column (only z-coordinate changes)
    node1_x = node_df[node_df['Node ID'] == node1_id]['X (m)'].iloc[0]
    node1_y = node_df[node_df['Node ID'] == node1_id]['Y (m)'].iloc[0]
    node2_x = node_df[node_df['Node ID'] == node2_id]['X (m)'].iloc[0]
    node2_y = node_df[node_df['Node ID'] == node2_id]['Y (m)'].iloc[0]
    
    if node1_x == node2_x and node1_y == node2_y and node1_z != node2_z:
        column_nodes.add(node1_id)
        column_nodes.add(node2_id)

# Filter roof sub-beams (roof beams not directly connected to columns)
roof_sub_beams = []
for beam in roof_beams:
    if beam['Node 1'] not in column_nodes and beam['Node 2'] not in column_nodes:
        roof_sub_beams.append(beam['Element ID'])

# Sort element IDs in ascending order
roof_sub_beams.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': roof_sub_beams})

# Save to CSV
output_df.to_csv('Task_2_out.csv', index=False)