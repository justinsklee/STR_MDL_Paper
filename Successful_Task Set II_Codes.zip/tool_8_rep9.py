import pandas as pd
import numpy as np

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get supported nodes (nodes with supports)
supported_nodes = set(support_df['Node'].tolist())

# Classify elements into columns, beams, and braces
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check changes in coordinates
    dx = abs(x2 - x1) > 1e-6
    dy = abs(y2 - y1) > 1e-6
    dz = abs(z2 - z1) > 1e-6
    
    if dz and not dx and not dy:
        return 'column'
    elif not dz:
        return 'beam'
    elif dz and (dx or dy):
        return 'brace'
    else:
        return 'unknown'

# Apply classification
element_df['type'] = element_df.apply(classify_element, axis=1)

# Get columns and braces
columns = element_df[element_df['type'] == 'column']
braces = element_df[element_df['type'] == 'brace']

# Find columns that share supports with bracing elements
columns_sharing_supports_with_braces = []

for _, column in columns.iterrows():
    column_nodes = {column['Node 1'], column['Node 2']}
    column_supported_nodes = column_nodes.intersection(supported_nodes)
    
    if column_supported_nodes:  # If column has supported nodes
        # Check if any brace also has nodes at these supported locations
        for _, brace in braces.iterrows():
            brace_nodes = {brace['Node 1'], brace['Node 2']}
            brace_supported_nodes = brace_nodes.intersection(supported_nodes)
            
            # If there's overlap in supported nodes between column and brace
            if column_supported_nodes.intersection(brace_supported_nodes):
                columns_sharing_supports_with_braces.append(column['Element ID'])
                break

# Remove duplicates and sort
columns_sharing_supports_with_braces = sorted(list(set(columns_sharing_supports_with_braces)))

# Create output dataframe
result_df = pd.DataFrame({
    'Element ID': columns_sharing_supports_with_braces
})

# Save to CSV
result_df.to_csv('Task_8_out.csv', index=False)

print(f"Found {len(columns_sharing_supports_with_braces)} columns that share supports with bracing elements")
print(result_df)