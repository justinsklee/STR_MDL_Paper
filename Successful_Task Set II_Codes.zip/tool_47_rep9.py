import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_47_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (minimum z coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find Y-1 grid coordinate (minimum y coordinate)
y1_grid_coord = node_df['Y (m)'].min()

# Find columns on first floor along Y-1 grid with section 101
# Columns are vertical elements (only z changes between nodes)
columns_first_floor_y1 = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    section = element['Section']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only z changes)
    is_column = (node1['X (m)'] == node2['X (m)'] and 
                 node1['Y (m)'] == node2['Y (m)'] and 
                 node1['Z (m)'] != node2['Z (m)'])
    
    # Check if column has section 101
    has_section_101 = (section == 101)
    
    # Check if column is on Y-1 grid (both nodes have same y-coordinate as Y-1 grid)
    on_y1_grid = (node1['Y (m)'] == y1_grid_coord and node2['Y (m)'] == y1_grid_coord)
    
    # Check if column has one node on first floor
    has_first_floor_node = (node1['Z (m)'] == first_floor_z or node2['Z (m)'] == first_floor_z)
    
    if is_column and has_section_101 and on_y1_grid and has_first_floor_node:
        # Find the node on first floor
        if node1['Z (m)'] == first_floor_z:
            first_floor_node = node1_id
        else:
            first_floor_node = node2_id
        columns_first_floor_y1.append(first_floor_node)

# Update support conditions to pin (release rotational constraints)
# Pin support: Dx=1, Dy=1, Dz=1, Rx=0, Ry=0, Rz=0
for node_id in columns_first_floor_y1:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated Support.csv
support_df.to_csv('Task_47_out/Support.csv', index=False)

print(f"Updated support conditions for nodes: {columns_first_floor_y1}")
print("Support.csv saved to Task_47_out/")