import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_38_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Identify first floor elevation (z = 0.0m)
first_floor_z = 0.0

# Find all unique X coordinates to identify grid lines
unique_x_coords = sorted(node_df['X (m)'].unique())

# Identify X-2 grid coordinate (second X coordinate)
x2_coord = unique_x_coords[1] if len(unique_x_coords) > 1 else None

if x2_coord is not None:
    # Find nodes on first floor (z = 0.0) at X-2 grid
    first_floor_nodes_x2 = node_df[(node_df['Z (m)'] == first_floor_z) & 
                                   (node_df['X (m)'] == x2_coord)]['Node ID'].tolist()
    
    # Find columns: elements where one node is on first floor at X-2 and other node is above
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get node coordinates
        node1_data = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_data = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a column (vertical element with same x,y coordinates)
        if (node1_data['X (m)'] == node2_data['X (m)'] and 
            node1_data['Y (m)'] == node2_data['Y (m)'] and
            node1_data['Z (m)'] != node2_data['Z (m)']):
            
            # Check if one node is on first floor at X-2 grid and other is above
            node1_on_first_floor_x2 = (node1_data['Z (m)'] == first_floor_z and 
                                       node1_data['X (m)'] == x2_coord)
            node2_on_first_floor_x2 = (node2_data['Z (m)'] == first_floor_z and 
                                       node2_data['X (m)'] == x2_coord)
            
            node1_above_first = node1_data['Z (m)'] > first_floor_z
            node2_above_first = node2_data['Z (m)'] > first_floor_z
            
            # Column has one node on first floor at X-2 and other node above
            if ((node1_on_first_floor_x2 and node2_above_first) or 
                (node2_on_first_floor_x2 and node1_above_first)):
                element_df.at[idx, 'Material'] = shn355_material

# Save updated Element.csv file
element_df.to_csv('Task_38_out/Element.csv', index=False)