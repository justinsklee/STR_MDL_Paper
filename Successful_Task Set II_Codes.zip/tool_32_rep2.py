import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_32_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
    
    # Find braces on third floor
    # Braces have one node at the floor and another node above the floor
    third_floor_braces = []
    
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        node1_z = node1_coords['Z (m)']
        node2_z = node2_coords['Z (m)']
        node1_x = node1_coords['X (m)']
        node1_y = node1_coords['Y (m)']
        node2_x = node2_coords['X (m)']
        node2_y = node2_coords['Y (m)']
        
        # Check if this is a brace on third floor
        # Brace: changes in (x or y) AND z coordinates
        # One node at third floor, other node above third floor
        has_xy_change = (node1_x != node2_x) or (node1_y != node2_y)
        has_z_change = node1_z != node2_z
        
        if has_xy_change and has_z_change:
            # Check if one node is at third floor and other is above
            if (node1_z == third_floor_elevation and node2_z > third_floor_elevation) or \
               (node2_z == third_floor_elevation and node1_z > third_floor_elevation):
                third_floor_braces.append(idx)
    
    # Update section for third floor braces to 102
    for idx in third_floor_braces:
        element_df.loc[idx, 'Section'] = 102

# Sort by Element ID in ascending order
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv file
element_df.to_csv('Task_32_out/Element.csv', index=False)