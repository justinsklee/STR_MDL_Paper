import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Merge element data with node coordinates for both nodes
element_with_coords = element_df.merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 1', right_on='Node ID', 
    suffixes=('', '_node1')
).merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 2', right_on='Node ID', 
    suffixes=('_node1', '_node2')
)

# Classify elements as braces (diagonal elements)
# Braces have changes in both horizontal (x or y) and vertical (z) coordinates
element_with_coords['dx'] = abs(element_with_coords['X (m)_node2'] - element_with_coords['X (m)_node1'])
element_with_coords['dy'] = abs(element_with_coords['Y (m)_node2'] - element_with_coords['Y (m)_node1'])
element_with_coords['dz'] = abs(element_with_coords['Z (m)_node2'] - element_with_coords['Z (m)_node1'])

# Braces: change in z AND change in (x or y)
braces = element_with_coords[
    (element_with_coords['dz'] > 0) & 
    ((element_with_coords['dx'] > 0) | (element_with_coords['dy'] > 0))
]

# Get brace element IDs
brace_element_ids = set(braces['Element ID'].tolist())

# Get element IDs that have beam-end-release
released_element_ids = set(beam_end_release_df['Element ID'].tolist())

# Find braces that are NOT beam-end-released
braces_not_released = sorted(list(brace_element_ids - released_element_ids))

# Create output dataframe
output_df = pd.DataFrame({'Element ID': braces_not_released})

# Save to CSV
output_df.to_csv('Task_9_out.csv', index=False)