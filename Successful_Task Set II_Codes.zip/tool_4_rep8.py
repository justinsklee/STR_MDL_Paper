import pandas as pd

# Load the relevant CSV files
element_df = pd.read_csv('Element.csv')
section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find section number for H 175x175x7.5/11
target_section = section_df[section_df['Section Name'] == 'H 175x175x7.5/11']['Section Number'].iloc[0]

# Get elements with the target section
elements_with_target_section = element_df[element_df['Section'] == target_section]

# Identify columns (vertical elements - change in ONLY 'z' coordinates)
columns = []
for _, element in elements_with_target_section.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only z-coordinate changes)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    if z_change and not x_change and not y_change:
        columns.append(element['Element ID'])

# Sort element IDs in ascending order
columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': columns})

# Save to CSV file
output_df.to_csv('Task_4_out.csv', index=False)