import pandas as pd

# Load CSV files
floor_load_df = pd.read_csv('Floor_Load.csv')
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Extract beam elements supporting residential loads
supporting_beams = []

for _, load in residential_loads.iterrows():
    # Parse nodes from the loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create beam connections for the 4-node area: (n1,n2), (n2,n3), (n3,n4), (n4,n1)
    beam_connections = [
        (nodes[0], nodes[1]),
        (nodes[1], nodes[2]), 
        (nodes[2], nodes[3]),
        (nodes[3], nodes[0])
    ]
    
    # Find elements that match these beam connections
    for node1, node2 in beam_connections:
        # Check both directions since beam can be defined either way
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            # Verify it's a beam (horizontal element - same z coordinates)
            n1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
            n2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
            
            if n1_z == n2_z:  # Beam condition
                supporting_beams.append(element['Element ID'])

# Remove duplicates and sort
supporting_beams = sorted(list(set(supporting_beams)))

# Create output dataframe
output_df = pd.DataFrame({'Element ID': supporting_beams})

# Save to CSV
output_df.to_csv('Task_5_out.csv', index=False)