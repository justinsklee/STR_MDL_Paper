import pandas as pd
import os

# Create output folder
os.makedirs('Task_33_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Find X-3 grid coordinate (third unique X coordinate)
unique_x_coords = sorted(nodes_df['X (m)'].unique())
x3_coord = unique_x_coords[2] if len(unique_x_coords) > 2 else None

if x3_coord is not None:
    # Find braces along grid X-3
    braces_x3 = []
    
    for _, element in elements_df.iterrows():
        element_id = element['Element ID']
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get node coordinates
        node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        # Check if element is on grid X-3 (both nodes have same X coordinate as X-3)
        if node1['X (m)'] == x3_coord and node2['X (m)'] == x3_coord:
            # Check if it's a brace (diagonal element with change in both horizontal and vertical coordinates)
            x_change = abs(node2['X (m)'] - node1['X (m)'])
            y_change = abs(node2['Y (m)'] - node1['Y (m)'])
            z_change = abs(node2['Z (m)'] - node1['Z (m)'])
            
            # Brace: change in (x or y) coordinates AND z coordinates
            if (x_change > 0 or y_change > 0) and z_change > 0:
                braces_x3.append(element_id)
    
    # Remove beam-end-release for braces along grid X-3
    beam_end_release_df = beam_end_release_df[~beam_end_release_df['Element ID'].isin(braces_x3)]
    
    # Sort by Element ID in ascending order
    beam_end_release_df = beam_end_release_df.sort_values('Element ID').reset_index(drop=True)

# Save updated beam end release file
beam_end_release_df.to_csv('Task_33_out/Beam_end_release.csv', index=False)