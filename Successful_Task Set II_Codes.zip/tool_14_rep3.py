import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
material_df = pd.read_csv('Material.csv')
node_df = pd.read_csv('Node.csv')

# Find the maximum Z coordinate to identify the roof level
max_z = node_df['Z (m)'].max()

# Get all beams (elements where both nodes have the same Z coordinate and no change in Z)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in Z coordinate)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append({
            'Element ID': element['Element ID'],
            'Material': element['Material'],
            'Z_level': node1['Z (m)']
        })

# Filter for roof beams (beams at the maximum Z level)
roof_beams = [beam for beam in beams if beam['Z_level'] == max_z]

# Get material names
result_data = []
for beam in roof_beams:
    material_info = material_df[material_df['Material Number'] == beam['Material']]
    material_name = material_info['Name'].iloc[0] if not material_info.empty else 'Unknown'
    
    result_data.append({
        'Element ID': beam['Element ID'],
        'Material Name': material_name
    })

# Sort by Element ID
result_data = sorted(result_data, key=lambda x: x['Element ID'])

# Create DataFrame and save to CSV
result_df = pd.DataFrame(result_data)
result_df.to_csv('Task_14_out.csv', index=False)

print(f"Found {len(result_data)} roof beams")
print(result_df)