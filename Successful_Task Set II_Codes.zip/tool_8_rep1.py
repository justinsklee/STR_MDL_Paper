import pandas as pd

# Load all relevant CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get supported node IDs
supported_nodes = set(support_df['Node'].tolist())

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check for changes in coordinates
    x_change = abs(x2 - x1) > 1e-6
    y_change = abs(y2 - y1) > 1e-6
    z_change = abs(z2 - z1) > 1e-6
    
    if z_change and not x_change and not y_change:
        return 'Column'
    elif not z_change:
        return 'Beam'
    elif z_change and (x_change or y_change):
        return 'Brace'
    else:
        return 'Unknown'

# Classify all elements
elements_df['Element_Type'] = elements_df.apply(classify_element, axis=1)

# Get columns and braces
columns = elements_df[elements_df['Element_Type'] == 'Column']
braces = elements_df[elements_df['Element_Type'] == 'Brace']

# Find columns that share supports with bracing elements
columns_sharing_supports = []

for _, column in columns.iterrows():
    column_nodes = {column['Node 1'], column['Node 2']}
    column_supported_nodes = column_nodes.intersection(supported_nodes)
    
    if column_supported_nodes:
        # Check if any brace also uses these supported nodes
        for _, brace in braces.iterrows():
            brace_nodes = {brace['Node 1'], brace['Node 2']}
            brace_supported_nodes = brace_nodes.intersection(supported_nodes)
            
            # If there's overlap in supported nodes between column and brace
            if column_supported_nodes.intersection(brace_supported_nodes):
                columns_sharing_supports.append(column['Element ID'])
                break

# Remove duplicates and sort
columns_sharing_supports = sorted(list(set(columns_sharing_supports)))

# Create output dataframe
output_df = pd.DataFrame({
    'Element ID': columns_sharing_supports
})

# Save to CSV
output_df.to_csv('Task_8_out.csv', index=False)

print(f"Found {len(columns_sharing_supports)} columns sharing supports with bracing elements")
print(output_df)