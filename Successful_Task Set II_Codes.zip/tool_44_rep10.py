import pandas as pd
import numpy as np
import os

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_44_out', exist_ok=True)

# Find the top floor elevation
max_z = node_df['Z (m)'].max()

# Identify beams on the top floor
# Beams are horizontal elements (no change in z coordinates between nodes)
top_floor_beams = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates of both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in z coordinates)
    if node1['Z (m)'] == node2['Z (m)']:
        # Check if it's on the top floor
        if node1['Z (m)'] == max_z:
            # Calculate length
            length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                           (node2['Y (m)'] - node1['Y (m)'])**2 + 
                           (node2['Z (m)'] - node1['Z (m)'])**2)
            
            # Check if length is longer than 1.65 meters
            if length > 1.65:
                top_floor_beams.append(idx)

# Update section numbers for qualifying beams
for idx in top_floor_beams:
    element_df.at[idx, 'Section'] = 105

# Save updated Element.csv file
element_df.to_csv('Task_44_out/Element.csv', index=False)