import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Function to calculate element length
def calculate_length(node1_id, node2_id, node_df):
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = node2['X (m)'] - node1['X (m)']
    dy = node2['Y (m)'] - node1['Y (m)']
    dz = node2['Z (m)'] - node1['Z (m)']
    
    length = np.sqrt(dx**2 + dy**2 + dz**2)
    return round(length, 4)

# Function to check if element is a beam (no change in Z coordinates)
def is_beam(element_row, node_df):
    node1_id = element_row['Node 1']
    node2_id = element_row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    return node1['Z (m)'] == node2['Z (m)']

# Get all beams supporting office loads
supporting_beams = []

for _, office_load in office_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = office_load['Nodes for Loading Area']
    nodes_list = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create beam connections for the 4-node area: (n1,n2), (n2,n3), (n3,n4), (n4,n1)
    beam_connections = [
        (nodes_list[0], nodes_list[1]),
        (nodes_list[1], nodes_list[2]),
        (nodes_list[2], nodes_list[3]),
        (nodes_list[3], nodes_list[0])
    ]
    
    # Find elements that match these beam connections
    for node1, node2 in beam_connections:
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            if is_beam(element, node_df):
                length = calculate_length(element['Node 1'], element['Node 2'], node_df)
                supporting_beams.append({
                    'Element ID': element['Element ID'],
                    'Section': element['Section'],
                    'Length (m)': length
                })

# Remove duplicates and sort by Element ID
supporting_beams_df = pd.DataFrame(supporting_beams).drop_duplicates().sort_values('Element ID')

# Save to CSV
supporting_beams_df.to_csv('Task_50_out.csv', index=False)

print(supporting_beams_df)