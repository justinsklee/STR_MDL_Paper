import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_30_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Fourth floor is at index 3 (0-indexed: ground=0, 2nd=1, 3rd=2, 4th=3)
if len(floor_elevations) >= 4:
    fourth_floor_elevation = floor_elevations[3]
    
    # Function to classify elements
    def classify_element(row):
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
        x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
        
        # Check if element is a brace (diagonal: change in x or y AND change in z)
        x_change = abs(x2 - x1) > 1e-6
        y_change = abs(y2 - y1) > 1e-6
        z_change = abs(z2 - z1) > 1e-6
        
        if (x_change or y_change) and z_change:
            return 'brace'
        elif z_change and not (x_change or y_change):
            return 'column'
        elif not z_change:
            return 'beam'
        else:
            return 'unknown'
    
    # Add element classification
    element_df['element_type'] = element_df.apply(classify_element, axis=1)
    
    # Identify braces on fourth floor (one node on fourth floor, other node above)
    braces_to_remove = []
    
    for idx, row in element_df.iterrows():
        if row['element_type'] == 'brace':
            node1_id = row['Node 1']
            node2_id = row['Node 2']
            
            node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
            node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
            
            # Check if one node is on fourth floor and other is above
            if (abs(node1_z - fourth_floor_elevation) < 1e-6 and node2_z > fourth_floor_elevation) or \
               (abs(node2_z - fourth_floor_elevation) < 1e-6 and node1_z > fourth_floor_elevation):
                braces_to_remove.append(row['Element ID'])
    
    # Remove braces on fourth floor
    element_df_updated = element_df[~element_df['Element ID'].isin(braces_to_remove)]
    
    # Remove the temporary classification column
    element_df_updated = element_df_updated.drop('element_type', axis=1)
    
    # Sort by Element ID
    element_df_updated = element_df_updated.sort_values('Element ID').reset_index(drop=True)
    
    # Save updated Element.csv
    element_df_updated.to_csv('Task_30_out/Element.csv', index=False)
    
    print(f"Removed {len(braces_to_remove)} braces on fourth floor (elevation {fourth_floor_elevation}m)")
    if braces_to_remove:
        print(f"Removed brace elements: {braces_to_remove}")
else:
    print("Model does not have a fourth floor")