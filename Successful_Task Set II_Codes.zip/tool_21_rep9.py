import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_21_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation level (index 1)
second_floor_elevation = floor_elevations[1]

# Find all columns (vertical elements)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical: only z changes, x and y stay same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append({
            'element_id': element['Element ID'],
            'node1_z': node1['Z (m)'],
            'node2_z': node2['Z (m)']
        })

# Find second floor columns (columns with one node at second floor elevation and other node above)
second_floor_columns = []
for col in columns:
    # Check if one node is at second floor and the other is above
    if ((col['node1_z'] == second_floor_elevation and col['node2_z'] > second_floor_elevation) or
        (col['node2_z'] == second_floor_elevation and col['node1_z'] > second_floor_elevation)):
        second_floor_columns.append(col['element_id'])

# Update section for second floor columns
for element_id in second_floor_columns:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = 102

# Save updated Element.csv
element_df.to_csv('Task_21_out/Element.csv', index=False)

print(f"Updated {len(second_floor_columns)} second floor columns to section 102")
print(f"Second floor column IDs: {second_floor_columns}")