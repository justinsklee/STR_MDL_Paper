import pandas as pd
import os

# Create output folder
os.makedirs('Task_26_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find second floor elevation (one floor above ground level z=0.0)
unique_z = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z[1]  # Second floor is the second unique z-coordinate

# Get nodes at second floor elevation
second_floor_nodes = node_df[node_df['Z (m)'] == second_floor_z]['Node ID'].tolist()

# Identify beams at second floor (both nodes at same elevation = second floor)
second_floor_beams = []
for idx, row in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == row['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == row['Node 2']]['Z (m)'].iloc[0]
    
    # Beam: both nodes at same elevation AND at second floor
    if node1_z == node2_z == second_floor_z:
        second_floor_beams.append(row['Element ID'])

# Update material to SHN355 (material 1003) for second floor beams
element_df.loc[element_df['Element ID'].isin(second_floor_beams), 'Material'] = 1003

# Save updated Element.csv
element_df.to_csv('Task_26_out/Element.csv', index=False)

print(f"Updated {len(second_floor_beams)} second floor beams to SHN355 material")
print(f"Second floor beam IDs: {second_floor_beams}")