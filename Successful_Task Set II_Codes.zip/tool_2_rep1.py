import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and find the roof level
floor_elevations = sorted(node_df['Z (m)'].unique())
roof_elevation = max(floor_elevations)

# Identify columns (vertical elements with same x,y coordinates but different z)
columns = []
for _, row in element_df.iterrows():
    node1_coords = node_df[node_df['Node ID'] == row['Node 1']][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == row['Node 2']][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    
    # Check if it's a column (same x,y but different z)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        columns.append(row['Element ID'])

# Identify beams at roof level (horizontal elements with same z coordinates at roof elevation)
roof_beams = []
for _, row in element_df.iterrows():
    node1_coords = node_df[node_df['Node ID'] == row['Node 1']][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == row['Node 2']][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    
    # Check if it's a beam at roof level (same z coordinates at roof elevation)
    if (node1_coords['Z (m)'] == node2_coords['Z (m)'] and 
        node1_coords['Z (m)'] == roof_elevation):
        roof_beams.append(row['Element ID'])

# Find roof sub-beams (beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_nodes = [beam_row['Node 1'], beam_row['Node 2']]
    
    # Check if this beam is connected to any column
    connected_to_column = False
    for col_id in columns:
        col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
        col_nodes = [col_row['Node 1'], col_row['Node 2']]
        
        # Check if beam shares any node with column
        if any(node in col_nodes for node in beam_nodes):
            connected_to_column = True
            break
    
    # If not connected to any column, it's a sub-beam
    if not connected_to_column:
        roof_sub_beams.append(beam_id)

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(roof_sub_beams)})

# Save to CSV
output_df.to_csv('Task_2_out.csv', index=False)

print(f"Roof sub-beam elements: {sorted(roof_sub_beams)}")