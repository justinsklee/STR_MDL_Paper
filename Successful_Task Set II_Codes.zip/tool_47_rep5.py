import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_47_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (minimum z-coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find Y-1 grid coordinate (minimum y-coordinate)
y1_grid_coord = node_df['Y (m)'].min()

# Find first floor columns along grid Y-1 with section 101
# First, identify all columns (vertical elements)
columns = []
for _, elem in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == elem['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == elem['Node 2']].iloc[0]
    
    # Check if it's a column (vertical element - only z changes, x and y stay same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(elem)

# Filter for first floor columns along Y-1 grid with section 101
target_columns = []
for column in columns:
    node1 = node_df[node_df['Node ID'] == column['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == column['Node 2']].iloc[0]
    
    # Check if column has one node at first floor and other above
    nodes_z = [node1['Z (m)'], node2['Z (m)']]
    if first_floor_z in nodes_z and max(nodes_z) > first_floor_z:
        # Check if column is on Y-1 grid
        if node1['Y (m)'] == y1_grid_coord and node2['Y (m)'] == y1_grid_coord:
            # Check if section is 101
            if column['Section'] == 101:
                target_columns.append(column)

# Find nodes at first floor for these columns
target_nodes = []
for column in target_columns:
    node1 = node_df[node_df['Node ID'] == column['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == column['Node 2']].iloc[0]
    
    # Get the node at first floor level
    if node1['Z (m)'] == first_floor_z:
        target_nodes.append(column['Node 1'])
    elif node2['Z (m)'] == first_floor_z:
        target_nodes.append(column['Node 2'])

# Update support conditions to pin (release rotational constraints)
# Pin support: Dx=1, Dy=1, Dz=1, Rx=0, Ry=0, Rz=0
for node_id in target_nodes:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated Support.csv
support_df.to_csv('Task_47_out/Support.csv', index=False)