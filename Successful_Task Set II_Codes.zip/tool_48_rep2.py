import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_48_out', exist_ok=True)

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find Y-1 grid coordinate (first Y grid line)
y_coords = sorted(node_df['Y (m)'].unique())
y1_coord = y_coords[0]

# Find braces on first floor along grid Y-1
# Braces: elements with change in both (x or y) AND z coordinates
# First floor braces: one node at first floor (z=0), other node above first floor
braces_to_update = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on Y-1 grid
    if node1['Y (m)'] == y1_coord and node2['Y (m)'] == y1_coord:
        # Check if it's a brace (change in x or y AND z coordinates)
        x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
        y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
        z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
        
        if (x_change or y_change) and z_change:
            # Check if it's a first floor brace (one node at z=0, other above)
            z_values = [node1['Z (m)'], node2['Z (m)']]
            if first_floor_z in z_values and any(z > first_floor_z for z in z_values):
                # Check if current section is 101
                if row['Section'] == 101:
                    braces_to_update.append(idx)

# Update section for identified braces
for idx in braces_to_update:
    element_df.at[idx, 'Section'] = 103

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_48_out/Element.csv', index=False)