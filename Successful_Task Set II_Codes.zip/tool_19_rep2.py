import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create a dictionary for quick node lookup
node_dict = {}
for _, row in node_df.iterrows():
    node_dict[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Function to classify elements and calculate lengths
def classify_and_calculate_length(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    x1, y1, z1 = node_dict[node1_id]
    x2, y2, z2 = node_dict[node2_id]
    
    # Calculate length
    length = np.sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)
    
    # Classify element
    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    dz = abs(z2 - z1)
    
    if dz > 1e-6 and (dx < 1e-6 and dy < 1e-6):  # Column: only z changes
        element_type = 'Column'
    elif dz < 1e-6:  # Beam: no z change
        element_type = 'Beam'
    else:  # Brace: z changes with x or y
        element_type = 'Brace'
    
    return element_type, length

# Calculate element types and lengths
element_data = []
for _, row in element_df.iterrows():
    element_type, length = classify_and_calculate_length(row)
    element_data.append({
        'Element ID': row['Element ID'],
        'Type': element_type,
        'Length': length
    })

# Create DataFrame
element_analysis_df = pd.DataFrame(element_data)

# Filter beams shorter than 1.3m
short_beams = element_analysis_df[
    (element_analysis_df['Type'] == 'Beam') & 
    (element_analysis_df['Length'] < 1.3)
].copy()

# Sort by Element ID and select required columns
result_df = short_beams[['Element ID', 'Length']].sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_19_out.csv', index=False)

print(result_df)