import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get the maximum Z coordinate (roof level)
max_z = node_df['Z (m)'].max()

# Filter elements that are beams (no change in Z coordinates between nodes)
beams = []
for _, element in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
    
    # Check if it's a beam (horizontal element - no change in Z)
    if node1_z == node2_z:
        beams.append(element['Element ID'])

# Filter beams that are at roof level (maximum Z coordinate)
roof_beams = []
for beam_id in beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    
    if node1_z == max_z:
        roof_beams.append(beam_id)

# Get all columns (vertical elements)
columns = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if it's a column (vertical element - change only in Z)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Get nodes that are connected to columns
column_nodes = set()
for col_id in columns:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    column_nodes.add(element['Node 1'])
    column_nodes.add(element['Node 2'])

# Filter roof beams to find sub-beams (not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Check if neither node is connected to a column
    if node1 not in column_nodes and node2 not in column_nodes:
        roof_sub_beams.append(beam_id)

# Sort in ascending order
roof_sub_beams.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': roof_sub_beams})

# Save to CSV
output_df.to_csv('Task_2_out.csv', index=False)

print(f"Roof sub-beam element numbers: {roof_sub_beams}")