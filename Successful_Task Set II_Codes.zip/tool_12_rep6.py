import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes from residential load areas
residential_nodes = []
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    residential_nodes.extend(nodes)

residential_nodes = list(set(residential_nodes))  # Remove duplicates

# Find beams that connect these nodes (beams have same Z coordinate for both nodes)
supporting_beams = []

for _, element in element_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Check if both nodes are in residential load areas
    if node1 in residential_nodes and node2 in residential_nodes:
        supporting_beams.append({
            'Element ID': element['Element ID'],
            'Section': element['Section']
        })

# Convert to DataFrame
result_df = pd.DataFrame(supporting_beams)

# Get section names from Long_Section.csv
result_df = result_df.merge(long_section_df[['Section Number', 'Section Name']], 
                           left_on='Section', right_on='Section Number', how='left')

# Select only required columns and rename
final_result = result_df[['Element ID', 'Section Name']].copy()
final_result.columns = ['Element Number', 'Section Name']

# Sort by Element Number
final_result = final_result.sort_values('Element Number').reset_index(drop=True)

# Save to CSV
final_result.to_csv('Task_12_out.csv', index=False)

print("Results saved to Task_12_out.csv")
print(final_result)