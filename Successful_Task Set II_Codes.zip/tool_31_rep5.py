import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is index 2 (0=ground, 1=second, 2=third)
third_floor_elevation = floor_elevations[2]

# Find all beams on third floor (elements where both nodes have same Z coordinate as third floor)
third_floor_beams = []
for _, element in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
    
    # Check if it's a beam (horizontal element on third floor)
    if node1_z == node2_z == third_floor_elevation:
        third_floor_beams.append(element['Element ID'])

# Find columns (vertical elements with one node on third floor)
columns_on_third_floor = set()
for _, element in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
    
    # Check if it's a column with one node on third floor
    if (node1_z == third_floor_elevation and node2_z != third_floor_elevation) or \
       (node2_z == third_floor_elevation and node1_z != third_floor_elevation):
        # Get the node on third floor
        if node1_z == third_floor_elevation:
            columns_on_third_floor.add(element['Node 1'])
        else:
            columns_on_third_floor.add(element['Node 2'])

# Find sub-beams (beams not directly connected to columns)
third_floor_sub_beams = []
for beam_id in third_floor_beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Check if either node is connected to a column
    if node1 not in columns_on_third_floor and node2 not in columns_on_third_floor:
        third_floor_sub_beams.append(beam_id)

# Create release status for sub-beams
result_data = []
for beam_id in sorted(third_floor_sub_beams):
    # Check if beam has release in beam_end_release_df
    if beam_id in beam_end_release_df['Element ID'].values:
        release_info = beam_end_release_df[beam_end_release_df['Element ID'] == beam_id].iloc[0]
        i_end = 0 if release_info['i-end release'] == 11 else 1
        j_end = 0 if release_info['j-end release'] == 11 else 1
    else:
        # No release = fixed
        i_end = 1
        j_end = 1
    
    result_data.append({
        'Element ID': beam_id,
        'i-end': i_end,
        'j-end': j_end
    })

# Create DataFrame and save to CSV
result_df = pd.DataFrame(result_data)
result_df.to_csv('Task_31_out.csv', index=False)