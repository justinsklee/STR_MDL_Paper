import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_47_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find the first floor elevation (minimum z-coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find Y-1 grid coordinate (minimum y-coordinate)
y1_grid_coord = node_df['Y (m)'].min()

# Find first floor columns along grid Y-1 with section 101
# Columns are vertical elements with change only in z-coordinates
first_floor_columns_y1 = []

for idx, row in element_df.iterrows():
    if row['Section'] == 101:  # Section 101
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if it's a column (vertical element)
        x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)'])
        y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)'])
        z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)'])
        
        is_column = (x_change < 1e-6 and y_change < 1e-6 and z_change > 1e-6)
        
        if is_column:
            # Check if both nodes are on Y-1 grid
            node1_on_y1 = abs(node1_coords['Y (m)'] - y1_grid_coord) < 1e-6
            node2_on_y1 = abs(node2_coords['Y (m)'] - y1_grid_coord) < 1e-6
            
            if node1_on_y1 and node2_on_y1:
                # Check if one node is on first floor
                node1_on_first_floor = abs(node1_coords['Z (m)'] - first_floor_z) < 1e-6
                node2_on_first_floor = abs(node2_coords['Z (m)'] - first_floor_z) < 1e-6
                
                if node1_on_first_floor or node2_on_first_floor:
                    # This is a first floor column on Y-1 grid
                    # Find the node that's on the first floor (bottom of column)
                    if node1_on_first_floor:
                        first_floor_columns_y1.append(node1_id)
                    if node2_on_first_floor:
                        first_floor_columns_y1.append(node2_id)

# Remove duplicates
first_floor_columns_y1 = list(set(first_floor_columns_y1))

# Update support conditions to pin (release rotations: Rx=0, Ry=0, Rz=0)
for node_id in first_floor_columns_y1:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated Support.csv
support_df.to_csv('Task_47_out/Support.csv', index=False)

print(f"Updated support conditions for {len(first_floor_columns_y1)} first floor columns along grid Y-1 with section 101")
print(f"Affected nodes: {sorted(first_floor_columns_y1)}")