import pandas as pd

# Load the Support.csv file
support_df = pd.read_csv('Support.csv')

# Create output dataframe with support information
output_df = support_df.copy()

# Save to CSV file
output_df.to_csv('Task_16_out.csv', index=False)