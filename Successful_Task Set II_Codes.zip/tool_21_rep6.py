import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_21_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Find second floor elevation (index 1 since ground is index 0)
if len(floor_elevations) >= 2:
    second_floor_elevation = floor_elevations[1]
else:
    print("Not enough floors in the model")
    exit()

# Find columns that have one node at second floor and another node above
second_floor_columns = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coord = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coord = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a column (vertical element - only Z changes, X and Y stay same)
    if (node1_coord['X (m)'] == node2_coord['X (m)'] and 
        node1_coord['Y (m)'] == node2_coord['Y (m)'] and 
        node1_coord['Z (m)'] != node2_coord['Z (m)']):
        
        # Check if one node is at second floor and the other is above
        z1, z2 = node1_coord['Z (m)'], node2_coord['Z (m)']
        if (z1 == second_floor_elevation and z2 > second_floor_elevation) or \
           (z2 == second_floor_elevation and z1 > second_floor_elevation):
            second_floor_columns.append(row['Element ID'])

# Update section for second floor columns
for element_id in second_floor_columns:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = 102

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Updated {len(second_floor_columns)} second floor columns to section 102")
print(f"Column IDs updated: {second_floor_columns}")