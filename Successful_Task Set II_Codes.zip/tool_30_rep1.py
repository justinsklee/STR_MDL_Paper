import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_30_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Fourth floor is at index 3 (0-indexed: ground=0, 2nd=1, 3rd=2, 4th=3)
if len(floor_elevations) >= 4:
    fourth_floor_elevation = floor_elevations[3]
    
    # Find nodes on fourth floor and above
    fourth_floor_nodes = set(nodes_df[nodes_df['Z (m)'] == fourth_floor_elevation]['Node ID'])
    above_fourth_floor_nodes = set(nodes_df[nodes_df['Z (m)'] > fourth_floor_elevation]['Node ID'])
    
    # Identify braces on fourth floor
    braces_to_remove = []
    
    for idx, row in elements_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = nodes_df[nodes_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = nodes_df[nodes_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Check if element is a brace (diagonal: changes in x/y AND z coordinates)
        x_change = node1_coords['X (m)'] != node2_coords['X (m)']
        y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        
        is_brace = (x_change or y_change) and z_change
        
        # Check if brace is on fourth floor (one node on fourth floor, other above)
        if is_brace:
            if ((node1_id in fourth_floor_nodes and node2_id in above_fourth_floor_nodes) or 
                (node2_id in fourth_floor_nodes and node1_id in above_fourth_floor_nodes)):
                braces_to_remove.append(row['Element ID'])
    
    # Remove braces on fourth floor
    elements_df_updated = elements_df[~elements_df['Element ID'].isin(braces_to_remove)]
    
    # Save updated Element.csv
    elements_df_updated.to_csv('Task_30_out/Element.csv', index=False)
    
    print(f"Removed {len(braces_to_remove)} braces from fourth floor")
    if braces_to_remove:
        print(f"Removed element IDs: {braces_to_remove}")
else:
    print("Model does not have a fourth floor")
    # Save original file if no fourth floor exists
    elements_df.to_csv('Task_30_out/Element.csv', index=False)