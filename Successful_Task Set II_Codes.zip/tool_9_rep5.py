import pandas as pd

# Load all relevant CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Merge elements with node coordinates to get start and end coordinates
elements_with_coords = elements_df.merge(nodes_df, left_on='Node 1', right_on='Node ID', suffixes=('', '_start'))
elements_with_coords = elements_with_coords.merge(nodes_df, left_on='Node 2', right_on='Node ID', suffixes=('', '_end'))

# Classify elements as braces (diagonal elements: change in x/y AND z coordinates)
elements_with_coords['dx'] = abs(elements_with_coords['X (m)_end'] - elements_with_coords['X (m)'])
elements_with_coords['dy'] = abs(elements_with_coords['Y (m)_end'] - elements_with_coords['Y (m)'])
elements_with_coords['dz'] = abs(elements_with_coords['Z (m)_end'] - elements_with_coords['Z (m)'])

# Braces: change in (x or y) AND z coordinates
braces = elements_with_coords[
    ((elements_with_coords['dx'] > 0) | (elements_with_coords['dy'] > 0)) & 
    (elements_with_coords['dz'] > 0)
]

# Get brace element IDs
brace_element_ids = set(braces['Element ID'].tolist())

# Get element IDs that have beam-end-release
released_element_ids = set(beam_end_release_df['Element ID'].tolist())

# Find braces that are NOT beam-end-released
braces_not_released = brace_element_ids - released_element_ids

# Create output dataframe
result_df = pd.DataFrame({
    'Element ID': sorted(list(braces_not_released))
})

# Save to CSV
result_df.to_csv('Task_9_out.csv', index=False)