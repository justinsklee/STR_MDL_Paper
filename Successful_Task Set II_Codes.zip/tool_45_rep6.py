import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')
material_df = pd.read_csv('Material.csv')

# Find the second floor elevation (one story above ground level)
unique_z = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z[1]  # Second floor is index 1 (ground is index 0)

# Find Y-1 grid coordinate (minimum Y coordinate)
y1_coord = node_df['Y (m)'].min()

# Filter nodes on second floor at Y-1 grid
second_floor_y1_nodes = node_df[
    (node_df['Z (m)'] == second_floor_z) & 
    (node_df['Y (m)'] == y1_coord)
]['Node ID'].tolist()

# Find columns on second floor along Y-1 grid
# Columns are vertical elements with one node on second floor and other node above
columns_on_second_floor_y1 = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is on second floor Y-1 grid and other is above
        if ((node1_id in second_floor_y1_nodes and node2['Z (m)'] > second_floor_z) or
            (node2_id in second_floor_y1_nodes and node1['Z (m)'] > second_floor_z)):
            columns_on_second_floor_y1.append(element)

# Create result dataframe
result_data = []
for element in columns_on_second_floor_y1:
    # Get section name
    section_num = element['Section']
    section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
    
    # Get material name
    material_num = element['Material']
    material_name = material_df[material_df['Material Number'] == material_num]['Name'].iloc[0]
    
    result_data.append({
        'Element ID': element['Element ID'],
        'Section Name': section_name,
        'Material Name': material_name
    })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID').reset_index(drop=True)

# Save to CSV
result_df.to_csv('Task_45_out.csv', index=False)

print(result_df)