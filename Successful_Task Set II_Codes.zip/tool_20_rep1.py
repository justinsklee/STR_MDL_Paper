import pandas as pd
import numpy as np
import math

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get first floor elevation (z = 0.0m)
first_floor_z = 0.0

# Find all nodes at first floor level
first_floor_nodes = node_df[node_df['Z (m)'] == first_floor_z]['Node ID'].tolist()

# Find columns connected to first floor nodes
# Columns are vertical elements (change in Z only, no change in X and Y)
first_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element)
    x_change = abs(node1['X (m)'] - node2['X (m)'])
    y_change = abs(node1['Y (m)'] - node2['Y (m)'])
    z_change = abs(node1['Z (m)'] - node2['Z (m)'])
    
    # Column: only Z changes, X and Y remain the same
    if x_change == 0 and y_change == 0 and z_change > 0:
        # Check if one node is at first floor and the other is above
        if (node1['Z (m)'] == first_floor_z and node2['Z (m)'] > first_floor_z) or \
           (node2['Z (m)'] == first_floor_z and node1['Z (m)'] > first_floor_z):
            first_floor_columns.append({
                'Element ID': element['Element ID'],
                'Section': element['Section'],
                'Length': z_change
            })

# Calculate total weight
total_weight = 0
steel_density = 7850  # kg/m³

for column in first_floor_columns:
    section_num = column['Section']
    section_info = section_df[section_df['Section Number'] == section_num].iloc[0]
    area = section_info['Area']  # m²
    length = column['Length']  # m
    volume = area * length  # m³
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
result_df = pd.DataFrame({
    'Total Weight of First Floor Columns (kg)': [total_weight_rounded]
})

result_df.to_csv('Task_20_out.csv', index=False)