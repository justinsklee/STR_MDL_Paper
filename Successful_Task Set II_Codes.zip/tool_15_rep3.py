import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is at index 1 (first floor is at index 0)
if len(floor_elevations) < 2:
    print("Error: Not enough floors in the model")
    exit()

second_floor_elevation = floor_elevations[1]

# Find all elements and classify them
braces = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    material = element['Material']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    node1_coords = [node1['X (m)'], node1['Y (m)'], node1['Z (m)']]
    node2_coords = [node2['X (m)'], node2['Y (m)'], node2['Z (m)']]
    
    # Check if element is a brace (changes in x or y AND z coordinates)
    x_change = abs(node1_coords[0] - node2_coords[0]) > 1e-6
    y_change = abs(node1_coords[1] - node2_coords[1]) > 1e-6
    z_change = abs(node1_coords[2] - node2_coords[2]) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if brace is associated with second floor
        # One node should be at second floor elevation, other node should be above
        node_elevations = [node1_coords[2], node2_coords[2]]
        
        if (abs(min(node_elevations) - second_floor_elevation) < 1e-6 and 
            max(node_elevations) > second_floor_elevation):
            braces.append({
                'Element ID': element_id,
                'Material Number': material
            })

# Create output dataframe
output_df = pd.DataFrame(braces)
output_df = output_df.sort_values('Element ID').reset_index(drop=True)

# Save to CSV
output_df.to_csv('Task_15_out.csv', index=False)

print(f"Found {len(braces)} second floor bracing elements")
print(output_df)