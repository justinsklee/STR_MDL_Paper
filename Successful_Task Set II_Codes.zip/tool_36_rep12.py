import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_36_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support node IDs
support_nodes = set(support_df['Node'].values)

# Identify columns (vertical elements with change only in z-coordinate)
columns = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only z changes, x and y remain same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Identify bracing elements (diagonal elements with change in x or y AND z coordinates)
braces = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a brace (change in x or y AND z coordinates)
    x_change = node1['X (m)'] != node2['X (m)']
    y_change = node1['Y (m)'] != node2['Y (m)']
    z_change = node1['Z (m)'] != node2['Z (m)']
    
    if (x_change or y_change) and z_change:
        braces.append(row['Element ID'])

# Find columns that share supports with bracing elements
columns_sharing_supports_with_braces = []

for col_id in columns:
    col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
    col_nodes = [col_row['Node 1'], col_row['Node 2']]
    
    # Check if any column node is a support node
    col_support_nodes = [node for node in col_nodes if node in support_nodes]
    
    if col_support_nodes:
        # Check if any brace shares these support nodes
        for brace_id in braces:
            brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
            brace_nodes = [brace_row['Node 1'], brace_row['Node 2']]
            
            # Check if brace shares any support node with this column
            if any(node in col_support_nodes for node in brace_nodes):
                columns_sharing_supports_with_braces.append(col_id)
                break

# Update section for these columns to 101
for col_id in columns_sharing_supports_with_braces:
    element_df.loc[element_df['Element ID'] == col_id, 'Section'] = 101

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_36_out/Element.csv', index=False)