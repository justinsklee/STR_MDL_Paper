import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Filter for residential live loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all beam element IDs that support residential loads
supporting_beam_ids = []

for _, load in residential_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # For each load area defined by 4 nodes, find the 4 beams that connect them
    # The beams connect: (node1,node2), (node2,node3), (node3,node4), (node4,node1)
    beam_pairs = []
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]  # Wrap around to first node for last pair
        beam_pairs.append((min(node1, node2), max(node1, node2)))
    
    # Find elements that match these node pairs and are beams (horizontal elements)
    for node1, node2 in beam_pairs:
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        # Check if these elements are beams (horizontal - same z coordinate)
        for _, elem in matching_elements.iterrows():
            elem_node1 = elem['Node 1']
            elem_node2 = elem['Node 2']
            
            node1_z = node_df[node_df['Node ID'] == elem_node1]['Z (m)'].iloc[0]
            node2_z = node_df[node_df['Node ID'] == elem_node2]['Z (m)'].iloc[0]
            
            # If z coordinates are the same, it's a beam
            if node1_z == node2_z:
                supporting_beam_ids.append(elem['Element ID'])

# Remove duplicates and sort
supporting_beam_ids = sorted(list(set(supporting_beam_ids)))

# Create output dataframe
output_df = pd.DataFrame({'Element ID': supporting_beam_ids})

# Save to CSV
output_df.to_csv('Task_5_out.csv', index=False)