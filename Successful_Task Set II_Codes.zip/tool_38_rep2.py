import pandas as pd
import os

# Create output folder
os.makedirs('Task_38_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Find first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find X-2 grid coordinate (second unique X coordinate)
unique_x_coords = sorted(node_df['X (m)'].unique())
x2_coord = unique_x_coords[1]  # X-2 is the second X coordinate

# Find nodes on first floor at X-2 grid
first_floor_x2_nodes = node_df[(node_df['Z (m)'] == first_floor_z) & (node_df['X (m)'] == x2_coord)]['Node ID'].tolist()

# Find columns that have one node on first floor at X-2 grid and the other node above
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1_info = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_info = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a column (vertical element - only z changes)
    is_column = (node1_info['X (m)'] == node2_info['X (m)']) and (node1_info['Y (m)'] == node2_info['Y (m)']) and (node1_info['Z (m)'] != node2_info['Z (m)'])
    
    if is_column:
        # Check if one node is on first floor at X-2 grid and other is above
        node1_on_first_floor_x2 = (node1_info['Z (m)'] == first_floor_z) and (node1_info['X (m)'] == x2_coord)
        node2_on_first_floor_x2 = (node2_info['Z (m)'] == first_floor_z) and (node2_info['X (m)'] == x2_coord)
        
        node1_above_first_floor = node1_info['Z (m)'] > first_floor_z
        node2_above_first_floor = node2_info['Z (m)'] > first_floor_z
        
        # Column belongs to first floor if one node is on first floor and other is above
        if (node1_on_first_floor_x2 and node2_above_first_floor) or (node2_on_first_floor_x2 and node1_above_first_floor):
            element_df.at[idx, 'Material'] = shn355_material

# Save updated Element.csv
element_df.to_csv('Task_38_out/Element.csv', index=False)