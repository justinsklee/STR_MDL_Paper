import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_33_out', exist_ok=True)

# Load all relevant CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Find X-direction grids (unique X coordinates)
x_coords = sorted(nodes_df['X (m)'].unique())

# Find X-3 grid coordinate (third X grid)
if len(x_coords) >= 3:
    x3_coord = x_coords[2]  # Third X grid (index 2)
    
    # Find braces along grid X-3
    # Braces are diagonal elements: change in both (x or y) AND z coordinates
    braces_on_x3 = []
    
    for _, element in elements_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates for both nodes
        node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        # Check if both nodes are on X-3 grid
        if node1['X (m)'] == x3_coord and node2['X (m)'] == x3_coord:
            # Check if it's a brace (diagonal element)
            x_change = abs(node1['X (m)'] - node2['X (m)'])
            y_change = abs(node1['Y (m)'] - node2['Y (m)'])
            z_change = abs(node1['Z (m)'] - node2['Z (m)'])
            
            # Brace: change in z AND (x or y)
            if z_change > 0 and (x_change > 0 or y_change > 0):
                braces_on_x3.append(element['Element ID'])
    
    # Remove beam-end-release entries for braces along grid X-3
    updated_beam_end_release_df = beam_end_release_df[~beam_end_release_df['Element ID'].isin(braces_on_x3)]
    
    # Sort by Element ID in ascending order
    updated_beam_end_release_df = updated_beam_end_release_df.sort_values('Element ID')
    
    # Save updated Beam_end_release.csv file
    updated_beam_end_release_df.to_csv('Task_33_out/Beam_end_release.csv', index=False)
    
    print(f"Removed beam-end-release for {len(braces_on_x3)} braces along grid X-3")
    if braces_on_x3:
        print(f"Affected element IDs: {braces_on_x3}")
else:
    print("Not enough X grids found in the model")
    # Save original file if no X-3 grid exists
    beam_end_release_df.to_csv('Task_33_out/Beam_end_release.csv', index=False)