import pandas as pd

# Load CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Find all unique z-coordinates to determine floor elevations
unique_z = sorted(nodes_df['Z (m)'].unique())
first_floor_z = unique_z[0]  # Ground level
second_floor_z = unique_z[1] if len(unique_z) > 1 else None

# Identify columns (vertical elements with change only in z-coordinate)
first_floor_columns = []

for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only z changes)
    x_change = abs(node1['X (m)'] - node2['X (m)']) < 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) < 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    if x_change and y_change and z_change:
        # Check if one node is at first floor and other is above
        node1_z = node1['Z (m)']
        node2_z = node2['Z (m)']
        
        if (abs(node1_z - first_floor_z) < 1e-6 and node2_z > first_floor_z) or \
           (abs(node2_z - first_floor_z) < 1e-6 and node1_z > first_floor_z):
            first_floor_columns.append(element['Element ID'])

# Sort element IDs in ascending order
first_floor_columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': first_floor_columns})

# Save to CSV
output_df.to_csv('Task_1_out.csv', index=False)