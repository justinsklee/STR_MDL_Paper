import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation (index 1)
second_floor_elevation = floor_elevations[1]

# Get nodes at second floor elevation
second_floor_nodes = node_df[node_df['Z (m)'] == second_floor_elevation]['Node ID'].tolist()

# Find braces connected to second floor
# Braces have one node at the floor and another node above the floor
second_floor_braces = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if one node is at second floor and the other is above
    node1_at_second_floor = node1_coords['Z (m)'] == second_floor_elevation
    node2_at_second_floor = node2_coords['Z (m)'] == second_floor_elevation
    node1_above_second_floor = node1_coords['Z (m)'] > second_floor_elevation
    node2_above_second_floor = node2_coords['Z (m)'] > second_floor_elevation
    
    # One node at second floor, one above
    if (node1_at_second_floor and node2_above_second_floor) or (node2_at_second_floor and node1_above_second_floor):
        # Check if it's a brace (change in x or y AND z coordinates)
        x_change = node1_coords['X (m)'] != node2_coords['X (m)']
        y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        
        if (x_change or y_change) and z_change:
            second_floor_braces.append({
                'Element ID': element['Element ID'],
                'Material Number': element['Material']
            })

# Create output dataframe
output_df = pd.DataFrame(second_floor_braces)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_15_out.csv', index=False)

print(f"Found {len(second_floor_braces)} second floor braces")
print(output_df)