import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get the maximum Z coordinate to identify the roof level
max_z = node_df['Z (m)'].max()

# Identify columns (vertical elements with only Z coordinate change)
columns = []
for _, elem in element_df.iterrows():
    node1_id = elem['Node 1']
    node2_id = elem['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only Z changes, X and Y remain same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(elem['Element ID'])

# Identify beams at roof level (elements with both nodes at max Z)
roof_beams = []
for _, elem in element_df.iterrows():
    node1_id = elem['Node 1']
    node2_id = elem['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam at roof level (both nodes at same Z, and Z is max)
    if (node1['Z (m)'] == node2['Z (m)'] and 
        node1['Z (m)'] == max_z):
        roof_beams.append(elem['Element ID'])

# Find nodes that are connected to columns at roof level
column_connected_nodes = set()
for _, elem in element_df.iterrows():
    if elem['Element ID'] in columns:
        node1_id = elem['Node 1']
        node2_id = elem['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Add the node that's at roof level
        if node1['Z (m)'] == max_z:
            column_connected_nodes.add(node1_id)
        if node2['Z (m)'] == max_z:
            column_connected_nodes.add(node2_id)

# Identify roof sub-beams (roof beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    elem = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = elem['Node 1']
    node2_id = elem['Node 2']
    
    # Check if neither node is connected to a column
    if (node1_id not in column_connected_nodes and 
        node2_id not in column_connected_nodes):
        roof_sub_beams.append(beam_id)

# Sort element numbers in ascending order
roof_sub_beams.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': roof_sub_beams})

# Save to CSV file
output_df.to_csv('Task_2_out.csv', index=False)

print(f"Roof sub-beam element numbers: {roof_sub_beams}")