import pandas as pd

# Load CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')

# Get the maximum z-coordinate to identify the roof level
max_z = nodes_df['Z (m)'].max()

# Identify columns (vertical elements with only z-coordinate change)
columns = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only z changes, x and y remain same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Find beams at roof level (elements with both nodes at max z)
roof_beams = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam at roof level (both nodes at same z, and z = max_z)
    if (node1['Z (m)'] == node2['Z (m)'] == max_z):
        roof_beams.append(element['Element ID'])

# Find roof sub-beams (roof beams not connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    beam = elements_df[elements_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam['Node 1']
    node2_id = beam['Node 2']
    
    # Check if either node is connected to a column
    connected_to_column = False
    for column_id in columns:
        column = elements_df[elements_df['Element ID'] == column_id].iloc[0]
        column_node1 = column['Node 1']
        column_node2 = column['Node 2']
        
        if node1_id in [column_node1, column_node2] or node2_id in [column_node1, column_node2]:
            connected_to_column = True
            break
    
    # If not connected to any column, it's a sub-beam
    if not connected_to_column:
        roof_sub_beams.append(beam_id)

# Sort element IDs in ascending order
roof_sub_beams.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': roof_sub_beams})

# Save to CSV
output_df.to_csv('Task_2_out.csv', index=False)

print(f"Found {len(roof_sub_beams)} roof sub-beams")
print(output_df)