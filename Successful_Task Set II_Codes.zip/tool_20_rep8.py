import pandas as pd
import numpy as np
import math

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find nodes at first floor level
first_floor_nodes = node_df[node_df['Z (m)'] == first_floor_z]['Node ID'].tolist()

# Find columns that have one node at first floor and the other node above first floor
first_floor_columns = []

for _, element in element_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if it's a column (vertical element - only z changes, x and y stay same)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        
        # Check if one node is at first floor and other is above
        if ((node1_coords['Z (m)'] == first_floor_z and node2_coords['Z (m)'] > first_floor_z) or
            (node2_coords['Z (m)'] == first_floor_z and node1_coords['Z (m)'] > first_floor_z)):
            first_floor_columns.append(element['Element ID'])

# Calculate total weight
total_weight = 0
steel_density = 7850  # kg/m^3

for col_id in first_floor_columns:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    section_num = element['Section']
    
    # Get section area
    section = section_df[section_df['Section Number'] == section_num].iloc[0]
    area = section['Area']  # m^2
    
    # Get column length
    node1 = element['Node 1']
    node2 = element['Node 2']
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    length = abs(node2_coords['Z (m)'] - node1_coords['Z (m)'])  # m
    
    # Calculate weight
    volume = area * length  # m^3
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
output_df = pd.DataFrame({
    'Total Steel Weight for First Floor Columns (kg)': [total_weight_rounded]
})

output_df.to_csv('Task_20_out.csv', index=False)