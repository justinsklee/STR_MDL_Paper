import pandas as pd
import numpy as np
import math

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find second floor elevation (one story above ground)
unique_z_coords = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z_coords[1] if len(unique_z_coords) > 1 else None

# Identify first floor columns
# Columns are vertical elements with one node at first floor and other node above first floor
first_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only z changes, x and y remain same)
    is_vertical = (node1['X (m)'] == node2['X (m)']) and (node1['Y (m)'] == node2['Y (m)']) and (node1['Z (m)'] != node2['Z (m)'])
    
    if is_vertical:
        # Check if one node is at first floor and other is above
        z1, z2 = node1['Z (m)'], node2['Z (m)']
        if (z1 == first_floor_z and z2 > first_floor_z) or (z2 == first_floor_z and z1 > first_floor_z):
            first_floor_columns.append({
                'Element ID': element['Element ID'],
                'Section': element['Section'],
                'Length': abs(z2 - z1)
            })

# Calculate total weight
total_weight = 0
steel_density = 7850  # kg/m^3

for column in first_floor_columns:
    section_num = column['Section']
    section_info = section_df[section_df['Section Number'] == section_num].iloc[0]
    area = section_info['Area']  # m^2
    length = column['Length']  # m
    volume = area * length  # m^3
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
output_df = pd.DataFrame({
    'Total Weight of First Floor Columns (kg)': [total_weight_rounded]
})

output_df.to_csv('Task_20_out.csv', index=False)