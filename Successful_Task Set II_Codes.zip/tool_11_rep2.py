import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique Z coordinates and sort them to identify floor levels
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=first floor, 1=second floor, 2=third floor)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
    
    # Find columns: elements where one node is at third floor and other node is above third floor
    third_floor_columns = []
    
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a column (vertical element with one node at third floor, other above)
        x1, y1, z1 = node1_coords['X (m)'], node1_coords['Y (m)'], node1_coords['Z (m)']
        x2, y2, z2 = node2_coords['X (m)'], node2_coords['Y (m)'], node2_coords['Z (m)']
        
        # Column criteria: same x,y coordinates and vertical alignment
        if x1 == x2 and y1 == y2:
            # One node at third floor, other node above third floor
            if ((z1 == third_floor_elevation and z2 > third_floor_elevation) or 
                (z2 == third_floor_elevation and z1 > third_floor_elevation)):
                
                # Get section name
                section_num = element['Section']
                section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
                
                third_floor_columns.append({
                    'Element ID': element['Element ID'],
                    'Section Name': section_name
                })
    
    # Create output DataFrame and save to CSV
    result_df = pd.DataFrame(third_floor_columns)
    result_df = result_df.sort_values('Element ID')
    result_df.to_csv('Task_11_out.csv', index=False)
    
    print(f"Found {len(third_floor_columns)} third floor columns")
    print(result_df)
else:
    print("Model does not have a third floor")