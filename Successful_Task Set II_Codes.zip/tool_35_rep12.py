import pandas as pd
import os

# Create output folder
os.makedirs('Task_35_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find residential loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that define residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    residential_nodes.update(nodes)

# Find columns supporting residential loads (columns with one node below the residential load nodes)
supporting_columns = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get node coordinates
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if element is a column (vertical - only z changes)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        
        # Determine which node is above and which is below
        if node1_coords['Z (m)'] > node2_coords['Z (m)']:
            upper_node = node1
            lower_node = node2
        else:
            upper_node = node2
            lower_node = node1
        
        # Check if the upper node is in residential load areas
        if upper_node in residential_nodes:
            supporting_columns.append(element_id)

# Update material for supporting columns to SHN355 (material 1003)
element_df.loc[element_df['Element ID'].isin(supporting_columns), 'Material'] = 1003

# Save updated Element.csv
element_df.to_csv('Task_35_out/Element.csv', index=False)

print(f"Updated {len(supporting_columns)} columns supporting residential loads to SHN355 material")
print(f"Column IDs updated: {supporting_columns}")