import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_36_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support node IDs
support_nodes = set(support_df['Node'].values)

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    # Column: only z changes
    if dx < 1e-6 and dy < 1e-6 and dz > 1e-6:
        return 'column'
    # Beam: only x or y changes, no z change
    elif dz < 1e-6 and (dx > 1e-6 or dy > 1e-6):
        return 'beam'
    # Brace: z changes AND (x or y changes)
    elif dz > 1e-6 and (dx > 1e-6 or dy > 1e-6):
        return 'brace'
    else:
        return 'unknown'

# Classify all elements
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find columns that share supports with bracing elements
columns_to_update = set()

for _, element in element_df.iterrows():
    if element['element_type'] == 'column':
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Check if either node is a support node
        if node1_id in support_nodes or node2_id in support_nodes:
            # Check if there's a bracing element sharing the same support node
            support_node = node1_id if node1_id in support_nodes else node2_id
            
            # Look for bracing elements connected to this support node
            bracing_elements = element_df[
                (element_df['element_type'] == 'brace') & 
                ((element_df['Node 1'] == support_node) | (element_df['Node 2'] == support_node))
            ]
            
            if len(bracing_elements) > 0:
                columns_to_update.add(element['Element ID'])

# Update section for identified columns
for col_id in columns_to_update:
    element_df.loc[element_df['Element ID'] == col_id, 'Section'] = 101

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_36_out/Element.csv', index=False)