import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is at index 1 (first floor is at index 0)
if len(floor_elevations) < 2:
    print("Not enough floors in the model")
    second_floor_results = pd.DataFrame(columns=['Element ID', 'Material'])
else:
    second_floor_elevation = floor_elevations[1]
    
    # Find braces connected to second floor
    second_floor_braces = []
    
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates for both nodes
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        node1_coords = (node1['X (m)'], node1['Y (m)'], node1['Z (m)'])
        node2_coords = (node2['X (m)'], node2['Y (m)'], node2['Z (m)'])
        
        # Check if element is a brace (changes in x/y AND z coordinates)
        x_change = abs(node1_coords[0] - node2_coords[0]) > 1e-6
        y_change = abs(node1_coords[1] - node2_coords[1]) > 1e-6
        z_change = abs(node1_coords[2] - node2_coords[2]) > 1e-6
        
        is_brace = (x_change or y_change) and z_change
        
        # Check if brace is connected to second floor
        if is_brace:
            node1_on_second_floor = abs(node1_coords[2] - second_floor_elevation) < 1e-6
            node2_above_second_floor = node2_coords[2] > second_floor_elevation
            
            node2_on_second_floor = abs(node2_coords[2] - second_floor_elevation) < 1e-6
            node1_above_second_floor = node1_coords[2] > second_floor_elevation
            
            if (node1_on_second_floor and node2_above_second_floor) or (node2_on_second_floor and node1_above_second_floor):
                second_floor_braces.append({
                    'Element ID': element['Element ID'],
                    'Material': element['Material']
                })
    
    # Create results dataframe
    second_floor_results = pd.DataFrame(second_floor_braces)
    
    # Sort by Element ID
    if not second_floor_results.empty:
        second_floor_results = second_floor_results.sort_values('Element ID')

# Save to CSV
second_floor_results.to_csv('Task_15_out.csv', index=False)