import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_36_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support node IDs
support_nodes = set(support_df['Node'].tolist())

# Function to classify elements
def classify_element(row):
    node1_id, node2_id = row['Node 1'], row['Node 2']
    
    # Get coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check changes in coordinates
    dx = abs(x2 - x1) > 1e-6
    dy = abs(y2 - y1) > 1e-6
    dz = abs(z2 - z1) > 1e-6
    
    # Classify
    if dz and not dx and not dy:  # Only z changes
        return 'column'
    elif not dz:  # No z change
        return 'beam'
    else:  # Change in z and (x or y)
        return 'brace'

# Add classification to elements
element_df['classification'] = element_df.apply(classify_element, axis=1)

# Find columns that share supports with bracing elements
columns_with_bracing = set()

for support_node in support_nodes:
    # Find all elements connected to this support node
    connected_elements = element_df[
        (element_df['Node 1'] == support_node) | 
        (element_df['Node 2'] == support_node)
    ]
    
    # Check if there are both columns and braces connected to this node
    has_column = any(connected_elements['classification'] == 'column')
    has_brace = any(connected_elements['classification'] == 'brace')
    
    if has_column and has_brace:
        # Add column element IDs to the set
        column_elements = connected_elements[connected_elements['classification'] == 'column']
        columns_with_bracing.update(column_elements['Element ID'].tolist())

# Update section for identified columns
element_df.loc[element_df['Element ID'].isin(columns_with_bracing), 'Section'] = 101

# Remove the temporary classification column
element_df = element_df.drop('classification', axis=1)

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_36_out/Element.csv', index=False)