import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique z-coordinates to identify floors
z_coords = sorted(node_df['Z (m)'].unique())

# Identify beams (horizontal elements - no change in z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if z-coordinates are the same (horizontal element)
    if node1['Z (m)'] == node2['Z (m)']:
        # Calculate length
        length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                        (node2['Y (m)'] - node1['Y (m)'])**2 + 
                        (node2['Z (m)'] - node1['Z (m)'])**2)
        
        # Check if length is less than 1.3m
        if length < 1.3:
            beams.append({
                'Element ID': element['Element ID'],
                'Length': length
            })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(beams)
if not result_df.empty:
    result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_19_out.csv', index=False)