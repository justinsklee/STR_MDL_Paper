import pandas as pd
import os

# Create output folder
os.makedirs('Task_27_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify columns (vertical elements with same x,y coordinates but different z)
columns = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams (horizontal elements with same z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Find nodes that are connected to columns
column_nodes = set()
for col_id in columns:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    column_nodes.add(element['Node 1'])
    column_nodes.add(element['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Check if both nodes are NOT connected to columns
    if node1 not in column_nodes and node2 not in column_nodes:
        sub_beams.append(beam_id)

# Add beam-end-release for sub-beams
new_releases = []
for sub_beam_id in sub_beams:
    # Check if release already exists
    if sub_beam_id not in beam_end_release_df['Element ID'].values:
        new_release = {
            'Element ID': sub_beam_id,
            'Type': 'Relative',
            'i-end release': 11,
            'Fxi': 0,
            'Fyi': 0,
            'Fzi': 0,
            'Mxi': 0,
            'Myi': 0,
            'Mzi': 0,
            'j-end release': 11,
            'Fxj': 0,
            'Fyj': 0,
            'Fzj': 0,
            'Mxj': 0,
            'Myj': 0,
            'Mzj': 0,
            'Group': 'Default'
        }
        new_releases.append(new_release)

# Add new releases to dataframe
if new_releases:
    new_releases_df = pd.DataFrame(new_releases)
    beam_end_release_df = pd.concat([beam_end_release_df, new_releases_df], ignore_index=True)

# Sort by Element ID in ascending order
beam_end_release_df = beam_end_release_df.sort_values('Element ID').reset_index(drop=True)

# Save updated file
beam_end_release_df.to_csv('Task_27_out/Beam_end_release.csv', index=False)

print(f"Sub-beams identified: {sub_beams}")
print(f"Beam-end-release applied to {len(new_releases)} sub-beams")