import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_21_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor elevation (one floor above ground level)
second_floor_elevation = floor_elevations[1]

# Find columns that have one node at second floor and the other node above second floor
second_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates of both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical: same x,y coordinates, different z)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is at second floor and the other is above
        z_coords = [node1['Z (m)'], node2['Z (m)']]
        if (second_floor_elevation in z_coords and 
            max(z_coords) > second_floor_elevation):
            second_floor_columns.append(element['Element ID'])

# Update section for second floor columns
element_df.loc[element_df['Element ID'].isin(second_floor_columns), 'Section'] = 102

# Save updated Element.csv
element_df.to_csv('Task_21_out/Element.csv', index=False)

print(f"Updated {len(second_floor_columns)} second floor columns to section 102")
print(f"Column IDs updated: {second_floor_columns}")