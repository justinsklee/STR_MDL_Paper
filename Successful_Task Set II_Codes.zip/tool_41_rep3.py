import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Identify roof level (highest elevation)
roof_elevation = max(floor_elevations)

# Filter beams with section 101 at roof level
roof_beams_section_101 = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    section = element['Section']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in z coordinates)
    is_beam = node1['Z (m)'] == node2['Z (m)']
    
    # Check if it's at roof level and has section 101
    if is_beam and node1['Z (m)'] == roof_elevation and section == 101:
        roof_beams_section_101.append(element_id)

# Calculate total weight
total_weight = 0
density = 7850  # kg/m^3

for element_id in roof_beams_section_101:
    element = element_df[element_df['Element ID'] == element_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Calculate length
    length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                     (node2['Y (m)'] - node1['Y (m)'])**2 + 
                     (node2['Z (m)'] - node1['Z (m)'])**2)
    
    # Get section area
    section_info = section_df[section_df['Section Number'] == 101].iloc[0]
    area = section_info['Area']  # m^2
    
    # Calculate weight
    weight = density * area * length  # kg
    total_weight += weight

# Round up to nearest 10 kg
total_weight_rounded = int(np.ceil(total_weight / 10) * 10)

# Create output dataframe
output_df = pd.DataFrame({
    'Total Weight (kg)': [total_weight_rounded]
})

# Save to CSV
output_df.to_csv('Task_41_out.csv', index=False)