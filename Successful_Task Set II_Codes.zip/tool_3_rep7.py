import pandas as pd
import numpy as np

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = nodes_df['X (m)'].min()

# Classify elements as braces (diagonal elements with changes in both horizontal and vertical coordinates)
brace_elements = []

for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (changes in x or y AND z coordinates)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    horizontal_change = x_change or y_change
    is_brace = horizontal_change and z_change
    
    # Check if brace is on X-1 grid (both nodes have same x-coordinate as X-1)
    if is_brace:
        node1_on_x1 = abs(node1['X (m)'] - x1_coord) < 1e-6
        node2_on_x1 = abs(node2['X (m)'] - x1_coord) < 1e-6
        
        if node1_on_x1 and node2_on_x1:
            brace_elements.append(element['Element ID'])

# Create output dataframe
result_df = pd.DataFrame({'Element ID': sorted(brace_elements)})

# Save to CSV
result_df.to_csv('Task_3_out.csv', index=False)

print(result_df)