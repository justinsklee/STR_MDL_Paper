import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_46_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the first floor elevation (ground level)
first_floor_z = node_df['Z (m)'].min()

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify first floor columns along grid X-1
# Columns are vertical elements with change only in z-coordinates
first_floor_columns_x1 = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only z changes)
    x_diff = abs(node1_coords['X (m)'] - node2_coords['X (m)'])
    y_diff = abs(node1_coords['Y (m)'] - node2_coords['Y (m)'])
    z_diff = abs(node1_coords['Z (m)'] - node2_coords['Z (m)'])
    
    is_column = (x_diff < 1e-6 and y_diff < 1e-6 and z_diff > 1e-6)
    
    if is_column:
        # Check if column is on X-1 grid
        on_x1_grid = (abs(node1_coords['X (m)'] - x1_coord) < 1e-6 and 
                      abs(node2_coords['X (m)'] - x1_coord) < 1e-6)
        
        if on_x1_grid:
            # Check if one node is on first floor and other is above
            node1_on_first_floor = abs(node1_coords['Z (m)'] - first_floor_z) < 1e-6
            node2_on_first_floor = abs(node2_coords['Z (m)'] - first_floor_z) < 1e-6
            node1_above_first_floor = node1_coords['Z (m)'] > first_floor_z
            node2_above_first_floor = node2_coords['Z (m)'] > first_floor_z
            
            is_first_floor_column = ((node1_on_first_floor and node2_above_first_floor) or 
                                   (node2_on_first_floor and node1_above_first_floor))
            
            if is_first_floor_column:
                first_floor_columns_x1.append(row['Element ID'])

# Update elements with section 105 to have material 1002
for idx, row in element_df.iterrows():
    if row['Element ID'] in first_floor_columns_x1 and row['Section'] == 105:
        element_df.at[idx, 'Material'] = 1002

# Save updated Element.csv
element_df.to_csv('Task_46_out/Element.csv', index=False)

print(f"Updated {len([e for e in first_floor_columns_x1 if element_df[element_df['Element ID'] == e]['Section'].iloc[0] == 105])} first floor columns along grid X-1 with section 105 to material 1002")