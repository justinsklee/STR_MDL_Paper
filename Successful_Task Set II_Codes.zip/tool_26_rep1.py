import pandas as pd
import os

# Create output folder
os.makedirs('Task_26_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation in the sorted list
second_floor_z = floor_elevations[1]

# Find material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Identify beams on second floor
# Beams are horizontal elements (no change in Z coordinates between nodes)
# and lie on the same elevation as the floor
second_floor_beams = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (horizontal element - same Z coordinates)
    if node1_coords['Z (m)'] == node2_coords['Z (m)']:
        # Check if it's on the second floor
        if node1_coords['Z (m)'] == second_floor_z:
            second_floor_beams.append(idx)

# Update material for second floor beams
for idx in second_floor_beams:
    element_df.at[idx, 'Material'] = shn355_material

# Save updated Element.csv
element_df.to_csv('Task_26_out/Element.csv', index=False)