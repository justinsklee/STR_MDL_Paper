import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_39_out', exist_ok=True)

# Find the first floor elevation (minimum z-coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find the second floor elevation (next unique z-coordinate above first floor)
unique_z_coords = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z_coords[1] if len(unique_z_coords) > 1 else first_floor_z + 1

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify braces on first floor along grid X-1
elements_to_remove = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal element with z-change and x or y change)
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 0
    x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 0
    y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 0
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if brace is on first floor (one node at first floor, other above)
        node1_at_first_floor = node1_coords['Z (m)'] == first_floor_z
        node2_at_first_floor = node2_coords['Z (m)'] == first_floor_z
        node1_above_first_floor = node1_coords['Z (m)'] > first_floor_z
        node2_above_first_floor = node2_coords['Z (m)'] > first_floor_z
        
        is_first_floor_brace = (node1_at_first_floor and node2_above_first_floor) or (node2_at_first_floor and node1_above_first_floor)
        
        # Check if brace is along grid X-1 (both nodes have same x-coordinate as X-1)
        both_nodes_on_x1 = (node1_coords['X (m)'] == x1_coord) and (node2_coords['X (m)'] == x1_coord)
        
        if is_first_floor_brace and both_nodes_on_x1:
            elements_to_remove.append(row['Element ID'])

# Remove identified braces
updated_element_df = element_df[~element_df['Element ID'].isin(elements_to_remove)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_39_out/Element.csv', index=False)

print(f"Removed {len(elements_to_remove)} braces on first floor along grid X-1")
if elements_to_remove:
    print(f"Removed element IDs: {elements_to_remove}")