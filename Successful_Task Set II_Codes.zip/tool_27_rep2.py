import pandas as pd
import os

# Create output folder
os.makedirs('Task_27_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify columns (vertical elements)
column_elements = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Column: only z-coordinate changes, x and y remain same
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        column_elements.append(row['Element ID'])

# Identify beams (horizontal elements)
beam_elements = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Beam: no change in z-coordinate
    if node1['Z (m)'] == node2['Z (m)']:
        beam_elements.append(row['Element ID'])

# Find nodes that are connected to columns
column_connected_nodes = set()
for _, row in element_df.iterrows():
    if row['Element ID'] in column_elements:
        column_connected_nodes.add(row['Node 1'])
        column_connected_nodes.add(row['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beam_elements = []
for beam_id in beam_elements:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_row['Node 1']
    node2_id = beam_row['Node 2']
    
    # Sub-beam: neither node is connected to a column
    if node1_id not in column_connected_nodes and node2_id not in column_connected_nodes:
        sub_beam_elements.append(beam_id)

# Add beam-end-release entries for sub-beams
for sub_beam_id in sub_beam_elements:
    # Check if release already exists
    if sub_beam_id not in beam_end_release_df['Element ID'].values:
        new_row = {
            'Element ID': sub_beam_id,
            'Type': 'Relative',
            'i-end release': 11,
            'Fxi': 0,
            'Fyi': 0,
            'Fzi': 0,
            'Mxi': 0,
            'Myi': 0,
            'Mzi': 0,
            'j-end release': 11,
            'Fxj': 0,
            'Fyj': 0,
            'Fzj': 0,
            'Mxj': 0,
            'Myj': 0,
            'Mzj': 0,
            'Group': 'Default'
        }
        beam_end_release_df = pd.concat([beam_end_release_df, pd.DataFrame([new_row])], ignore_index=True)

# Sort by Element ID in ascending order
beam_end_release_df = beam_end_release_df.sort_values('Element ID').reset_index(drop=True)

# Save updated file
beam_end_release_df.to_csv('Task_27_out/Beam_end_release.csv', index=False)

print(f"Added beam-end-release to {len(sub_beam_elements)} sub-beams: {sub_beam_elements}")