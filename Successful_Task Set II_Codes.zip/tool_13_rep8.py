import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Get all unique z coordinates and sort them to find floor elevations
unique_z = sorted(node_df['Z (m)'].unique())
first_floor_z = unique_z[0]  # Ground level
second_floor_z = unique_z[1] if len(unique_z) > 1 else first_floor_z + 1

# Create node coordinate lookup
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Find first floor bracing
first_floor_braces = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    if node1_id in node_coords and node2_id in node_coords:
        x1, y1, z1 = node_coords[node1_id]
        x2, y2, z2 = node_coords[node2_id]
        
        # Check if this is a brace (diagonal element with change in x/y AND z)
        has_xy_change = (x1 != x2) or (y1 != y2)
        has_z_change = (z1 != z2)
        
        if has_xy_change and has_z_change:
            # Check if one node is at first floor and the other is above
            node_at_first_floor = (z1 == first_floor_z) or (z2 == first_floor_z)
            node_above_first_floor = (z1 > first_floor_z) or (z2 > first_floor_z)
            
            if node_at_first_floor and node_above_first_floor:
                first_floor_braces.append({
                    'Element ID': element_id,
                    'Section': element['Section']
                })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(first_floor_braces)
if not result_df.empty:
    result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_13_out.csv', index=False)