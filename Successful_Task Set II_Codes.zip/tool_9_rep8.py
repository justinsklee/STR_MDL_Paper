import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify braces (diagonal elements: change in both (x or y) AND z coordinates)
braces = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if element is a brace (change in z AND change in x or y)
    z_change = abs(z2 - z1) > 1e-6
    xy_change = abs(x2 - x1) > 1e-6 or abs(y2 - y1) > 1e-6
    
    if z_change and xy_change:
        braces.append(element_id)

# Get braces that are NOT beam-end-released
# Beam-end-released elements have entries in beam_end_release_df
released_elements = set(beam_end_release_df['Element ID'].tolist())
non_released_braces = [brace_id for brace_id in braces if brace_id not in released_elements]

# Sort in ascending order
non_released_braces.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': non_released_braces})

# Save to CSV file
output_df.to_csv('Task_9_out.csv', index=False)