import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_30_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Determine fourth floor elevation (index 3 since we start from 0)
if len(floor_elevations) >= 4:
    fourth_floor_elevation = floor_elevations[3]
else:
    print("Model does not have a fourth floor")
    fourth_floor_elevation = None

if fourth_floor_elevation is not None:
    # Get nodes on fourth floor and above
    fourth_floor_nodes = nodes_df[nodes_df['Z (m)'] == fourth_floor_elevation]['Node ID'].tolist()
    above_fourth_floor_nodes = nodes_df[nodes_df['Z (m)'] > fourth_floor_elevation]['Node ID'].tolist()
    
    # Identify braces on fourth floor
    braces_to_remove = []
    
    for idx, row in elements_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = nodes_df[nodes_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = nodes_df[nodes_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Check if element is a brace (changes in x/y AND z coordinates)
        x_change = node1_coords['X (m)'] != node2_coords['X (m)']
        y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        
        is_brace = (x_change or y_change) and z_change
        
        # Check if brace is on fourth floor (one node on fourth floor, other above)
        if is_brace:
            node1_on_fourth = node1_id in fourth_floor_nodes
            node2_on_fourth = node2_id in fourth_floor_nodes
            node1_above_fourth = node1_id in above_fourth_floor_nodes
            node2_above_fourth = node2_id in above_fourth_floor_nodes
            
            if (node1_on_fourth and node2_above_fourth) or (node2_on_fourth and node1_above_fourth):
                braces_to_remove.append(row['Element ID'])
    
    # Remove identified braces from elements dataframe
    elements_df_updated = elements_df[~elements_df['Element ID'].isin(braces_to_remove)]
    
    # Sort by Element ID in ascending order
    elements_df_updated = elements_df_updated.sort_values('Element ID').reset_index(drop=True)
    
    # Save updated Element.csv
    elements_df_updated.to_csv('Task_30_out/Element.csv', index=False)
    
    print(f"Removed {len(braces_to_remove)} braces from fourth floor")
    print(f"Removed brace Element IDs: {braces_to_remove}")
else:
    # If no fourth floor, save original file
    elements_df.to_csv('Task_30_out/Element.csv', index=False)
    print("No fourth floor found in model")