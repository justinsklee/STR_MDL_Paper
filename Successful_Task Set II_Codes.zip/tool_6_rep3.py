import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')

# Filter for office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get all nodes that are part of office load areas
office_nodes = set()
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.update(nodes)

# Find columns that support these nodes from below
supporting_columns = []

for node_id in office_nodes:
    # Get the z-coordinate of the floor node
    floor_z = node_df[node_df['Node ID'] == node_id]['Z (m)'].iloc[0]
    
    # Find columns connected to this node
    # Columns are vertical elements (change only in z-coordinate)
    elements_with_node = element_df[(element_df['Node 1'] == node_id) | (element_df['Node 2'] == node_id)]
    
    for _, element in elements_with_node.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates of both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Check if it's a column (vertical element)
        x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)'])
        y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)'])
        z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)'])
        
        # Column: only z changes, x and y stay the same
        if x_change == 0 and y_change == 0 and z_change > 0:
            # Check if this column supports from below (one node at floor level, other below)
            if ((node1_id == node_id and node2_coords['Z (m)'] < floor_z) or 
                (node2_id == node_id and node1_coords['Z (m)'] < floor_z)):
                supporting_columns.append(element['Element ID'])

# Remove duplicates and sort
supporting_columns = sorted(list(set(supporting_columns)))

# Create output dataframe
output_df = pd.DataFrame({'Element ID': supporting_columns})

# Save to CSV
output_df.to_csv('Task_6_out.csv', index=False)

print(f"Found {len(supporting_columns)} columns supporting office live loads")
print(output_df)