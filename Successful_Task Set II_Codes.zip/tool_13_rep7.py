import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_elevation = floor_elevations[0]  # Ground level
second_floor_elevation = floor_elevations[1] if len(floor_elevations) > 1 else None

# Create node coordinate lookup
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Find first floor bracing elements
first_floor_braces = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_coords[node1_id]
    node2_coords = node_coords[node2_id]
    
    # Check if this is a brace (diagonal element - changes in both horizontal and vertical coordinates)
    x_change = node1_coords[0] != node2_coords[0]
    y_change = node1_coords[1] != node2_coords[1]
    z_change = node1_coords[2] != node2_coords[2]
    
    horizontal_change = x_change or y_change
    is_brace = horizontal_change and z_change
    
    if is_brace:
        # Check if this is a first floor brace (one node at first floor, other above)
        node1_at_first_floor = node1_coords[2] == first_floor_elevation
        node2_at_first_floor = node2_coords[2] == first_floor_elevation
        node1_above_first_floor = node1_coords[2] > first_floor_elevation
        node2_above_first_floor = node2_coords[2] > first_floor_elevation
        
        if (node1_at_first_floor and node2_above_first_floor) or (node2_at_first_floor and node1_above_first_floor):
            first_floor_braces.append({
                'Element ID': element_id,
                'Section': element['Section']
            })

# Create output dataframe and sort by Element ID
output_df = pd.DataFrame(first_floor_braces)
if not output_df.empty:
    output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_13_out.csv', index=False)

print(f"Found {len(first_floor_braces)} first floor bracing elements")
if not output_df.empty:
    print(output_df.to_string(index=False))
else:
    print("No first floor bracing elements found")