import pandas as pd
import os

# Create output folder
os.makedirs('Task_40_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the second floor elevation (one story above ground level z=0.0)
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor is index 1 (ground is index 0)

# Find Y-1 grid coordinate (minimum y-coordinate)
y1_coord = node_df['Y (m)'].min()

# Find nodes on second floor and Y-1 grid
second_floor_y1_nodes = node_df[
    (node_df['Z (m)'] == second_floor_z) & 
    (node_df['Y (m)'] == y1_coord)
]['Node ID'].tolist()

# Find nodes above second floor and Y-1 grid
above_second_floor_y1_nodes = node_df[
    (node_df['Z (m)'] > second_floor_z) & 
    (node_df['Y (m)'] == y1_coord)
]['Node ID'].tolist()

# Identify braces to remove (elements connecting second floor Y-1 nodes to nodes above)
braces_to_remove = []

for _, element in element_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Check if this element connects a second floor Y-1 node to a node above
    if ((node1 in second_floor_y1_nodes and node2 in above_second_floor_y1_nodes) or
        (node2 in second_floor_y1_nodes and node1 in above_second_floor_y1_nodes)):
        
        # Verify it's a brace by checking if it's diagonal
        node1_info = node_df[node_df['Node ID'] == node1].iloc[0]
        node2_info = node_df[node_df['Node ID'] == node2].iloc[0]
        
        # Brace: change in z AND change in (x or y)
        z_change = node1_info['Z (m)'] != node2_info['Z (m)']
        xy_change = (node1_info['X (m)'] != node2_info['X (m)']) or (node1_info['Y (m)'] != node2_info['Y (m)'])
        
        if z_change and xy_change:
            braces_to_remove.append(element['Element ID'])

# Remove identified braces
updated_element_df = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_40_out/Element.csv', index=False)

print(f"Removed {len(braces_to_remove)} second floor braces along grid Y-1")
print(f"Removed elements: {braces_to_remove}")