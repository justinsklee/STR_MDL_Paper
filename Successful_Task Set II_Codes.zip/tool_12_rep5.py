import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that define residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    residential_nodes.update(nodes)

# Find beams that connect the residential load area nodes
supporting_beams = []

for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create pairs of consecutive nodes (forming a cycle)
    node_pairs = []
    for i in range(len(nodes)):
        node_pairs.append((nodes[i], nodes[(i+1) % len(nodes)]))
    
    # Find elements that connect these node pairs
    for node1, node2 in node_pairs:
        # Find elements where both nodes match (in either direction)
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            # Check if it's a beam (same z-coordinate for both nodes)
            node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
            node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
            
            if node1_z == node2_z:  # It's a beam
                supporting_beams.append(element['Element ID'])

# Remove duplicates
supporting_beams = list(set(supporting_beams))

# Get beam information with section names
result_data = []
for beam_id in supporting_beams:
    element_info = element_df[element_df['Element ID'] == beam_id].iloc[0]
    section_num = element_info['Section']
    section_name = long_section_df[long_section_df['Section Number'] == section_num]['Section Name'].iloc[0]
    
    result_data.append({
        'Element ID': beam_id,
        'Section Name': section_name
    })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_12_out.csv', index=False)

print(f"Found {len(result_df)} beams supporting residential live load")
print(result_df)