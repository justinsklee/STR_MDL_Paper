import pandas as pd
import os

# Create output folder
os.makedirs('Task_28_out', exist_ok=True)

# Load the Support.csv file
support_df = pd.read_csv('Support.csv')

# Assign pin support to all supports
# Pin support means: Dx=1, Dy=1, Dz=1, Rx=0, Ry=0, Rz=0
support_df['Dx'] = 1
support_df['Dy'] = 1
support_df['Dz'] = 1
support_df['Rx'] = 0
support_df['Ry'] = 0
support_df['Rz'] = 0

# Save the updated Support.csv file
support_df.to_csv('Task_28_out/Support.csv', index=False)