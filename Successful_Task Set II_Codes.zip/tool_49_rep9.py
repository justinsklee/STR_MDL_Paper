import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Identify roof level (highest elevation)
roof_elevation = max(floor_elevations)

# Get unique X coordinates and sort them to identify grid X-1
x_coords = sorted(node_df['X (m)'].unique())
grid_x1_coord = x_coords[0]  # First X coordinate is grid X-1

# Filter nodes at roof level on grid X-1
roof_nodes_x1 = node_df[(node_df['Z (m)'] == roof_elevation) & 
                        (node_df['X (m)'] == grid_x1_coord)]

# Get roof beams (elements with both nodes at roof level and no change in Z)
roof_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1_data = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_data = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are at roof level (beams have same Z coordinate)
    if (node1_data['Z (m)'] == roof_elevation and 
        node2_data['Z (m)'] == roof_elevation):
        
        # Check if beam is on grid X-1 (both nodes have same X coordinate as grid X-1)
        if (node1_data['X (m)'] == grid_x1_coord and 
            node2_data['X (m)'] == grid_x1_coord):
            
            # Calculate beam length
            length = np.sqrt((node2_data['X (m)'] - node1_data['X (m)'])**2 + 
                           (node2_data['Y (m)'] - node1_data['Y (m)'])**2 + 
                           (node2_data['Z (m)'] - node1_data['Z (m)'])**2)
            
            # Check if length > 1.3m
            if length > 1.3:
                # Get section name
                section_num = element['Section']
                section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
                
                roof_beams.append({
                    'Element ID': element['Element ID'],
                    'Section Name': section_name
                })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(roof_beams)
if not result_df.empty:
    result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_49_out.csv', index=False)