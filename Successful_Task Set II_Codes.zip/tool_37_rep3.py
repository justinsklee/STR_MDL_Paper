import pandas as pd
import os

# Create output folder
os.makedirs('Task_37_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify columns (vertical elements)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Column: change in ONLY 'z' coordinates and no change in ('x' and 'y') coordinates
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams (horizontal elements)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Beam: NO change in 'z' coordinates
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    beam_element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_element['Node 1']
    node2_id = beam_element['Node 2']
    
    # Check if either node is connected to a column
    connected_to_column = False
    for column_id in columns:
        column_element = element_df[element_df['Element ID'] == column_id].iloc[0]
        column_node1 = column_element['Node 1']
        column_node2 = column_element['Node 2']
        
        if node1_id in [column_node1, column_node2] or node2_id in [column_node1, column_node2]:
            connected_to_column = True
            break
    
    if not connected_to_column:
        sub_beams.append(beam_id)

# Get beam-end-released elements
beam_end_released_elements = set(beam_end_release_df['Element ID'].tolist())

# Find sub-beams that are NOT beam-end-released
sub_beams_not_released = []
for sub_beam_id in sub_beams:
    if sub_beam_id not in beam_end_released_elements:
        sub_beams_not_released.append(sub_beam_id)

# Remove sub-beams that are not beam-end-released
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_not_released)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save the updated Element.csv file
updated_element_df.to_csv('Task_37_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_not_released)} sub-beams that are not beam-end-released")
print(f"Sub-beams removed: {sub_beams_not_released}")