import pandas as pd
import os

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
support_df = pd.read_csv('Support.csv')

# Create output folder
os.makedirs('Task_47_out', exist_ok=True)

# Find the first floor elevation (minimum z-coordinate)
first_floor_z = nodes_df['Z (m)'].min()

# Find Y-1 grid coordinate (minimum y-coordinate)
y1_grid_coord = nodes_df['Y (m)'].min()

# Find first floor columns along Y-1 grid with section 101
# Columns are vertical elements (same x,y coordinates, different z coordinates)
first_floor_columns_y1 = []

for _, element in elements_df.iterrows():
    if element['Section'] == 101:  # Section 101
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        # Check if it's a column (vertical element)
        if (node1['X (m)'] == node2['X (m)'] and 
            node1['Y (m)'] == node2['Y (m)'] and 
            node1['Z (m)'] != node2['Z (m)']):
            
            # Check if it's on Y-1 grid
            if node1['Y (m)'] == y1_grid_coord and node2['Y (m)'] == y1_grid_coord:
                
                # Check if one node is on first floor
                if node1['Z (m)'] == first_floor_z:
                    first_floor_columns_y1.append(node1_id)
                elif node2['Z (m)'] == first_floor_z:
                    first_floor_columns_y1.append(node2_id)

# Update support conditions for these nodes (assign pin support)
# Pin support: Dx=1, Dy=1, Dz=1, Rx=0, Ry=0, Rz=0
for node_id in first_floor_columns_y1:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Dx', 'Dy', 'Dz', 'Rx', 'Ry', 'Rz']] = [1, 1, 1, 0, 0, 0]

# Save updated Support.csv
support_df.to_csv('Task_47_out/Support.csv', index=False)

print(f"Updated support conditions for nodes: {first_floor_columns_y1}")
print("Support.csv has been saved to Task_47_out folder")