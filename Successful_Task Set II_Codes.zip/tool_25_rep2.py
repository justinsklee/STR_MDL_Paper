import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Create output folder
os.makedirs('Task_25_out', exist_ok=True)

# Find unique Z coordinates and sort them to identify floors
unique_z = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=first floor, 1=second floor, 2=third floor)
if len(unique_z) >= 3:
    third_floor_z = unique_z[2]
    
    # Find material number for SS400
    ss400_material = material_df[material_df['Name'] == 'SS400']['Material Number'].iloc[0]
    
    # Identify columns: elements where nodes have same X,Y but different Z coordinates
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if it's a column (same X,Y, different Z)
        is_column = (node1['X (m)'] == node2['X (m)'] and 
                    node1['Y (m)'] == node2['Y (m)'] and 
                    node1['Z (m)'] != node2['Z (m)'])
        
        if is_column:
            # Check if one node is at third floor and the other is above
            node1_z = node1['Z (m)']
            node2_z = node2['Z (m)']
            
            # Third floor columns have one node at third floor and one above
            if (node1_z == third_floor_z and node2_z > third_floor_z) or \
               (node2_z == third_floor_z and node1_z > third_floor_z):
                element_df.at[idx, 'Material'] = ss400_material

# Save updated Element.csv
element_df.to_csv('Task_25_out/Element.csv', index=False)