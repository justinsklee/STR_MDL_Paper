import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')
node_df = pd.read_csv('Node.csv')

# Identify columns (vertical elements with only z-coordinate change)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams (horizontal elements with no z-coordinate change)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Find nodes that are connected to columns
column_nodes = set()
for _, element in element_df.iterrows():
    if element['Element ID'] in columns:
        column_nodes.add(element['Node 1'])
        column_nodes.add(element['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    beam_element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_element['Node 1']
    node2_id = beam_element['Node 2']
    
    # Check if both nodes of the beam are NOT connected to columns
    if node1_id not in column_nodes and node2_id not in column_nodes:
        sub_beams.append(beam_id)

# Find sub-beams that are NOT beam-end-released
# Beam-end-released means both i-end and j-end release are '11'
released_elements = set()
for _, release in beam_end_release_df.iterrows():
    if release['i-end release'] == 11 and release['j-end release'] == 11:
        released_elements.add(release['Element ID'])

# Sub-beams that are NOT beam-end-released
sub_beams_not_released = [beam_id for beam_id in sub_beams if beam_id not in released_elements]

# Create output DataFrame
result_df = pd.DataFrame({'Element ID': sorted(sub_beams_not_released)})

# Save to CSV
result_df.to_csv('Task_10_out.csv', index=False)

print(f"Sub-beams not beam-end-released: {sorted(sub_beams_not_released)}")