import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_32_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Identify third floor elevation (index 2 since we start from 0)
if len(floor_elevations) >= 3:
    third_floor_z = floor_elevations[2]
    
    # Find braces on third floor
    # Braces have one node on the floor and another node above the floor
    third_floor_braces = []
    
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates of both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a brace (diagonal element with change in x/y AND z)
        x_change = node1_coords['X (m)'] != node2_coords['X (m)']
        y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        
        is_brace = (x_change or y_change) and z_change
        
        # Check if brace is associated with third floor
        # (one node at third floor elevation, other node above)
        if is_brace:
            node1_z = node1_coords['Z (m)']
            node2_z = node2_coords['Z (m)']
            
            third_floor_brace = ((node1_z == third_floor_z and node2_z > third_floor_z) or 
                               (node2_z == third_floor_z and node1_z > third_floor_z))
            
            if third_floor_brace:
                third_floor_braces.append(idx)
    
    # Update section for third floor braces to 102
    for idx in third_floor_braces:
        element_df.loc[idx, 'Section'] = 102

# Save updated Element.csv
element_df.to_csv('Task_32_out/Element.csv', index=False)