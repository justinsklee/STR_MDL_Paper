import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0-based: ground=0, second=1, third=2)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
else:
    print("Model does not have a third floor")
    exit()

# Get all beams on third floor (beams have same Z coordinate for both nodes)
third_floor_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam on third floor (same Z coordinates at third floor elevation)
    if (node1['Z (m)'] == third_floor_elevation and 
        node2['Z (m)'] == third_floor_elevation):
        third_floor_beams.append(element['Element ID'])

# Find columns on third floor (elements with one node at third floor and one above)
third_floor_columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (one node at third floor, one above)
    if ((node1['Z (m)'] == third_floor_elevation and node2['Z (m)'] > third_floor_elevation) or
        (node2['Z (m)'] == third_floor_elevation and node1['Z (m)'] > third_floor_elevation)):
        # Check if it's vertical (same x,y coordinates)
        if (node1['X (m)'] == node2['X (m)'] and node1['Y (m)'] == node2['Y (m)']):
            third_floor_columns.append(element['Element ID'])

# Get nodes that are connected to columns
column_connected_nodes = set()
for col_id in third_floor_columns:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get the node that's at third floor elevation
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    if node1['Z (m)'] == third_floor_elevation:
        column_connected_nodes.add(node1_id)
    if node2['Z (m)'] == third_floor_elevation:
        column_connected_nodes.add(node2_id)

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in third_floor_beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # If neither node is connected to a column, it's a sub-beam
    if node1_id not in column_connected_nodes and node2_id not in column_connected_nodes:
        sub_beams.append(beam_id)

# Create output data for sub-beams
output_data = []
for beam_id in sub_beams:
    # Check if beam has end release
    release_row = beam_end_release_df[beam_end_release_df['Element ID'] == beam_id]
    
    if not release_row.empty:
        i_release = release_row.iloc[0]['i-end release']
        j_release = release_row.iloc[0]['j-end release']
        
        # Convert release codes to 0/1 (0 for released, 1 for fixed)
        # Release code '11' means released, '10' means fixed
        i_status = 0 if str(i_release) == '11' else 1
        j_status = 0 if str(j_release) == '11' else 1
    else:
        # No release specified means fixed
        i_status = 1
        j_status = 1
    
    output_data.append([beam_id, i_status, j_status])

# Sort by element number
output_data.sort(key=lambda x: x[0])

# Create DataFrame and save to CSV
output_df = pd.DataFrame(output_data, columns=['Element Number', 'i-end (0=released, 1=fixed)', 'j-end (0=released, 1=fixed)'])
output_df.to_csv('Task_31_out.csv', index=False)

print(f"Found {len(sub_beams)} sub-beams on third floor")