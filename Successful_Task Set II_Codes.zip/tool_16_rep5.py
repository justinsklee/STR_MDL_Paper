import pandas as pd

# Load the Support.csv file
support_df = pd.read_csv('Support.csv')

# Create output dataframe with support information
output_df = support_df[['Node', 'Dx', 'Dy', 'Dz', 'Rx', 'Ry', 'Rz']].copy()

# Save to CSV file
output_df.to_csv('Task_16_out.csv', index=False)

print("Support conditions:")
print(output_df.to_string(index=False))