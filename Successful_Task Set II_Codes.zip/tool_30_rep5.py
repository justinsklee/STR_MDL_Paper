import pandas as pd
import os

# Create output folder
os.makedirs('Task_30_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Identify fourth floor elevation (index 3 since we start from 0)
if len(floor_elevations) >= 4:
    fourth_floor_z = floor_elevations[3]
else:
    print(f"Model only has {len(floor_elevations)} floors. Cannot remove braces from fourth floor.")
    exit()

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if element is a brace (diagonal: changes in x/y AND z coordinates)
    x_change = abs(x2 - x1) > 1e-6
    y_change = abs(y2 - y1) > 1e-6
    z_change = abs(z2 - z1) > 1e-6
    
    if (x_change or y_change) and z_change:
        return 'brace'
    elif z_change and not (x_change or y_change):
        return 'column'
    elif not z_change:
        return 'beam'
    else:
        return 'unknown'

# Identify braces on fourth floor
braces_to_remove = []

for idx, row in element_df.iterrows():
    element_type = classify_element(row)
    
    if element_type == 'brace':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        z1, z2 = node1['Z (m)'], node2['Z (m)']
        
        # Check if brace has one node on fourth floor and other node above
        if (abs(z1 - fourth_floor_z) < 1e-6 and z2 > fourth_floor_z) or \
           (abs(z2 - fourth_floor_z) < 1e-6 and z1 > fourth_floor_z):
            braces_to_remove.append(row['Element ID'])

# Remove braces from fourth floor
updated_element_df = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_30_out/Element.csv', index=False)

print(f"Removed {len(braces_to_remove)} braces from fourth floor (z = {fourth_floor_z}m)")
if braces_to_remove:
    print(f"Removed brace elements: {braces_to_remove}")