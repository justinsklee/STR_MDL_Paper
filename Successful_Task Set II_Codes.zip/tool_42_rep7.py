import pandas as pd
import os

# Create output folder
os.makedirs('Task_42_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check coordinate changes
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    # Classify based on coordinate changes
    if z_change and not x_change and not y_change:
        return 'column'
    elif not z_change:
        return 'beam'
    elif z_change and (x_change or y_change):
        return 'brace'
    else:
        return 'unknown'

# Add classification to element dataframe
element_df['classification'] = element_df.apply(classify_element, axis=1)

# Find beams on the roof
roof_beams = element_df[
    (element_df['classification'] == 'beam') &
    (element_df.apply(lambda row: 
        node_df[node_df['Node ID'] == row['Node 1']]['Z (m)'].iloc[0] == roof_elevation and
        node_df[node_df['Node ID'] == row['Node 2']]['Z (m)'].iloc[0] == roof_elevation, axis=1))
]

# Find all braces
braces = element_df[element_df['classification'] == 'brace']

# Get all nodes that are connected to braces
brace_nodes = set()
for _, brace in braces.iterrows():
    brace_nodes.add(brace['Node 1'])
    brace_nodes.add(brace['Node 2'])

# Find roof beams not connected to any braces
roof_beams_no_braces = []
for _, beam in roof_beams.iterrows():
    beam_node1 = beam['Node 1']
    beam_node2 = beam['Node 2']
    
    # Check if either node is connected to a brace
    if beam_node1 not in brace_nodes and beam_node2 not in brace_nodes:
        roof_beams_no_braces.append(beam['Element ID'])

# Update section for these beams
for beam_id in roof_beams_no_braces:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 104

# Remove the classification column before saving
element_df = element_df.drop('classification', axis=1)

# Save updated Element.csv file
element_df.to_csv('Task_42_out/Element.csv', index=False)

print(f"Updated {len(roof_beams_no_braces)} roof beams to section 104")
print(f"Beam IDs updated: {roof_beams_no_braces}")