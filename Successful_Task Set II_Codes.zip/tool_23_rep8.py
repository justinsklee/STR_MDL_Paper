import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Create output folder
output_folder = 'Task_23_out'
os.makedirs(output_folder, exist_ok=True)

# Find the section number for H 100x100x6/8
target_section = section_df[section_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_elevation = floor_elevations[0]  # Ground level (z = 0.0m)
second_floor_elevation = floor_elevations[1]  # First floor above ground

# Identify first floor braces
first_floor_braces = []

for idx, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a brace (change in x/y AND z coordinates)
    x_change = node1['X (m)'] != node2['X (m)']
    y_change = node1['Y (m)'] != node2['Y (m)']
    z_change = node1['Z (m)'] != node2['Z (m)']
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if it's a first floor brace (one node at first floor, other above)
        node1_z = node1['Z (m)']
        node2_z = node2['Z (m)']
        
        is_first_floor_brace = ((node1_z == first_floor_elevation and node2_z == second_floor_elevation) or
                               (node2_z == first_floor_elevation and node1_z == second_floor_elevation))
        
        if is_first_floor_brace:
            first_floor_braces.append(element['Element ID'])

# Update section for first floor braces
for element_id in first_floor_braces:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = target_section

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Updated {len(first_floor_braces)} first floor braces to section H 100x100x6/8")
print(f"First floor brace elements: {first_floor_braces}")