import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique z-coordinates to identify floors
z_coords = sorted(node_df['Z (m)'].unique())
roof_level = max(z_coords)

# Get all nodes at roof level
roof_nodes = node_df[node_df['Z (m)'] == roof_level]['Node ID'].tolist()

# Identify beams (elements with no change in z-coordinates)
beams = []
for _, element in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
    
    if node1_z == node2_z:  # Beam (horizontal element)
        beams.append(element['Element ID'])

# Get beams at roof level
roof_beams = []
for beam_id in beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    
    if node1_z == roof_level:
        roof_beams.append(beam_id)

# Identify columns (elements with change only in z-coordinates)
columns = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Column: only z changes, x and y remain same
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Find sub-beams (beams not directly connected to columns)
sub_beams_roof = []
for beam_id in roof_beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Check if beam is connected to any column
    connected_to_column = False
    for col_id in columns:
        col_element = element_df[element_df['Element ID'] == col_id].iloc[0]
        col_nodes = [col_element['Node 1'], col_element['Node 2']]
        
        if node1_id in col_nodes or node2_id in col_nodes:
            connected_to_column = True
            break
    
    if not connected_to_column:
        sub_beams_roof.append(beam_id)

# Update section for sub-beams on roof to 104
for beam_id in sub_beams_roof:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 104

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_22_out/Element.csv', index=False)