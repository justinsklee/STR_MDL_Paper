import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Filter for residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all beam element numbers supporting residential loads
supporting_beams = set()

for _, load in residential_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create pairs of consecutive nodes (including wrap-around from last to first)
    node_pairs = []
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]  # Wrap around to first node
        node_pairs.append((min(node1, node2), max(node1, node2)))
    
    # Find elements that connect these node pairs
    for node1, node2 in node_pairs:
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        # Add element IDs to the set
        supporting_beams.update(matching_elements['Element ID'].tolist())

# Convert to sorted list and create DataFrame
beam_list = sorted(list(supporting_beams))
result_df = pd.DataFrame({'Element ID': beam_list})

# Save to CSV
result_df.to_csv('Task_5_out.csv', index=False)

print("Beams supporting residential live loads:")
print(result_df)