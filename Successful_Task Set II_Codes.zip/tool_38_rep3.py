import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_38_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
materials_df = pd.read_csv('Material.csv')

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find unique X coordinates to determine grid positions
unique_x = sorted(nodes_df['X (m)'].unique())

# Find X-2 grid coordinate (second X grid)
if len(unique_x) >= 2:
    x2_coord = unique_x[1]  # Second X grid
else:
    print("Not enough X grids found")
    exit()

# Find material number for SHN355
shn355_material = materials_df[materials_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Find first floor columns along grid X-2
# Columns are vertical elements with one node at first floor and other node above
first_floor_nodes = nodes_df[nodes_df['Z (m)'] == first_floor_z]
x2_first_floor_nodes = first_floor_nodes[first_floor_nodes['X (m)'] == x2_coord]['Node ID'].tolist()

# Find columns that have one node at first floor X-2 grid and other node above
for idx, row in elements_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a column (vertical element)
    is_vertical = (node1['X (m)'] == node2['X (m)'] and 
                   node1['Y (m)'] == node2['Y (m)'] and 
                   node1['Z (m)'] != node2['Z (m)'])
    
    if is_vertical:
        # Check if column is on X-2 grid and has one node at first floor
        on_x2_grid = (node1['X (m)'] == x2_coord and node2['X (m)'] == x2_coord)
        
        # Check if one node is at first floor and other is above
        node1_at_first_floor = (node1['Z (m)'] == first_floor_z)
        node2_at_first_floor = (node2['Z (m)'] == first_floor_z)
        node1_above_first = (node1['Z (m)'] > first_floor_z)
        node2_above_first = (node2['Z (m)'] > first_floor_z)
        
        first_floor_column = ((node1_at_first_floor and node2_above_first) or 
                             (node2_at_first_floor and node1_above_first))
        
        if on_x2_grid and first_floor_column:
            elements_df.at[idx, 'Material'] = shn355_material

# Save updated Element.csv file
elements_df.to_csv('Task_38_out/Element.csv', index=False)