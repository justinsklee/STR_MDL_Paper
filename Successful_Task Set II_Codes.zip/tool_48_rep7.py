import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_48_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the first floor elevation (ground level)
first_floor_z = node_df['Z (m)'].min()

# Find the second floor elevation
second_floor_z = node_df[node_df['Z (m)'] > first_floor_z]['Z (m)'].min()

# Find Y-1 grid coordinate (minimum Y coordinate)
y1_coord = node_df['Y (m)'].min()

# Identify first floor braces along grid Y-1 with section 101
first_floor_braces_y1 = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    section = row['Section']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal: change in z AND (x or y))
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 0
    x_or_y_change = (abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 0) or (abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 0)
    is_brace = z_change and x_or_y_change
    
    # Check if brace is along grid Y-1 (both nodes have Y coordinate = y1_coord)
    on_y1_grid = (node1_coords['Y (m)'] == y1_coord) and (node2_coords['Y (m)'] == y1_coord)
    
    # Check if brace has one node on first floor and other node above first floor
    node1_on_first_floor = node1_coords['Z (m)'] == first_floor_z
    node2_above_first_floor = node2_coords['Z (m)'] > first_floor_z
    node2_on_first_floor = node2_coords['Z (m)'] == first_floor_z
    node1_above_first_floor = node1_coords['Z (m)'] > first_floor_z
    
    first_floor_brace = (node1_on_first_floor and node2_above_first_floor) or (node2_on_first_floor and node1_above_first_floor)
    
    # Check if section is 101
    has_section_101 = section == 101
    
    if is_brace and on_y1_grid and first_floor_brace and has_section_101:
        first_floor_braces_y1.append(idx)

# Update section to 103 for identified braces
for idx in first_floor_braces_y1:
    element_df.at[idx, 'Section'] = 103

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_48_out/Element.csv', index=False)