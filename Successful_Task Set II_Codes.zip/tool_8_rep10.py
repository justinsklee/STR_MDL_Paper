import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get supported node IDs
supported_nodes = set(support_df['Node'].tolist())

# Classify elements based on node coordinates
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Column: vertical elements (only z changes)
    if x1 == x2 and y1 == y2 and z1 != z2:
        return 'Column'
    # Beam: horizontal elements (no z change)
    elif z1 == z2:
        return 'Beam'
    # Brace: diagonal elements (x or y changes AND z changes)
    elif (x1 != x2 or y1 != y2) and z1 != z2:
        return 'Brace'
    else:
        return 'Unknown'

# Classify all elements
element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Get columns and braces
columns = element_df[element_df['Element_Type'] == 'Column']
braces = element_df[element_df['Element_Type'] == 'Brace']

# Find nodes that are connected to braces and have supports
brace_nodes_with_supports = set()
for _, brace in braces.iterrows():
    node1, node2 = brace['Node 1'], brace['Node 2']
    if node1 in supported_nodes:
        brace_nodes_with_supports.add(node1)
    if node2 in supported_nodes:
        brace_nodes_with_supports.add(node2)

# Find columns that share supports with bracing elements
columns_sharing_supports = []
for _, column in columns.iterrows():
    node1, node2 = column['Node 1'], column['Node 2']
    if node1 in brace_nodes_with_supports or node2 in brace_nodes_with_supports:
        columns_sharing_supports.append(column['Element ID'])

# Create output dataframe
result_df = pd.DataFrame({
    'Element ID': sorted(columns_sharing_supports)
})

# Save to CSV
result_df.to_csv('Task_8_out.csv', index=False)