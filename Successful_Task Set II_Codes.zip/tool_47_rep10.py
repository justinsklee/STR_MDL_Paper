import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_47_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
support_df = pd.read_csv('Support.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find Y-1 grid coordinate (minimum y-coordinate)
y1_coord = nodes_df['Y (m)'].min()

# Find nodes on first floor and Y-1 grid
first_floor_nodes = nodes_df[nodes_df['Z (m)'] == first_floor_z]
y1_nodes = first_floor_nodes[first_floor_nodes['Y (m)'] == y1_coord]['Node ID'].tolist()

# Find columns with section 101 that have one node on first floor Y-1 grid
# and the other node above the first floor
columns_section_101 = elements_df[elements_df['Section'] == 101]

# Identify columns (vertical elements - only z-coordinate changes)
target_columns = []
for _, element in columns_section_101.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_data = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2_data = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only z changes, x and y stay same)
    x_change = abs(node1_data['X (m)'] - node2_data['X (m)']) < 1e-6
    y_change = abs(node1_data['Y (m)'] - node2_data['Y (m)']) < 1e-6
    z_change = abs(node1_data['Z (m)'] - node2_data['Z (m)']) > 1e-6
    
    if x_change and y_change and z_change:
        # Check if one node is on first floor Y-1 grid and other is above
        node1_on_first_floor = (abs(node1_data['Z (m)'] - first_floor_z) < 1e-6)
        node2_on_first_floor = (abs(node2_data['Z (m)'] - first_floor_z) < 1e-6)
        
        node1_on_y1 = (abs(node1_data['Y (m)'] - y1_coord) < 1e-6)
        node2_on_y1 = (abs(node2_data['Y (m)'] - y1_coord) < 1e-6)
        
        # One node should be on first floor Y-1, other should be above first floor
        if ((node1_on_first_floor and node1_on_y1 and node2_data['Z (m)'] > first_floor_z) or
            (node2_on_first_floor and node2_on_y1 and node1_data['Z (m)'] > first_floor_z)):
            
            # Find the node on first floor Y-1 grid
            if node1_on_first_floor and node1_on_y1:
                target_node = node1_id
            else:
                target_node = node2_id
            
            target_columns.append(target_node)

# Update support conditions to pin (Dx=1, Dy=1, Dz=1, Rx=0, Ry=0, Rz=0)
for node_id in target_columns:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated Support.csv
support_df.to_csv('Task_47_out/Support.csv', index=False)

print(f"Updated support conditions for {len(target_columns)} first floor columns along grid Y-1 with section 101")
print("Target nodes:", target_columns)