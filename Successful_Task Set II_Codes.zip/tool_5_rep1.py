import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Filter residential loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all beam element IDs supporting residential loads
supporting_beams = set()

for _, load in residential_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create pairs of consecutive nodes (forming the perimeter)
    node_pairs = []
    for i in range(len(nodes)):
        node_pairs.append((nodes[i], nodes[(i + 1) % len(nodes)]))
    
    # Find beams that connect these node pairs
    for node1, node2 in node_pairs:
        # Find elements that connect these two nodes
        beam_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        # Filter for beams (horizontal elements - no change in Z coordinate)
        for _, element in beam_elements.iterrows():
            node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
            node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
            
            # Check if it's a beam (no change in Z coordinate)
            if node1_z == node2_z:
                supporting_beams.add(element['Element ID'])

# Convert to sorted list
beam_list = sorted(list(supporting_beams))

# Create output dataframe
output_df = pd.DataFrame({'Element ID': beam_list})

# Save to CSV
output_df.to_csv('Task_5_out.csv', index=False)

print("Beam elements supporting residential live loads:")
print(output_df)