import pandas as pd
import os

# Create output folder
output_folder = 'Task_37_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Create node coordinate lookup
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Identify columns (vertical elements - change only in z coordinates)
columns = set()
for _, row in element_df.iterrows():
    node1 = int(row['Node 1'])
    node2 = int(row['Node 2'])
    
    x1, y1, z1 = node_coords[node1]
    x2, y2, z2 = node_coords[node2]
    
    # Column: change only in z, no change in x and y
    if x1 == x2 and y1 == y2 and z1 != z2:
        columns.add(row['Element ID'])

# Identify beams (horizontal elements - no change in z coordinates)
beams = set()
for _, row in element_df.iterrows():
    node1 = int(row['Node 1'])
    node2 = int(row['Node 2'])
    
    x1, y1, z1 = node_coords[node1]
    x2, y2, z2 = node_coords[node2]
    
    # Beam: no change in z
    if z1 == z2:
        beams.add(row['Element ID'])

# Find beams that are directly connected to columns
beams_connected_to_columns = set()
for beam_id in beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_node1 = int(beam_row['Node 1'])
    beam_node2 = int(beam_row['Node 2'])
    
    # Check if any column shares a node with this beam
    for column_id in columns:
        column_row = element_df[element_df['Element ID'] == column_id].iloc[0]
        column_node1 = int(column_row['Node 1'])
        column_node2 = int(column_row['Node 2'])
        
        if beam_node1 in [column_node1, column_node2] or beam_node2 in [column_node1, column_node2]:
            beams_connected_to_columns.add(beam_id)
            break

# Sub-beams are beams that are NOT directly connected to columns
sub_beams = beams - beams_connected_to_columns

# Get beam-end-released elements
beam_end_released = set(beam_end_release_df['Element ID'].tolist())

# Remove sub-beams that are NOT beam-end-released
sub_beams_not_released = sub_beams - beam_end_released
elements_to_remove = sub_beams_not_released

# Filter out the elements to be removed
updated_element_df = element_df[~element_df['Element ID'].isin(elements_to_remove)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)