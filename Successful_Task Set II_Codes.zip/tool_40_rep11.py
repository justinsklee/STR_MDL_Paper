import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_40_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Identify second floor elevation
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor (index 1)

# Identify Y-1 grid coordinate (minimum Y coordinate)
y_grid_coords = sorted(node_df['Y (m)'].unique())
y1_coord = y_grid_coords[0]  # Y-1 grid

# Identify braces on second floor along grid Y-1
elements_to_remove = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal - changes in x/y AND z coordinates)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if brace is on second floor (one node at second floor, other above)
        node1_at_second_floor = abs(node1['Z (m)'] - second_floor_z) < 1e-6
        node2_at_second_floor = abs(node2['Z (m)'] - second_floor_z) < 1e-6
        node1_above_second_floor = node1['Z (m)'] > second_floor_z
        node2_above_second_floor = node2['Z (m)'] > second_floor_z
        
        is_second_floor_brace = (node1_at_second_floor and node2_above_second_floor) or \
                               (node2_at_second_floor and node1_above_second_floor)
        
        if is_second_floor_brace:
            # Check if brace is along grid Y-1 (both nodes have same Y coordinate as Y-1)
            node1_on_y1 = abs(node1['Y (m)'] - y1_coord) < 1e-6
            node2_on_y1 = abs(node2['Y (m)'] - y1_coord) < 1e-6
            
            if node1_on_y1 and node2_on_y1:
                elements_to_remove.append(row['Element ID'])

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(elements_to_remove)]

# Sort by Element ID in ascending order
element_df_updated = element_df_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df_updated.to_csv('Task_40_out/Element.csv', index=False)