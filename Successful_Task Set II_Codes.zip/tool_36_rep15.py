import pandas as pd
import os

# Create output folder
os.makedirs('Task_36_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support node IDs
support_nodes = set(support_df['Node'].tolist())

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if it's a column (vertical: only z changes)
    if x1 == x2 and y1 == y2 and z1 != z2:
        return 'column'
    # Check if it's a beam (horizontal: no z change)
    elif z1 == z2:
        return 'beam'
    # Otherwise it's a brace (diagonal: x or y changes AND z changes)
    else:
        return 'brace'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find columns that share supports with bracing elements
columns_to_update = set()

for _, element in element_df.iterrows():
    if element['element_type'] == 'brace':
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Check if either node is a support
        if node1_id in support_nodes or node2_id in support_nodes:
            # Find columns that share these support nodes
            for _, col_element in element_df.iterrows():
                if col_element['element_type'] == 'column':
                    col_node1 = col_element['Node 1']
                    col_node2 = col_element['Node 2']
                    
                    # Check if column shares a support node with the brace
                    if (col_node1 in support_nodes and col_node1 in [node1_id, node2_id]) or \
                       (col_node2 in support_nodes and col_node2 in [node1_id, node2_id]):
                        columns_to_update.add(col_element['Element ID'])

# Update section for identified columns
for col_id in columns_to_update:
    element_df.loc[element_df['Element ID'] == col_id, 'Section'] = 101

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv file
element_df.to_csv('Task_36_out/Element.csv', index=False)