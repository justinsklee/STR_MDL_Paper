import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Get office load areas
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Extract nodes for office loads
office_nodes = []
for _, row in office_loads.iterrows():
    nodes_str = row['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.extend(nodes)

# Remove duplicates
office_nodes = list(set(office_nodes))

# Find columns supporting office loads
# Columns are vertical elements and support loads from below
# For each office load node, find columns that have one end at that node
# and the other end below (smaller z-coordinate)

supporting_columns = []

for node_id in office_nodes:
    # Get the z-coordinate of the office load node
    office_node_z = node_df[node_df['Node ID'] == node_id]['Z (m)'].iloc[0]
    
    # Find elements connected to this node
    elements_with_node = element_df[
        (element_df['Node 1'] == node_id) | (element_df['Node 2'] == node_id)
    ]
    
    for _, element in elements_with_node.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates of both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if element is vertical (column)
        # Columns have change only in z-coordinate, no change in x and y
        if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
            node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
            node1_coords['Z (m)'] != node2_coords['Z (m)']):
            
            # Check if this column supports the office load from below
            # One node should be at office level, other should be below
            if ((node1_id == node_id and node2_coords['Z (m)'] < office_node_z) or
                (node2_id == node_id and node1_coords['Z (m)'] < office_node_z)):
                supporting_columns.append(element['Element ID'])

# Remove duplicates and sort
supporting_columns = sorted(list(set(supporting_columns)))

# Create output dataframe
output_df = pd.DataFrame({
    'Element ID': supporting_columns
})

# Save to CSV
output_df.to_csv('Task_6_out.csv', index=False)