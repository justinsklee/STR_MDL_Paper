import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_40_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Identify second floor elevation (one floor above ground level z=0)
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor is index 1 (ground is index 0)

# Identify Y-1 grid coordinate (minimum Y coordinate)
y_coordinates = sorted(node_df['Y (m)'].unique())
y1_grid_coord = y_coordinates[0]  # Y-1 grid is the minimum Y coordinate

# Find nodes on second floor and Y-1 grid
second_floor_nodes = node_df[node_df['Z (m)'] == second_floor_z]['Node ID'].tolist()
y1_grid_nodes = node_df[node_df['Y (m)'] == y1_grid_coord]['Node ID'].tolist()

# Identify braces on second floor along Y-1 grid
braces_to_remove = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal: change in x/y AND z coordinates)
    x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 1e-6
    y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 1e-6
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if brace is along Y-1 grid (both nodes have same Y coordinate as Y-1 grid)
        node1_on_y1 = abs(node1_coords['Y (m)'] - y1_grid_coord) < 1e-6
        node2_on_y1 = abs(node2_coords['Y (m)'] - y1_grid_coord) < 1e-6
        
        # Check if one node is on second floor and the other is above it
        node1_on_second = abs(node1_coords['Z (m)'] - second_floor_z) < 1e-6
        node2_above_second = node2_coords['Z (m)'] > second_floor_z
        node2_on_second = abs(node2_coords['Z (m)'] - second_floor_z) < 1e-6
        node1_above_second = node1_coords['Z (m)'] > second_floor_z
        
        second_floor_brace = (node1_on_second and node2_above_second) or (node2_on_second and node1_above_second)
        
        if node1_on_y1 and node2_on_y1 and second_floor_brace:
            braces_to_remove.append(row['Element ID'])

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID in ascending order
element_df_updated = element_df_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv file
element_df_updated.to_csv('Task_40_out/Element.csv', index=False)

print(f"Removed {len(braces_to_remove)} braces from second floor along grid Y-1")
if braces_to_remove:
    print(f"Removed brace elements: {braces_to_remove}")