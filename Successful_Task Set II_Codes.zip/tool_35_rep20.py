import pandas as pd
import os

# Create output folder
os.makedirs('Task_35_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that define residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    residential_nodes.update(nodes)

# Find columns that support residential loads (columns attached to residential load nodes from below)
supporting_columns = []
for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get node coordinates
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if element is a column (vertical - only z changes)
    is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                node1_coords['Z (m)'] != node2_coords['Z (m)'])
    
    if is_column:
        # Check if column supports residential load (has node attached to residential load area)
        # Column supports load from below, so check if the upper node is in residential load area
        upper_node = node1 if node1_coords['Z (m)'] > node2_coords['Z (m)'] else node2
        
        if upper_node in residential_nodes:
            supporting_columns.append(element_id)

# Update material for supporting columns to SHN355 (material 1003)
for col_id in supporting_columns:
    element_df.loc[element_df['Element ID'] == col_id, 'Material'] = 1003

# Save updated Element.csv
element_df.to_csv('Task_35_out/Element.csv', index=False)

print(f"Updated {len(supporting_columns)} columns supporting residential loads to SHN355 material")
print(f"Column IDs updated: {supporting_columns}")