import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find X-1 grid coordinate (first unique X coordinate when sorted)
unique_x_coords = sorted(node_df['X (m)'].unique())
x1_coord = unique_x_coords[0]

# Merge element data with node coordinates for both nodes
element_with_nodes = element_df.merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 1', right_on='Node ID', 
    suffixes=('', '_node1')
).merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 2', right_on='Node ID', 
    suffixes=('', '_node2')
)

# Classify elements as braces (diagonal elements: change in both horizontal and vertical coordinates)
element_with_nodes['is_brace'] = (
    (element_with_nodes['X (m)'] != element_with_nodes['X (m)_node2']) | 
    (element_with_nodes['Y (m)'] != element_with_nodes['Y (m)_node2'])
) & (element_with_nodes['Z (m)'] != element_with_nodes['Z (m)_node2'])

# Filter braces along grid X-1 (both nodes have X-coordinate equal to X-1 grid)
braces_on_x1 = element_with_nodes[
    element_with_nodes['is_brace'] & 
    (element_with_nodes['X (m)'] == x1_coord) & 
    (element_with_nodes['X (m)_node2'] == x1_coord)
]

# Extract element numbers and sort in ascending order
brace_elements = braces_on_x1[['Element ID']].sort_values('Element ID')

# Save to CSV
brace_elements.to_csv('Task_3_out.csv', index=False)