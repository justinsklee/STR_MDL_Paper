import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Filter for residential loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all beam elements (horizontal elements with no change in Z coordinate)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in Z coordinate)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append({
            'Element ID': element['Element ID'],
            'Node 1': node1_id,
            'Node 2': node2_id,
            'Z': node1['Z (m)']
        })

beams_df = pd.DataFrame(beams)

# Find beams supporting residential loads
supporting_beam_ids = set()

for _, load in residential_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area'].strip()
    node_ids = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Get the Z coordinate of the load area (all nodes should be at same level)
    load_z = node_df[node_df['Node ID'] == node_ids[0]]['Z (m)'].iloc[0]
    
    # Find beams that connect these nodes and are at the same elevation
    for i in range(len(node_ids)):
        node_a = node_ids[i]
        node_b = node_ids[(i + 1) % len(node_ids)]  # Connect in a loop
        
        # Find beam connecting these two nodes
        supporting_beam = beams_df[
            (((beams_df['Node 1'] == node_a) & (beams_df['Node 2'] == node_b)) |
             ((beams_df['Node 1'] == node_b) & (beams_df['Node 2'] == node_a))) &
            (beams_df['Z'] == load_z)
        ]
        
        if not supporting_beam.empty:
            supporting_beam_ids.add(supporting_beam.iloc[0]['Element ID'])

# Create output dataframe
result_df = pd.DataFrame({'Element ID': sorted(list(supporting_beam_ids))})

# Save to CSV
result_df.to_csv('Task_5_out.csv', index=False)