import pandas as pd
import os

# Create output folder
os.makedirs('Task_29_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the highest z-coordinate (roof level)
roof_level = node_df['Z (m)'].max()

# Identify columns (vertical elements)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams on the roof level
roof_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a beam on roof level
    if (node1['Z (m)'] == node2['Z (m)'] == roof_level):
        roof_beams.append(element['Element ID'])

# Find nodes connected to columns on roof level
column_connected_nodes = set()
for _, element in element_df.iterrows():
    if element['Element ID'] in columns:
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Add roof level node to column_connected_nodes
        if node1['Z (m)'] == roof_level:
            column_connected_nodes.add(node1_id)
        if node2['Z (m)'] == roof_level:
            column_connected_nodes.add(node2_id)

# Identify sub-beams on roof (beams not directly connected to columns)
sub_beams_to_remove = []
for beam_id in roof_beams:
    beam = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam['Node 1']
    node2_id = beam['Node 2']
    
    # If neither node is connected to a column, it's a sub-beam
    if node1_id not in column_connected_nodes and node2_id not in column_connected_nodes:
        sub_beams_to_remove.append(beam_id)

# Remove sub-beams from element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_to_remove)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_29_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_to_remove)} sub-beams from roof level")
print(f"Sub-beams removed: {sub_beams_to_remove}")