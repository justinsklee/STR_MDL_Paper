import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find section number for H 175x175x7.5/11
target_section = section_df[section_df['Section Name'] == 'H 175x175x7.5/11']['Section Number'].iloc[0]

# Get elements with the target section
elements_with_section = element_df[element_df['Section'] == target_section]

# Filter for columns (vertical elements - only z coordinates change, x and y remain same)
column_elements = []

for _, element in elements_with_section.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only z changes, x and y stay same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        column_elements.append(element['Element ID'])

# Create output dataframe
result_df = pd.DataFrame({'Element ID': sorted(column_elements)})

# Save to CSV
result_df.to_csv('Task_4_out.csv', index=False)