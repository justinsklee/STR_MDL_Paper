import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_39_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique x-coordinates to identify grids
unique_x = sorted(node_df['X (m)'].unique())
x1_coord = unique_x[0]  # X-1 grid coordinate (first x-coordinate)

# Get unique z-coordinates to identify floors
unique_z = sorted(node_df['Z (m)'].unique())
first_floor_z = unique_z[0]  # First floor elevation
second_floor_z = unique_z[1]  # Second floor elevation

# Find braces on first floor along grid X-1
# Braces are diagonal elements (change in x/y AND z coordinates)
# First floor braces have one node at first floor and another above first floor
# Grid X-1 braces have both nodes sharing the same x-coordinate as X-1

elements_to_remove = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on grid X-1 (same x-coordinate as X-1)
    if node1['X (m)'] == x1_coord and node2['X (m)'] == x1_coord:
        
        # Check if it's a brace (change in z AND change in x or y)
        z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 0
        x_change = abs(node1['X (m)'] - node2['X (m)']) > 0
        y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 0
        
        is_brace = z_change and (x_change or y_change)
        
        # Check if it's on first floor (one node at first floor, other above)
        node_z_values = [node1['Z (m)'], node2['Z (m)']]
        has_first_floor_node = first_floor_z in node_z_values
        has_node_above_first_floor = any(z > first_floor_z for z in node_z_values)
        
        is_first_floor_brace = has_first_floor_node and has_node_above_first_floor
        
        if is_brace and is_first_floor_brace:
            elements_to_remove.append(row['Element ID'])

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(elements_to_remove)]

# Save updated Element.csv
element_df_updated.to_csv('Task_39_out/Element.csv', index=False)

print(f"Removed {len(elements_to_remove)} braces on first floor along grid X-1")
if elements_to_remove:
    print(f"Removed element IDs: {elements_to_remove}")