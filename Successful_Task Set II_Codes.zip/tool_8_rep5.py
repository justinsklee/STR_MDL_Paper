import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get supported node IDs
supported_nodes = set(support_df['Node'].tolist())

# Classify elements
columns = []
braces = []

for _, row in element_df.iterrows():
    element_id = row['Element ID']
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if coordinates change
    x_change = abs(x2 - x1) > 1e-6
    y_change = abs(y2 - y1) > 1e-6
    z_change = abs(z2 - z1) > 1e-6
    
    # Classify element
    if z_change and not x_change and not y_change:
        # Column: only z changes
        columns.append(element_id)
    elif (x_change or y_change) and z_change:
        # Brace: x or y changes AND z changes
        braces.append(element_id)

# Find columns that share supports with bracing elements
columns_sharing_supports_with_braces = []

for col_id in columns:
    col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
    col_node1 = col_row['Node 1']
    col_node2 = col_row['Node 2']
    col_nodes = {col_node1, col_node2}
    
    # Check if column has nodes that are supported
    col_supported_nodes = col_nodes.intersection(supported_nodes)
    
    if col_supported_nodes:
        # Check if any brace shares these supported nodes
        for brace_id in braces:
            brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
            brace_node1 = brace_row['Node 1']
            brace_node2 = brace_row['Node 2']
            brace_nodes = {brace_node1, brace_node2}
            
            # Check if brace shares any supported nodes with column
            if col_supported_nodes.intersection(brace_nodes):
                columns_sharing_supports_with_braces.append(col_id)
                break

# Remove duplicates and sort
columns_sharing_supports_with_braces = sorted(list(set(columns_sharing_supports_with_braces)))

# Create output DataFrame
output_df = pd.DataFrame({
    'Element ID': columns_sharing_supports_with_braces
})

# Save to CSV
output_df.to_csv('Task_8_out.csv', index=False)

print(f"Found {len(columns_sharing_supports_with_braces)} columns sharing supports with bracing elements")
print(output_df)