import pandas as pd
import os

# Create output folder
os.makedirs('Task_40_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find Y-1 grid coordinate (minimum Y coordinate)
y1_coord = node_df['Y (m)'].min()

# Find second floor elevation (second unique Z value when sorted)
unique_z = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z[1]

# Identify braces: elements with change in both (x or y) AND z coordinates
braces_to_remove = []

for idx, row in element_df.iterrows():
    element_id = row['Element ID']
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a brace (change in x/y AND z)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if brace is on Y-1 grid (both nodes have Y coordinate equal to y1_coord)
        on_y1_grid = (abs(node1['Y (m)'] - y1_coord) < 1e-6 and 
                      abs(node2['Y (m)'] - y1_coord) < 1e-6)
        
        # Check if brace is associated with second floor
        # (one node at second floor, other node above second floor)
        node1_at_second = abs(node1['Z (m)'] - second_floor_z) < 1e-6
        node2_at_second = abs(node2['Z (m)'] - second_floor_z) < 1e-6
        node1_above_second = node1['Z (m)'] > second_floor_z
        node2_above_second = node2['Z (m)'] > second_floor_z
        
        second_floor_brace = (node1_at_second and node2_above_second) or (node2_at_second and node1_above_second)
        
        if on_y1_grid and second_floor_brace:
            braces_to_remove.append(element_id)

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID
element_df_updated = element_df_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df_updated.to_csv('Task_40_out/Element.csv', index=False)

print(f"Removed {len(braces_to_remove)} second floor braces along grid Y-1")
if braces_to_remove:
    print(f"Removed elements: {braces_to_remove}")