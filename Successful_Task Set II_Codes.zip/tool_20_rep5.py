import pandas as pd
import numpy as np
import math

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find second floor elevation (one story above ground)
unique_z = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z[1] if len(unique_z) > 1 else None

# Identify first floor columns
# Columns are vertical elements with one node at first floor and other node above first floor
first_floor_columns = []

for idx, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element)
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Column: no change in x,y coordinates, change only in z
    is_column = (x1 == x2) and (y1 == y2) and (z1 != z2)
    
    if is_column:
        # Check if one node is at first floor and other is above
        if ((z1 == first_floor_z and z2 > first_floor_z) or 
            (z2 == first_floor_z and z1 > first_floor_z)):
            first_floor_columns.append(element['Element ID'])

# Calculate total steel weight
total_weight = 0
steel_density = 7850  # kg/m^3

for element_id in first_floor_columns:
    element = element_df[element_df['Element ID'] == element_id].iloc[0]
    
    # Get nodes
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Calculate length
    length = abs(node2['Z (m)'] - node1['Z (m)'])
    
    # Get section area
    section_num = element['Section']
    section = section_df[section_df['Section Number'] == section_num].iloc[0]
    area = section['Area']  # m^2
    
    # Calculate volume and weight
    volume = area * length  # m^3
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
output_df = pd.DataFrame({
    'Total Weight of First Floor Columns (kg)': [total_weight_rounded]
})

output_df.to_csv('Task_20_out.csv', index=False)