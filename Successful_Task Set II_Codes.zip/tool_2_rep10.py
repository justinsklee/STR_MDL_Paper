import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get the maximum z-coordinate to identify the roof level
max_z = node_df['Z (m)'].max()

# Identify columns (vertical elements with only z-coordinate change)
columns = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Identify beams at roof level (no change in z-coordinates and at max z)
roof_beams = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a beam at roof level
    if (node1['Z (m)'] == node2['Z (m)'] and 
        node1['Z (m)'] == max_z):
        roof_beams.append(row['Element ID'])

# Get nodes connected to columns
column_nodes = set()
for _, row in element_df.iterrows():
    if row['Element ID'] in columns:
        column_nodes.add(row['Node 1'])
        column_nodes.add(row['Node 2'])

# Find roof sub-beams (beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_row['Node 1']
    node2_id = beam_row['Node 2']
    
    # Check if beam is not connected to any column nodes
    if node1_id not in column_nodes and node2_id not in column_nodes:
        roof_sub_beams.append(beam_id)

# Sort element IDs in ascending order
roof_sub_beams.sort()

# Create output DataFrame
output_df = pd.DataFrame({'Element ID': roof_sub_beams})

# Save to CSV
output_df.to_csv('Task_2_out.csv', index=False)