import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_40_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Identify second floor elevation
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor (index 1)

# Identify Y-1 grid coordinate
y_coords = sorted(node_df['Y (m)'].unique())
y1_coord = y_coords[0]  # Y-1 grid (first Y coordinate)

# Identify braces on second floor along grid Y-1
braces_to_remove = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a brace (diagonal element)
    x_change = node1_coords['X (m)'] != node2_coords['X (m)']
    y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
    z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if both nodes are on Y-1 grid
        both_on_y1 = (node1_coords['Y (m)'] == y1_coord and 
                      node2_coords['Y (m)'] == y1_coord)
        
        # Check if one node is on second floor and the other is above
        node1_on_second = node1_coords['Z (m)'] == second_floor_z
        node2_above_second = node2_coords['Z (m)'] > second_floor_z
        node2_on_second = node2_coords['Z (m)'] == second_floor_z
        node1_above_second = node1_coords['Z (m)'] > second_floor_z
        
        second_floor_brace = ((node1_on_second and node2_above_second) or 
                             (node2_on_second and node1_above_second))
        
        if both_on_y1 and second_floor_brace:
            braces_to_remove.append(row['Element ID'])

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID in ascending order
element_df_updated = element_df_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df_updated.to_csv('Task_40_out/Element.csv', index=False)

print(f"Removed {len(braces_to_remove)} second floor braces along grid Y-1")
print(f"Removed element IDs: {braces_to_remove}")