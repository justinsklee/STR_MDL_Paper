import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')

# Get office load areas
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Find all nodes involved in office loads
office_nodes = set()
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.update(nodes)

# Find columns supporting office loads
# Columns are vertical elements (only z-coordinate changes)
# They support loads from BELOW the floor, so we need columns that have one node 
# at the office load nodes and extend downward

supporting_columns = []

for node_id in office_nodes:
    # Get the z-coordinate of the office load node
    office_node_z = node_df[node_df['Node ID'] == node_id]['Z (m)'].iloc[0]
    
    # Find columns that have one end at this node
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Check if this element connects to our office load node
        if node1_id == node_id or node2_id == node_id:
            # Get coordinates of both nodes
            node1_coords = node_df[node_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
            node2_coords = node_df[node_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
            
            # Check if it's a column (vertical element - only z changes)
            if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                node1_coords['Z (m)'] != node2_coords['Z (m)']):
                
                # Check if the column extends below the office load level
                min_z = min(node1_coords['Z (m)'], node2_coords['Z (m)'])
                max_z = max(node1_coords['Z (m)'], node2_coords['Z (m)'])
                
                # Column supports the load if it has one node at the load level and extends below
                if max_z == office_node_z and min_z < office_node_z:
                    supporting_columns.append(element['Element ID'])

# Remove duplicates and sort
supporting_columns = sorted(list(set(supporting_columns)))

# Create output DataFrame
output_df = pd.DataFrame({'Element ID': supporting_columns})

# Save to CSV
output_df.to_csv('Task_6_out.csv', index=False)

print(f"Found {len(supporting_columns)} columns supporting office live loads")
print(output_df)