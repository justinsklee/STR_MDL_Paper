import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_36_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get supported nodes
supported_nodes = support_df['Node'].tolist()

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check for changes in coordinates
    dx = abs(x2 - x1) > 1e-6
    dy = abs(y2 - y1) > 1e-6
    dz = abs(z2 - z1) > 1e-6
    
    if dz and not dx and not dy:
        return 'column'
    elif not dz:
        return 'beam'
    elif (dx or dy) and dz:
        return 'brace'
    else:
        return 'unknown'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find columns that share supports with bracing elements
columns_with_braces = set()

for _, col_row in element_df[element_df['element_type'] == 'column'].iterrows():
    col_node1 = col_row['Node 1']
    col_node2 = col_row['Node 2']
    col_nodes = {col_node1, col_node2}
    
    # Check if this column shares nodes with any brace
    for _, brace_row in element_df[element_df['element_type'] == 'brace'].iterrows():
        brace_node1 = brace_row['Node 1']
        brace_node2 = brace_row['Node 2']
        brace_nodes = {brace_node1, brace_node2}
        
        # Check if column and brace share any nodes, and if any of those nodes are supported
        shared_nodes = col_nodes.intersection(brace_nodes)
        if shared_nodes and any(node in supported_nodes for node in shared_nodes):
            columns_with_braces.add(col_row['Element ID'])
            break

# Update sections for identified columns
for idx, row in element_df.iterrows():
    if row['Element ID'] in columns_with_braces:
        element_df.at[idx, 'Section'] = 101

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_36_out/Element.csv', index=False)