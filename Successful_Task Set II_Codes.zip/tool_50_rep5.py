import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')

# Filter floor loads for office loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Function to calculate element length
def calculate_length(node1_id, node2_id, node_df):
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = node2['X (m)'] - node1['X (m)']
    dy = node2['Y (m)'] - node1['Y (m)']
    dz = node2['Z (m)'] - node1['Z (m)']
    
    return np.sqrt(dx**2 + dy**2 + dz**2)

# Function to classify elements
def classify_element(node1_id, node2_id, node_df):
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    if dz > 0 and dx == 0 and dy == 0:
        return 'column'
    elif dz == 0:
        return 'beam'
    else:
        return 'brace'

# Get supporting beams for office loads
supporting_beams = []

for _, office_load in office_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = office_load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create beam pairs from the 4 nodes (forming a rectangle)
    beam_pairs = [
        (nodes[0], nodes[1]),
        (nodes[1], nodes[2]),
        (nodes[2], nodes[3]),
        (nodes[3], nodes[0])
    ]
    
    # Find elements that match these beam pairs
    for node1, node2 in beam_pairs:
        # Find element with these nodes
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            # Check if it's a beam (horizontal element)
            element_type = classify_element(element['Node 1'], element['Node 2'], node_df)
            if element_type == 'beam':
                length = calculate_length(element['Node 1'], element['Node 2'], node_df)
                supporting_beams.append({
                    'Element ID': element['Element ID'],
                    'Section': element['Section'],
                    'Length (m)': round(length, 3)
                })

# Create DataFrame and remove duplicates
result_df = pd.DataFrame(supporting_beams)
result_df = result_df.drop_duplicates().sort_values('Element ID').reset_index(drop=True)

# Save to CSV
result_df.to_csv('Task_50_out.csv', index=False)

print("Results saved to Task_50_out.csv")
print(result_df)