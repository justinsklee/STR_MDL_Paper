import pandas as pd
import numpy as np

# Load all relevant CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
sections_df = pd.read_csv('Long_Section.csv')

# Find the highest floor elevation (roof level)
max_z = nodes_df['Z (m)'].max()

# Find X-1 grid coordinate (minimum X coordinate)
x1_coord = nodes_df['X (m)'].min()

# Filter nodes at roof level and on X-1 grid
roof_x1_nodes = nodes_df[(nodes_df['Z (m)'] == max_z) & (nodes_df['X (m)'] == x1_coord)]

# Get roof level beams (elements where both nodes have same Z coordinate at roof level)
roof_beams = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_data = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2_data = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are at roof level (beams have same Z coordinate)
    if node1_data['Z (m)'] == max_z and node2_data['Z (m)'] == max_z:
        # Check if both nodes are on X-1 grid
        if node1_data['X (m)'] == x1_coord and node2_data['X (m)'] == x1_coord:
            # Calculate beam length
            length = np.sqrt((node2_data['X (m)'] - node1_data['X (m)'])**2 + 
                           (node2_data['Y (m)'] - node1_data['Y (m)'])**2 + 
                           (node2_data['Z (m)'] - node1_data['Z (m)'])**2)
            
            if length > 1.3:
                roof_beams.append({
                    'Element ID': element['Element ID'],
                    'Section': element['Section'],
                    'Length': length
                })

# Get section names
result_data = []
for beam in roof_beams:
    section_info = sections_df[sections_df['Section Number'] == beam['Section']]
    if not section_info.empty:
        section_name = section_info.iloc[0]['Section Name']
    else:
        section_name = 'Unknown'
    
    result_data.append({
        'Element ID': beam['Element ID'],
        'Section Name': section_name
    })

# Create output dataframe and save to CSV
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')
result_df.to_csv('Task_49_out.csv', index=False)

print("Results saved to Task_49_out.csv")
print(result_df)