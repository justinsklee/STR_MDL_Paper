import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_32_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
    
    # Find braces on third floor
    # Braces have one node at third floor and another node above third floor
    third_floor_braces = []
    
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a brace (change in x/y AND z coordinates)
        x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 1e-6
        y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 1e-6
        z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
        
        is_brace = (x_change or y_change) and z_change
        
        if is_brace:
            # Check if one node is at third floor and other is above
            node1_at_third = abs(node1_coords['Z (m)'] - third_floor_elevation) < 1e-6
            node2_at_third = abs(node2_coords['Z (m)'] - third_floor_elevation) < 1e-6
            node1_above_third = node1_coords['Z (m)'] > third_floor_elevation
            node2_above_third = node2_coords['Z (m)'] > third_floor_elevation
            
            if (node1_at_third and node2_above_third) or (node2_at_third and node1_above_third):
                third_floor_braces.append(idx)
    
    # Update section for third floor braces to 102
    for idx in third_floor_braces:
        element_df.loc[idx, 'Section'] = 102

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_32_out/Element.csv', index=False)