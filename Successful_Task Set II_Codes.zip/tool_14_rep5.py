import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the maximum z-coordinate (roof level)
max_z = node_df['Z (m)'].max()

# Get nodes at roof level
roof_nodes = node_df[node_df['Z (m)'] == max_z]['Node ID'].tolist()

# Find beams (elements with no change in z-coordinate between nodes)
roof_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in z-coordinate) and at roof level
    if node1_z == node2_z and node1_z == max_z:
        material_id = element['Material']
        material_name = material_df[material_df['Material Number'] == material_id]['Name'].iloc[0]
        roof_beams.append({
            'Element ID': element['Element ID'],
            'Material Name': material_name
        })

# Create output dataframe and sort by Element ID
output_df = pd.DataFrame(roof_beams)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_14_out.csv', index=False)

print(f"Found {len(roof_beams)} roof beams")
print(output_df)