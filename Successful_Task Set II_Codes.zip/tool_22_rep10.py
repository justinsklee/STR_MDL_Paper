import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get all unique Z coordinates and sort them
z_coords = sorted(node_df['Z (m)'].unique())
roof_z = max(z_coords)  # Highest Z coordinate is the roof

# Get all nodes at roof level
roof_nodes = node_df[node_df['Z (m)'] == roof_z]['Node ID'].tolist()

# Identify columns (vertical elements)
columns = []
for _, element in element_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    node1_coords = node_df[node_df['Node ID'] == node1][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    
    # Column: change in Z only, no change in X and Y
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        columns.append(element['Element ID'])

# Get nodes that are connected to columns
column_connected_nodes = set()
for _, element in element_df.iterrows():
    if element['Element ID'] in columns:
        column_connected_nodes.add(element['Node 1'])
        column_connected_nodes.add(element['Node 2'])

# Identify beams on roof level
roof_beams = []
for _, element in element_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    node1_coords = node_df[node_df['Node ID'] == node1][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    
    # Beam: no change in Z coordinates
    if node1_coords['Z (m)'] == node2_coords['Z (m)']:
        # Check if both nodes are on roof level
        if node1_coords['Z (m)'] == roof_z:
            roof_beams.append(element['Element ID'])

# Identify sub-beams on roof (beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Sub-beam: neither node is connected to a column
    if node1 not in column_connected_nodes and node2 not in column_connected_nodes:
        roof_sub_beams.append(beam_id)

# Update section for roof sub-beams to 104
for beam_id in roof_sub_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 104

# Save updated Element.csv
element_df.to_csv('Task_22_out/Element.csv', index=False)