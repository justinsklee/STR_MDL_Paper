import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find X-1 grid coordinate (minimum X coordinate)
x1_coord = node_df['X (m)'].min()

# Merge element data with node coordinates for both Node 1 and Node 2
element_with_nodes = element_df.merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 1', 
    right_on='Node ID', 
    suffixes=('', '_node1')
).merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 2', 
    right_on='Node ID', 
    suffixes=('', '_node2')
)

# Classify elements as braces (diagonal elements: change in x/y AND z coordinates)
element_with_nodes['is_brace'] = (
    (element_with_nodes['X (m)'] != element_with_nodes['X (m)_node2']) | 
    (element_with_nodes['Y (m)'] != element_with_nodes['Y (m)_node2'])
) & (element_with_nodes['Z (m)'] != element_with_nodes['Z (m)_node2'])

# Find braces along grid X-1 (both nodes have X-coordinate equal to X-1 grid)
braces_on_x1 = element_with_nodes[
    element_with_nodes['is_brace'] & 
    (element_with_nodes['X (m)'] == x1_coord) & 
    (element_with_nodes['X (m)_node2'] == x1_coord)
]

# Extract element numbers and sort in ascending order
result = braces_on_x1[['Element ID']].sort_values('Element ID')

# Save to CSV
result.to_csv('Task_3_out.csv', index=False)