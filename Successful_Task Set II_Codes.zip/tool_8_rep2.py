import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Merge element data with node coordinates
element_with_coords = element_df.merge(
    node_df.rename(columns={'Node ID': 'Node 1', 'X (m)': 'X1', 'Y (m)': 'Y1', 'Z (m)': 'Z1'}),
    on='Node 1'
).merge(
    node_df.rename(columns={'Node ID': 'Node 2', 'X (m)': 'X2', 'Y (m)': 'Y2', 'Z (m)': 'Z2'}),
    on='Node 2'
)

# Classify elements
def classify_element(row):
    # Check coordinate changes
    x_change = abs(row['X2'] - row['X1']) > 1e-6
    y_change = abs(row['Y2'] - row['Y1']) > 1e-6
    z_change = abs(row['Z2'] - row['Z1']) > 1e-6
    
    # Columns: only z changes
    if z_change and not x_change and not y_change:
        return 'Column'
    # Beams: no z change
    elif not z_change:
        return 'Beam'
    # Braces: z changes AND (x or y changes)
    elif z_change and (x_change or y_change):
        return 'Brace'
    else:
        return 'Unknown'

element_with_coords['Element_Type'] = element_with_coords.apply(classify_element, axis=1)

# Get supported nodes
supported_nodes = set(support_df['Node'].tolist())

# Find columns that share supports with bracing elements
columns = element_with_coords[element_with_coords['Element_Type'] == 'Column']
braces = element_with_coords[element_with_coords['Element_Type'] == 'Brace']

# Get nodes that have both columns and braces connected and are supported
column_nodes = set()
for _, col in columns.iterrows():
    column_nodes.update([col['Node 1'], col['Node 2']])

brace_nodes = set()
for _, brace in braces.iterrows():
    brace_nodes.update([brace['Node 1'], brace['Node 2']])

# Find nodes that are supported and have both columns and braces
shared_supported_nodes = supported_nodes.intersection(column_nodes).intersection(brace_nodes)

# Get column element IDs that connect to these shared supported nodes
result_columns = []
for _, col in columns.iterrows():
    if col['Node 1'] in shared_supported_nodes or col['Node 2'] in shared_supported_nodes:
        result_columns.append(col['Element ID'])

# Create output dataframe and sort by Element ID
result_df = pd.DataFrame({'Element ID': sorted(result_columns)})

# Save to CSV
result_df.to_csv('Task_8_out.csv', index=False)

print(f"Found {len(result_columns)} columns that share supports with bracing elements")
print(result_df)