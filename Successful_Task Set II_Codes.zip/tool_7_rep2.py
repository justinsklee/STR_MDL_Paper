import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find section number for H 100x100x6/8
target_section = section_df[section_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Classify elements as columns, beams, or braces
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check for changes in coordinates
    x_change = abs(x2 - x1) > 1e-6
    y_change = abs(y2 - y1) > 1e-6
    z_change = abs(z2 - z1) > 1e-6
    
    if z_change and not x_change and not y_change:
        return 'Column'
    elif not z_change:
        return 'Beam'
    elif z_change and (x_change or y_change):
        return 'Brace'
    else:
        return 'Unknown'

# Add element classification
element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Find braces with section H 100x100x6/8
braces_with_target_section = element_df[
    (element_df['Element_Type'] == 'Brace') & 
    (element_df['Section'] == target_section)
]

# Get all nodes that are connected to these braces
brace_nodes = set()
for _, brace in braces_with_target_section.iterrows():
    brace_nodes.add(brace['Node 1'])
    brace_nodes.add(brace['Node 2'])

# Find beams that are connected to any of these nodes
beams = element_df[element_df['Element_Type'] == 'Beam']
connected_beams = []

for _, beam in beams.iterrows():
    beam_node1 = beam['Node 1']
    beam_node2 = beam['Node 2']
    
    # Check if beam is connected to any brace node
    if beam_node1 in brace_nodes or beam_node2 in brace_nodes:
        connected_beams.append(beam['Element ID'])

# Create output dataframe
result_df = pd.DataFrame({'Element ID': sorted(connected_beams)})

# Save to CSV
result_df.to_csv('Task_7_out.csv', index=False)