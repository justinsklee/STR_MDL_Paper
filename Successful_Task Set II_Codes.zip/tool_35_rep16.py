import pandas as pd
import os

# Create output folder
os.makedirs('Task_35_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find residential loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that define residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    residential_nodes.update(nodes)

# Find columns that support residential loads (columns below these nodes)
supporting_columns = []

for node_id in residential_nodes:
    # Get the z-coordinate of this node
    node_z = node_df[node_df['Node ID'] == node_id]['Z (m)'].iloc[0]
    
    # Find columns that have this node as their upper node (Node 2)
    # and have their lower node (Node 1) below this elevation
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Skip if not connected to our target node
        if node2_id != node_id:
            continue
            
        # Get coordinates of both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Check if it's a column (vertical element: same x,y but different z)
        if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
            node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
            node1_coords['Z (m)'] != node2_coords['Z (m)']):
            
            # Check if Node 1 is below Node 2 (column supporting from below)
            if node1_coords['Z (m)'] < node2_coords['Z (m)']:
                supporting_columns.append(element['Element ID'])

# Update material for supporting columns to SHN355 (material 1003)
for col_id in supporting_columns:
    element_df.loc[element_df['Element ID'] == col_id, 'Material'] = 1003

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_35_out/Element.csv', index=False)

print(f"Updated {len(supporting_columns)} columns supporting residential loads to SHN355 material")
print(f"Column IDs updated: {supporting_columns}")