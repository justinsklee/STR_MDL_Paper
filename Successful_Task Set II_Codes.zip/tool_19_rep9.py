import pandas as pd
import numpy as np

# Load the CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Function to calculate element length
def calculate_element_length(row, node_df):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    length = np.sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)
    return length

# Function to classify elements
def classify_element(row, node_df):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if it's a column (vertical - only z changes)
    if abs(x1 - x2) < 1e-6 and abs(y1 - y2) < 1e-6 and abs(z1 - z2) > 1e-6:
        return 'Column'
    # Check if it's a beam (horizontal - no z change)
    elif abs(z1 - z2) < 1e-6:
        return 'Beam'
    # Otherwise it's a brace (diagonal)
    else:
        return 'Brace'

# Calculate lengths and classify elements
element_df['Length'] = element_df.apply(lambda row: calculate_element_length(row, node_df), axis=1)
element_df['Type'] = element_df.apply(lambda row: classify_element(row, node_df), axis=1)

# Filter for beams shorter than 1.3m
short_beams = element_df[(element_df['Type'] == 'Beam') & (element_df['Length'] < 1.3)]

# Create output dataframe with element numbers and lengths
output_df = short_beams[['Element ID', 'Length']].copy()
output_df = output_df.sort_values('Element ID')
output_df.columns = ['Element Number', 'Length']

# Save to CSV
output_df.to_csv('Task_19_out.csv', index=False)

print(f"Found {len(output_df)} beams shorter than 1.3m")
print(output_df)