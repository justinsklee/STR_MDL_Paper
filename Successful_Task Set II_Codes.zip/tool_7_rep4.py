import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get section number for H 100x100x6/8
target_section = section_df[section_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Classify elements
def classify_element(row):
    node1 = node_df[node_df['Node ID'] == row['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == row['Node 2']].iloc[0]
    
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    if dz > 0 and dx == 0 and dy == 0:
        return 'Column'
    elif dz == 0:
        return 'Beam'
    elif dz > 0 and (dx > 0 or dy > 0):
        return 'Brace'
    
element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Find braces with target section
braces_with_target_section = element_df[
    (element_df['Element_Type'] == 'Brace') & 
    (element_df['Section'] == target_section)
]

# Get nodes connected to these braces
brace_nodes = set()
for _, brace in braces_with_target_section.iterrows():
    brace_nodes.add(brace['Node 1'])
    brace_nodes.add(brace['Node 2'])

# Find beams connected to these nodes
beams_connected_to_braces = element_df[
    (element_df['Element_Type'] == 'Beam') & 
    ((element_df['Node 1'].isin(brace_nodes)) | (element_df['Node 2'].isin(brace_nodes)))
]

# Create output dataframe
result = beams_connected_to_braces[['Element ID']].sort_values('Element ID')

# Save to CSV
result.to_csv('Task_7_out.csv', index=False)