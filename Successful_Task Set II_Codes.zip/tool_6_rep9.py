import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')

# Get office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Find all nodes involved in office live loads
office_nodes = []
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    office_nodes.extend(nodes)

office_nodes = list(set(office_nodes))  # Remove duplicates

# Get coordinates of office load nodes
office_node_coords = node_df[node_df['Node ID'].isin(office_nodes)][['Node ID', 'X (m)', 'Y (m)', 'Z (m)']]

# Find columns supporting office loads (columns that have one node at office load level and another below)
supporting_columns = []

for _, office_node in office_node_coords.iterrows():
    office_node_id = office_node['Node ID']
    office_x = office_node['X (m)']
    office_y = office_node['Y (m)']
    office_z = office_node['Z (m)']
    
    # Find elements connected to this office load node
    connected_elements = element_df[(element_df['Node 1'] == office_node_id) | 
                                  (element_df['Node 2'] == office_node_id)]
    
    for _, element in connected_elements.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates of both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a column (vertical element - only z changes)
        if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
            node1_coords['Y (m)'] == node2_coords['Y (m)'] and
            node1_coords['Z (m)'] != node2_coords['Z (m)']):
            
            # Check if one node is at office load level and the other is below
            if ((node1_id == office_node_id and node2_coords['Z (m)'] < office_z) or
                (node2_id == office_node_id and node1_coords['Z (m)'] < office_z)):
                supporting_columns.append(element['Element ID'])

# Remove duplicates and sort
supporting_columns = sorted(list(set(supporting_columns)))

# Create output DataFrame
output_df = pd.DataFrame({'Element ID': supporting_columns})

# Save to CSV
output_df.to_csv('Task_6_out.csv', index=False)