import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_47_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find Y-1 grid coordinate (first Y grid line)
y_coords = sorted(node_df['Y (m)'].unique())
y1_coord = y_coords[0]

# Find all columns on first floor with section 101
# Columns are vertical elements (only z changes, x and y stay same)
columns = []
for _, elem in element_df.iterrows():
    if elem['Section'] == 101:  # Section 101
        node1_id = elem['Node 1']
        node2_id = elem['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if it's a column (vertical element)
        if (node1['X (m)'] == node2['X (m)'] and 
            node1['Y (m)'] == node2['Y (m)'] and 
            node1['Z (m)'] != node2['Z (m)']):
            
            # Check if column is on Y-1 grid
            if node1['Y (m)'] == y1_coord or node2['Y (m)'] == y1_coord:
                
                # Check if column is connected to first floor
                if node1['Z (m)'] == first_floor_z or node2['Z (m)'] == first_floor_z:
                    # Find the node at first floor level
                    if node1['Z (m)'] == first_floor_z:
                        floor_node = node1_id
                    else:
                        floor_node = node2_id
                    
                    columns.append(floor_node)

# Update support conditions for identified nodes
# Pin support: Dx=1, Dy=1, Dz=1, Rx=0, Ry=0, Rz=0
for node_id in columns:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated Support.csv
support_df.to_csv('Task_47_out/Support.csv', index=False)

print(f"Updated support conditions for {len(columns)} first floor columns along grid Y-1 with section 101")
print(f"Nodes modified: {columns}")