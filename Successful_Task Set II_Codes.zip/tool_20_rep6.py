import pandas as pd
import numpy as np
import math

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Identify first floor elevation
first_floor_z = 0.0

# Find all columns (vertical elements with change only in z-coordinate)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only z changes)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element)

# Find first floor columns (one node at first floor, other node above)
first_floor_columns = []
for column in columns:
    node1_id = column['Node 1']
    node2_id = column['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    node1_z = node1['Z (m)']
    node2_z = node2['Z (m)']
    
    # Check if one node is at first floor and other is above
    if ((node1_z == first_floor_z and node2_z > first_floor_z) or
        (node2_z == first_floor_z and node1_z > first_floor_z)):
        first_floor_columns.append(column)

# Calculate total weight
total_weight = 0
steel_density = 7850  # kg/m³

for column in first_floor_columns:
    # Get section properties
    section_num = column['Section']
    section_info = section_df[section_df['Section Number'] == section_num].iloc[0]
    area = section_info['Area']  # m²
    
    # Calculate column length
    node1_id = column['Node 1']
    node2_id = column['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    length = abs(node2['Z (m)'] - node1['Z (m)'])  # m
    
    # Calculate weight for this column
    volume = area * length  # m³
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
output_df = pd.DataFrame({
    'Total Weight of First Floor Columns (kg)': [total_weight_rounded]
})

output_df.to_csv('Task_20_out.csv', index=False)