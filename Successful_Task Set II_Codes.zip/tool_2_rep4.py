import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get the maximum z-coordinate (roof level)
max_z = node_df['Z (m)'].max()

# Filter nodes at roof level
roof_nodes = node_df[node_df['Z (m)'] == max_z]['Node ID'].tolist()

# Classify elements as columns, beams, or braces
def classify_element(row):
    node1_id, node2_id = row['Node 1'], row['Node 2']
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x_change = node1['X (m)'] != node2['X (m)']
    y_change = node1['Y (m)'] != node2['Y (m)']
    z_change = node1['Z (m)'] != node2['Z (m)']
    
    if z_change and not (x_change or y_change):
        return 'column'
    elif not z_change:
        return 'beam'
    else:
        return 'brace'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Get roof beams (beams with both nodes at roof level)
roof_beams = element_df[
    (element_df['element_type'] == 'beam') & 
    (element_df['Node 1'].isin(roof_nodes)) & 
    (element_df['Node 2'].isin(roof_nodes))
]

# Get columns that connect to roof nodes
roof_columns = element_df[
    (element_df['element_type'] == 'column') & 
    ((element_df['Node 1'].isin(roof_nodes)) | (element_df['Node 2'].isin(roof_nodes)))
]

# Get nodes that are connected to columns at roof level
column_connected_nodes = set()
for _, col in roof_columns.iterrows():
    if col['Node 1'] in roof_nodes:
        column_connected_nodes.add(col['Node 1'])
    if col['Node 2'] in roof_nodes:
        column_connected_nodes.add(col['Node 2'])

# Find roof sub-beams (roof beams not directly connected to columns)
roof_sub_beams = roof_beams[
    ~(roof_beams['Node 1'].isin(column_connected_nodes)) & 
    ~(roof_beams['Node 2'].isin(column_connected_nodes))
]

# Create output dataframe with only Element ID
output_df = pd.DataFrame({
    'Element ID': sorted(roof_sub_beams['Element ID'].tolist())
})

# Save to CSV
output_df.to_csv('Task_2_out.csv', index=False)