import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Filter for residential live loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Extract supporting beam element numbers
supporting_beams = []

for _, load in residential_loads.iterrows():
    # Parse nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # For each load region defined by 4 nodes, find beams connecting them
    # Connections: (node1,node2), (node2,node3), (node3,node4), (node4,node1)
    beam_connections = [
        (nodes[0], nodes[1]),
        (nodes[1], nodes[2]),
        (nodes[2], nodes[3]),
        (nodes[3], nodes[0])
    ]
    
    # Find element IDs for these beam connections
    for conn in beam_connections:
        node1, node2 = conn
        # Find elements connecting these nodes (considering both directions)
        beam_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        # Filter for beams (horizontal elements - no change in Z coordinate)
        for _, element in beam_elements.iterrows():
            n1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
            n2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
            
            # Check if it's a beam (no change in Z coordinate)
            if n1_z == n2_z:
                supporting_beams.append(element['Element ID'])

# Remove duplicates and sort
supporting_beams = sorted(list(set(supporting_beams)))

# Create output DataFrame
output_df = pd.DataFrame({'Element ID': supporting_beams})

# Save to CSV
output_df.to_csv('Task_5_out.csv', index=False)