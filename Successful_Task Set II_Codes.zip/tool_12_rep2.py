import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all beam element IDs supporting residential loads
supporting_beam_ids = set()

for _, load in residential_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # Find beams that connect these nodes in sequence (forming the perimeter)
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]  # Connect last node back to first
        
        # Find beam connecting these two nodes
        beam = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        if not beam.empty:
            supporting_beam_ids.add(beam.iloc[0]['Element ID'])

# Get beam details with section names
supporting_beams = element_df[element_df['Element ID'].isin(supporting_beam_ids)].copy()

# Merge with section information to get section names
result = supporting_beams.merge(
    long_section_df[['Section Number', 'Section Name']], 
    left_on='Section', 
    right_on='Section Number',
    how='left'
)

# Select only required columns and sort by Element ID
output = result[['Element ID', 'Section Name']].sort_values('Element ID').reset_index(drop=True)

# Save to CSV
output.to_csv('Task_12_out.csv', index=False)

print(f"Found {len(output)} beams supporting residential live load")
print(output)