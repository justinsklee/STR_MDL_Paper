import pandas as pd
import numpy as np
import math

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Create node coordinate lookup
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Find first floor elevation (minimum z-coordinate)
first_floor_z = node_df['Z (m)'].min()

# Identify columns (vertical elements with change only in z-coordinate)
columns = []
for _, element in element_df.iterrows():
    node1_coords = node_coords[element['Node 1']]
    node2_coords = node_coords[element['Node 2']]
    
    # Check if element is vertical (column)
    if (node1_coords[0] == node2_coords[0] and  # same x
        node1_coords[1] == node2_coords[1] and  # same y
        node1_coords[2] != node2_coords[2]):    # different z
        columns.append(element)

# Filter first floor columns (one node at first floor, other node above)
first_floor_columns = []
for element in columns:
    node1_coords = node_coords[element['Node 1']]
    node2_coords = node_coords[element['Node 2']]
    
    # Check if one node is at first floor and other is above
    if ((node1_coords[2] == first_floor_z and node2_coords[2] > first_floor_z) or
        (node2_coords[2] == first_floor_z and node1_coords[2] > first_floor_z)):
        first_floor_columns.append(element)

# Calculate total weight
total_weight = 0
steel_density = 7850  # kg/m^3

for element in first_floor_columns:
    # Get section area
    section_num = element['Section']
    section_area = section_df[section_df['Section Number'] == section_num]['Area'].iloc[0]  # m^2
    
    # Calculate length
    node1_coords = node_coords[element['Node 1']]
    node2_coords = node_coords[element['Node 2']]
    length = abs(node2_coords[2] - node1_coords[2])  # m
    
    # Calculate weight
    volume = section_area * length  # m^3
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
output_df = pd.DataFrame({
    'Total Weight of First Floor Columns (kg)': [total_weight_rounded]
})

output_df.to_csv('Task_20_out.csv', index=False)