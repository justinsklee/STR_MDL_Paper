import pandas as pd

# Load the CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_elevation = floor_elevations[0]  # Ground level (z = 0.0m)

# Find columns that have one node at first floor and the other node above first floor
first_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates of both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical: only z coordinates change)
    x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) < 1e-6
    y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) < 1e-6
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
    
    is_column = x_change and y_change and z_change
    
    if is_column:
        # Check if one node is at first floor and the other is above
        node1_at_first_floor = abs(node1_coords['Z (m)'] - first_floor_elevation) < 1e-6
        node2_at_first_floor = abs(node2_coords['Z (m)'] - first_floor_elevation) < 1e-6
        
        node1_above_first_floor = node1_coords['Z (m)'] > first_floor_elevation
        node2_above_first_floor = node2_coords['Z (m)'] > first_floor_elevation
        
        if (node1_at_first_floor and node2_above_first_floor) or (node2_at_first_floor and node1_above_first_floor):
            first_floor_columns.append(element['Element ID'])

# Sort the element IDs in ascending order
first_floor_columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': first_floor_columns})

# Save to CSV
output_df.to_csv('Task_1_out.csv', index=False)