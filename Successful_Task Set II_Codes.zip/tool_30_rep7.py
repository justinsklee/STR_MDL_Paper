import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_30_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Fourth floor is at index 3 (0-indexed: ground=0, 2nd=1, 3rd=2, 4th=3)
if len(floor_elevations) >= 4:
    fourth_floor_z = floor_elevations[3]
else:
    print("Model does not have a fourth floor")
    fourth_floor_z = None

if fourth_floor_z is not None:
    # Get nodes on the fourth floor
    fourth_floor_nodes = nodes_df[nodes_df['Z (m)'] == fourth_floor_z]['Node ID'].tolist()
    
    # Identify braces on fourth floor
    # Braces have one node on the floor and another node above the floor
    braces_to_remove = []
    
    for idx, row in elements_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2_coords = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a brace (diagonal element)
        # Brace: change in (x or y) coordinates AND z coordinates
        x_change = node1_coords['X (m)'] != node2_coords['X (m)']
        y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        
        is_brace = (x_change or y_change) and z_change
        
        if is_brace:
            # Check if one node is on fourth floor and the other is above
            node1_on_fourth = node1_id in fourth_floor_nodes
            node2_above_fourth = node2_coords['Z (m)'] > fourth_floor_z
            
            node2_on_fourth = node2_id in fourth_floor_nodes
            node1_above_fourth = node1_coords['Z (m)'] > fourth_floor_z
            
            if (node1_on_fourth and node2_above_fourth) or (node2_on_fourth and node1_above_fourth):
                braces_to_remove.append(row['Element ID'])
    
    # Remove braces from elements dataframe
    elements_df = elements_df[~elements_df['Element ID'].isin(braces_to_remove)]
    
    print(f"Removed {len(braces_to_remove)} braces from fourth floor")

# Save updated Element.csv
elements_df.to_csv('Task_30_out/Element.csv', index=False)