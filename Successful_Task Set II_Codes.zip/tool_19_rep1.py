import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create a dictionary for quick node lookup
node_dict = {}
for _, row in node_df.iterrows():
    node_dict[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Function to classify elements and calculate lengths
def classify_and_calculate_length(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    x1, y1, z1 = node_dict[node1_id]
    x2, y2, z2 = node_dict[node2_id]
    
    # Calculate length
    length = np.sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)
    
    # Classify element
    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    dz = abs(z2 - z1)
    
    if dz > 0.001 and (dx > 0.001 or dy > 0.001):
        element_type = 'Brace'
    elif dz > 0.001 and dx < 0.001 and dy < 0.001:
        element_type = 'Column'
    elif dz < 0.001:
        element_type = 'Beam'
    else:
        element_type = 'Unknown'
    
    return element_type, length

# Apply classification and length calculation
element_df[['Element_Type', 'Length']] = element_df.apply(
    lambda row: pd.Series(classify_and_calculate_length(row)), axis=1
)

# Filter for beams shorter than 1.3m
short_beams = element_df[
    (element_df['Element_Type'] == 'Beam') & 
    (element_df['Length'] < 1.3)
][['Element ID', 'Length']].copy()

# Sort by element ID
short_beams = short_beams.sort_values('Element ID')

# Rename columns for output
short_beams.columns = ['Element Number', 'Length']

# Save to CSV
short_beams.to_csv('Task_19_out.csv', index=False)

print(short_beams)