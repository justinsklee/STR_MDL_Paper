import pandas as pd

# Load CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')

# Get the highest z-coordinate (roof level)
roof_z = nodes_df['Z (m)'].max()

# Get all beams (horizontal elements with no change in z-coordinate)
beams = []
for _, element in elements_df.iterrows():
    node1_z = nodes_df[nodes_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    node2_z = nodes_df[nodes_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in z-coordinate)
    if node1_z == node2_z:
        beams.append({
            'Element ID': element['Element ID'],
            'Node 1': element['Node 1'],
            'Node 2': element['Node 2'],
            'Z': node1_z
        })

beams_df = pd.DataFrame(beams)

# Filter for roof beams (beams at the highest elevation)
roof_beams = beams_df[beams_df['Z'] == roof_z]

# Get all columns (vertical elements)
columns = []
for _, element in elements_df.iterrows():
    node1 = nodes_df[nodes_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if it's a column (change in z only, no change in x and y)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Get all nodes that are connected to columns
column_connected_nodes = set()
for _, element in elements_df.iterrows():
    if element['Element ID'] in columns:
        column_connected_nodes.add(element['Node 1'])
        column_connected_nodes.add(element['Node 2'])

# Find roof sub-beams (roof beams not directly connected to columns)
roof_sub_beams = []
for _, beam in roof_beams.iterrows():
    # Check if both nodes of the beam are NOT connected to columns
    if (beam['Node 1'] not in column_connected_nodes and 
        beam['Node 2'] not in column_connected_nodes):
        roof_sub_beams.append(beam['Element ID'])

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(roof_sub_beams)})

# Save to CSV
output_df.to_csv('Task_2_out.csv', index=False)