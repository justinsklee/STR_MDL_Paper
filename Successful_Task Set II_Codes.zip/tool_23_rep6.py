import pandas as pd
import os

# Create output folder
os.makedirs('Task_23_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find the section number for H 100x100x6/8
target_section = section_df[section_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_z = floor_elevations[0]  # Ground level (z = 0.0m)
second_floor_z = floor_elevations[1] if len(floor_elevations) > 1 else first_floor_z + 1

# Identify braces on first floor
first_floor_braces = []

for idx, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a brace (change in x/y AND z coordinates)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if one node is at first floor and the other is above
        node1_at_first = abs(node1['Z (m)'] - first_floor_z) < 1e-6
        node2_at_first = abs(node2['Z (m)'] - first_floor_z) < 1e-6
        node1_above_first = node1['Z (m)'] > first_floor_z
        node2_above_first = node2['Z (m)'] > first_floor_z
        
        if (node1_at_first and node2_above_first) or (node2_at_first and node1_above_first):
            first_floor_braces.append(element['Element ID'])

# Update section for first floor braces
for element_id in first_floor_braces:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = target_section

# Save updated Element.csv
element_df.to_csv('Task_23_out/Element.csv', index=False)

print(f"Updated {len(first_floor_braces)} first floor braces with section H 100x100x6/8")
print(f"First floor brace elements: {first_floor_braces}")