import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_48_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find first floor elevation (ground level)
first_floor_z = node_df['Z (m)'].min()

# Find second floor elevation
second_floor_z = node_df[node_df['Z (m)'] > first_floor_z]['Z (m)'].min()

# Find Y-1 grid coordinate (minimum Y coordinate)
y1_coord = node_df['Y (m)'].min()

# Identify first floor braces along grid Y-1 with section 101
first_floor_braces_y1 = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    section = row['Section']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal element)
    is_diagonal = (node1_coords['Z (m)'] != node2_coords['Z (m)']) and \
                  ((node1_coords['X (m)'] != node2_coords['X (m)']) or 
                   (node1_coords['Y (m)'] != node2_coords['Y (m)']))
    
    # Check if brace is along Y-1 grid (both nodes have Y coordinate = y1_coord)
    on_y1_grid = (node1_coords['Y (m)'] == y1_coord) and (node2_coords['Y (m)'] == y1_coord)
    
    # Check if one node is on first floor and other is above
    first_floor_brace = ((node1_coords['Z (m)'] == first_floor_z and node2_coords['Z (m)'] > first_floor_z) or
                        (node2_coords['Z (m)'] == first_floor_z and node1_coords['Z (m)'] > first_floor_z))
    
    # Check if current section is 101
    has_section_101 = (section == 101)
    
    if is_diagonal and on_y1_grid and first_floor_brace and has_section_101:
        first_floor_braces_y1.append(idx)

# Update section from 101 to 103 for identified braces
for idx in first_floor_braces_y1:
    element_df.at[idx, 'Section'] = 103

# Save updated Element.csv file
element_df.to_csv('Task_48_out/Element.csv', index=False)

print(f"Updated {len(first_floor_braces_y1)} first floor braces along grid Y-1 from section 101 to section 103")