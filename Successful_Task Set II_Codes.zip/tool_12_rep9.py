import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that define residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    residential_nodes.update(nodes)

residential_nodes = list(residential_nodes)

# Find beams that connect these nodes (beams have same z-coordinate for both nodes)
supporting_beams = []

for _, element in element_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if it's a beam (same z-coordinate)
    if node1_coords['Z (m)'] == node2_coords['Z (m)']:
        # Check if both nodes are in residential load areas
        if node1 in residential_nodes and node2 in residential_nodes:
            supporting_beams.append({
                'Element ID': element['Element ID'],
                'Section': element['Section']
            })

# Convert to DataFrame and get section names
result_df = pd.DataFrame(supporting_beams)

# Merge with section data to get section names
result_df = result_df.merge(long_section_df[['Section Number', 'Section Name']], 
                           left_on='Section', right_on='Section Number', how='left')

# Select only required columns
final_result = result_df[['Element ID', 'Section Name']].sort_values('Element ID')

# Save to CSV
final_result.to_csv('Task_12_out.csv', index=False)

print(final_result)