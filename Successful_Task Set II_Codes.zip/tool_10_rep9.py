import pandas as pd
import numpy as np

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Create node coordinate lookup
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Classify elements
columns = []
beams = []
braces = []

for _, row in element_df.iterrows():
    element_id = row['Element ID']
    node1 = row['Node 1']
    node2 = row['Node 2']
    
    coord1 = node_coords[node1]
    coord2 = node_coords[node2]
    
    x1, y1, z1 = coord1
    x2, y2, z2 = coord2
    
    # Check if vertical (column): only z changes, x and y stay same
    if x1 == x2 and y1 == y2 and z1 != z2:
        columns.append(element_id)
    # Check if horizontal (beam): z stays same, x or y changes
    elif z1 == z2 and (x1 != x2 or y1 != y2):
        beams.append(element_id)
    # Otherwise diagonal (brace): z changes AND (x or y) changes
    else:
        braces.append(element_id)

# Find sub-beams (beams not directly connected to columns)
sub_beams = []

for beam_id in beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_node1 = beam_row['Node 1']
    beam_node2 = beam_row['Node 2']
    
    # Check if beam is directly connected to any column
    connected_to_column = False
    
    for col_id in columns:
        col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
        col_node1 = col_row['Node 1']
        col_node2 = col_row['Node 2']
        
        # If beam shares a node with a column, it's directly connected
        if beam_node1 in [col_node1, col_node2] or beam_node2 in [col_node1, col_node2]:
            connected_to_column = True
            break
    
    # If not connected to any column, it's a sub-beam
    if not connected_to_column:
        sub_beams.append(beam_id)

# Find sub-beams that are NOT beam-end-released
# Beam-end-release means both 'i-end release' and 'j-end release' are '11'
released_elements = set()
for _, row in beam_end_release_df.iterrows():
    if row['i-end release'] == 11 and row['j-end release'] == 11:
        released_elements.add(row['Element ID'])

# Sub-beams that are NOT beam-end-released
non_released_sub_beams = [beam_id for beam_id in sub_beams if beam_id not in released_elements]

# Sort in ascending order
non_released_sub_beams.sort()

# Create output dataframe
output_df = pd.DataFrame({
    'Element ID': non_released_sub_beams
})

# Save to CSV
output_df.to_csv('Task_10_out.csv', index=False)

print(f"Found {len(non_released_sub_beams)} sub-beams that are not beam-end-released")
print("Results saved to Task_10_out.csv")