import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find all unique floor elevations
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation (index 1)
second_floor_z = floor_elevations[1]

# Find grid Y-1 coordinate (minimum Y coordinate)
y1_coordinate = node_df['Y (m)'].min()

# Find columns on second floor along grid Y-1
# Columns are vertical elements (change only in Z coordinate)
# For second floor columns, one node should be at second floor elevation, other node above
columns_second_floor_y1 = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only Z changes)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if both nodes are on grid Y-1
        if (node1['Y (m)'] == y1_coordinate and node2['Y (m)'] == y1_coordinate):
            
            # Check if one node is at second floor and other is above
            z_coords = sorted([node1['Z (m)'], node2['Z (m)']])
            if z_coords[0] == second_floor_z and z_coords[1] > second_floor_z:
                
                # Get section and material information
                section_num = element['Section']
                material_num = element['Material']
                
                section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
                material_name = material_df[material_df['Material Number'] == material_num]['Name'].iloc[0]
                
                columns_second_floor_y1.append({
                    'Element ID': element['Element ID'],
                    'Section Name': section_name,
                    'Material Name': material_name
                })

# Create output dataframe and sort by Element ID
output_df = pd.DataFrame(columns_second_floor_y1)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_45_out.csv', index=False)

print(output_df)