import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all beam elements (horizontal elements - no change in Z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Beam: no change in Z coordinates
    if node1_z == node2_z:
        beams.append(element['Element ID'])

# Find beams supporting residential loads
supporting_beams = []

for _, load in residential_loads.iterrows():
    # Parse nodes for loading area
    load_nodes = [int(x.strip()) for x in load['Nodes for Loading Area'].split(',')]
    
    # Find beams connecting these nodes in sequence: (n1,n2), (n2,n3), (n3,n4), (n4,n1)
    beam_pairs = []
    for i in range(len(load_nodes)):
        node1 = load_nodes[i]
        node2 = load_nodes[(i + 1) % len(load_nodes)]
        beam_pairs.append((min(node1, node2), max(node1, node2)))
    
    # Find elements that match these beam pairs and are beams
    for _, element in element_df.iterrows():
        if element['Element ID'] in beams:
            element_pair = (min(element['Node 1'], element['Node 2']), max(element['Node 1'], element['Node 2']))
            if element_pair in beam_pairs:
                supporting_beams.append(element['Element ID'])

# Remove duplicates and sort
supporting_beams = sorted(list(set(supporting_beams)))

# Get section names for these beams
result_data = []
for beam_id in supporting_beams:
    element_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    section_num = element_row['Section']
    section_name = long_section_df[long_section_df['Section Number'] == section_num]['Section Name'].iloc[0]
    result_data.append({'Element ID': beam_id, 'Section Name': section_name})

# Create output dataframe and save
result_df = pd.DataFrame(result_data)
result_df.to_csv('Task_12_out.csv', index=False)

print(result_df)