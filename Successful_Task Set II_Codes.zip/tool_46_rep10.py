import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_46_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the first floor elevation (minimum z-coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify columns: elements where only z-coordinates change between nodes
columns = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (only z changes, x and y stay same)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Find first floor columns on grid X-1 with section 105
first_floor_x1_columns_105 = []
for idx, row in element_df.iterrows():
    element_id = row['Element ID']
    
    if element_id in columns and row['Section'] == 105:
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if column is on X-1 grid and has one node at first floor
        if (node1['X (m)'] == x1_coord and node2['X (m)'] == x1_coord and
            (node1['Z (m)'] == first_floor_z or node2['Z (m)'] == first_floor_z)):
            first_floor_x1_columns_105.append(element_id)

# Update material for identified columns
for element_id in first_floor_x1_columns_105:
    element_df.loc[element_df['Element ID'] == element_id, 'Material'] = 1002

# Save updated Element.csv file
element_df.to_csv('Task_46_out/Element.csv', index=False)

print(f"Updated {len(first_floor_x1_columns_105)} first floor columns on grid X-1 with section 105 to material 1002")
print(f"Column IDs updated: {first_floor_x1_columns_105}")