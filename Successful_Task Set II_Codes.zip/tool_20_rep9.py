import pandas as pd
import numpy as np
import math

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Identify first floor elevation
first_floor_z = 0.0

# Find all unique floor elevations and sort them
all_z_coords = sorted(node_df['Z (m)'].unique())
first_floor_z = all_z_coords[0]  # Ground level
second_floor_z = all_z_coords[1] if len(all_z_coords) > 1 else first_floor_z + 1

# Identify columns: vertical elements (change only in z-coordinate)
columns = []
for _, element in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if element is vertical (column)
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    if dx < 1e-6 and dy < 1e-6 and dz > 1e-6:  # Vertical element
        columns.append({
            'Element ID': element['Element ID'],
            'Section': element['Section'],
            'Node1_Z': node1['Z (m)'],
            'Node2_Z': node2['Z (m)'],
            'Length': dz
        })

# Filter first floor columns: one node at first floor, other node above first floor
first_floor_columns = []
for col in columns:
    node1_z = col['Node1_Z']
    node2_z = col['Node2_Z']
    
    # Check if one node is at first floor and the other is above
    if (abs(node1_z - first_floor_z) < 1e-6 and node2_z > first_floor_z) or \
       (abs(node2_z - first_floor_z) < 1e-6 and node1_z > first_floor_z):
        first_floor_columns.append(col)

# Calculate total weight
total_weight = 0.0
steel_density = 7850  # kg/m^3

for col in first_floor_columns:
    section_num = col['Section']
    section_info = section_df[section_df['Section Number'] == section_num].iloc[0]
    cross_sectional_area = section_info['Area']  # m^2
    length = col['Length']  # m
    
    volume = cross_sectional_area * length  # m^3
    weight = volume * steel_density  # kg
    total_weight += weight

# Round up to nearest 100 kg
total_weight_rounded = math.ceil(total_weight / 100) * 100

# Create output CSV
output_df = pd.DataFrame({
    'Total Weight of First Floor Columns (kg)': [total_weight_rounded]
})

output_df.to_csv('Task_20_out.csv', index=False)