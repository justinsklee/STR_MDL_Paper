import pandas as pd
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (maximum z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Get nodes at roof elevation
roof_nodes = node_df[node_df['Z (m)'] == roof_elevation]['Node ID'].tolist()

# Identify beams (elements with no change in z-coordinates)
beams = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    if node1_z == node2_z:  # Beam (horizontal element)
        beams.append(row['Element ID'])

# Find beams on roof level
roof_beams = []
for beam_id in beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_row['Node 1']
    node2_id = beam_row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    
    if node1_z == roof_elevation:
        roof_beams.append(beam_id)

# Identify columns (elements with change only in z-coordinates)
columns = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Find nodes that are connected to columns
column_connected_nodes = set()
for col_id in columns:
    col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
    column_connected_nodes.add(col_row['Node 1'])
    column_connected_nodes.add(col_row['Node 2'])

# Find sub-beams on roof (beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_row['Node 1']
    node2_id = beam_row['Node 2']
    
    # Check if both nodes are NOT connected to columns
    if node1_id not in column_connected_nodes and node2_id not in column_connected_nodes:
        roof_sub_beams.append(beam_id)

# Update section for roof sub-beams to 104
for beam_id in roof_sub_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 104

# Save updated Element.csv
element_df.to_csv('Task_22_out/Element.csv', index=False)