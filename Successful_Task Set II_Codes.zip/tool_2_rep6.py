import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get the maximum Z coordinate (roof level)
max_z = node_df['Z (m)'].max()

# Filter elements that are beams (no change in Z coordinates)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in Z coordinates)
    if node1_z == node2_z:
        beams.append({
            'Element ID': element['Element ID'],
            'Node 1': node1_id,
            'Node 2': node2_id,
            'Z': node1_z
        })

beams_df = pd.DataFrame(beams)

# Filter roof beams (beams at maximum Z level)
roof_beams = beams_df[beams_df['Z'] == max_z]

# Find columns (vertical elements)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_data = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_data = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (change only in Z, no change in X and Y)
    if (node1_data['X (m)'] == node2_data['X (m)'] and 
        node1_data['Y (m)'] == node2_data['Y (m)'] and 
        node1_data['Z (m)'] != node2_data['Z (m)']):
        columns.append(element['Element ID'])

# Find nodes that are connected to columns
column_connected_nodes = set()
for _, element in element_df.iterrows():
    if element['Element ID'] in columns:
        column_connected_nodes.add(element['Node 1'])
        column_connected_nodes.add(element['Node 2'])

# Find roof sub-beams (roof beams not directly connected to columns)
roof_sub_beams = []
for _, beam in roof_beams.iterrows():
    node1 = beam['Node 1']
    node2 = beam['Node 2']
    
    # Check if neither end of the beam is connected to a column
    if node1 not in column_connected_nodes and node2 not in column_connected_nodes:
        roof_sub_beams.append(beam['Element ID'])

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(roof_sub_beams)})

# Save to CSV
output_df.to_csv('Task_2_out.csv', index=False)

print(f"Found {len(roof_sub_beams)} roof sub-beams")
print(output_df)