import pandas as pd
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Get nodes at roof level
roof_nodes = node_df[node_df['Z (m)'] == roof_elevation]['Node ID'].tolist()

# Identify beams (elements with no change in z-coordinate)
beams = []
for _, row in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == row['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == row['Node 2']]['Z (m)'].iloc[0]
    
    if node1_z == node2_z:  # Beam (horizontal element)
        beams.append(row['Element ID'])

# Find roof beams (beams at roof elevation)
roof_beams = []
for beam_id in beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_z = node_df[node_df['Node ID'] == beam_row['Node 1']]['Z (m)'].iloc[0]
    
    if node1_z == roof_elevation:
        roof_beams.append(beam_id)

# Identify columns (elements with change only in z-coordinate)
columns = []
for _, row in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == row['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == row['Node 2']].iloc[0]
    
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Find sub-beams on roof (roof beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1 = beam_row['Node 1']
    node2 = beam_row['Node 2']
    
    # Check if either node is connected to a column
    connected_to_column = False
    for col_id in columns:
        col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
        if node1 in [col_row['Node 1'], col_row['Node 2']] or node2 in [col_row['Node 1'], col_row['Node 2']]:
            connected_to_column = True
            break
    
    if not connected_to_column:
        roof_sub_beams.append(beam_id)

# Update section for roof sub-beams to 104
for beam_id in roof_sub_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 104

# Sort by Element ID in ascending order
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_22_out/Element.csv', index=False)