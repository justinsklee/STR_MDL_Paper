import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_38_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Identify first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find all unique x-coordinates to identify grids
x_coords = sorted(node_df['X (m)'].unique())

# X-2 grid corresponds to the second x-coordinate
x2_coord = x_coords[1]  # Index 1 for X-2 grid

# Find nodes on first floor (z = 0.0) at X-2 grid
first_floor_x2_nodes = node_df[(node_df['Z (m)'] == first_floor_z) & 
                               (node_df['X (m)'] == x2_coord)]['Node ID'].tolist()

# Find columns: vertical elements with one node on first floor at X-2 and other node above
first_floor_x2_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a vertical element (column)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        
        # Check if one node is on first floor at X-2 grid and other is above
        node1_on_first_floor_x2 = (node1_coords['Z (m)'] == first_floor_z and 
                                   node1_coords['X (m)'] == x2_coord)
        node2_on_first_floor_x2 = (node2_coords['Z (m)'] == first_floor_z and 
                                   node2_coords['X (m)'] == x2_coord)
        
        if ((node1_on_first_floor_x2 and node2_coords['Z (m)'] > first_floor_z) or
            (node2_on_first_floor_x2 and node1_coords['Z (m)'] > first_floor_z)):
            first_floor_x2_columns.append(element['Element ID'])

# Update material for identified columns
element_df.loc[element_df['Element ID'].isin(first_floor_x2_columns), 'Material'] = shn355_material

# Save updated Element.csv
element_df.to_csv('Task_38_out/Element.csv', index=False)

print(f"Updated {len(first_floor_x2_columns)} first floor columns along grid X-2 to material SHN355")
print(f"Column IDs updated: {first_floor_x2_columns}")