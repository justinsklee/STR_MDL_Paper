import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_47_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
support_df = pd.read_csv('Support.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (minimum z value)
first_floor_z = nodes_df['Z (m)'].min()

# Find Y-1 grid coordinate (minimum y value)
y1_grid_coord = nodes_df['Y (m)'].min()

# Find nodes on first floor and Y-1 grid
first_floor_y1_nodes = nodes_df[
    (nodes_df['Z (m)'] == first_floor_z) & 
    (nodes_df['Y (m)'] == y1_grid_coord)
]['Node ID'].tolist()

# Find columns (vertical elements) with section 101
columns_section_101 = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    section = element['Section']
    
    # Get node coordinates
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical: only z changes, x and y stay same)
    is_column = (node1['X (m)'] == node2['X (m)'] and 
                node1['Y (m)'] == node2['Y (m)'] and 
                node1['Z (m)'] != node2['Z (m)'])
    
    # Check if it has section 101 and one node is on first floor Y-1 grid
    if is_column and section == 101:
        if node1_id in first_floor_y1_nodes or node2_id in first_floor_y1_nodes:
            # Find the node on first floor Y-1 grid
            if node1_id in first_floor_y1_nodes:
                target_node = node1_id
            else:
                target_node = node2_id
            columns_section_101.append(target_node)

# Update support conditions for identified nodes (pin support: Dx=1, Dy=1, Dz=1, Rx=0, Ry=0, Rz=0)
for node_id in columns_section_101:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated Support.csv
support_df.to_csv('Task_47_out/Support.csv', index=False)

print(f"Updated support conditions for {len(columns_section_101)} first floor columns along grid Y-1 with section 101")
print(f"Nodes updated: {columns_section_101}")