import pandas as pd

# Load all relevant CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify beams (horizontal elements - no change in Z coordinates)
beams = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (same Z coordinate)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Identify columns (vertical elements - change only in Z coordinates)
columns = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (same X and Y, different Z)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Find nodes that are connected to columns
column_nodes = set()
for column_id in columns:
    column_element = elements_df[elements_df['Element ID'] == column_id].iloc[0]
    column_nodes.add(column_element['Node 1'])
    column_nodes.add(column_element['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    beam_element = elements_df[elements_df['Element ID'] == beam_id].iloc[0]
    node1 = beam_element['Node 1']
    node2 = beam_element['Node 2']
    
    # If neither node is connected to a column, it's a sub-beam
    if node1 not in column_nodes and node2 not in column_nodes:
        sub_beams.append(beam_id)

# Find sub-beams that are NOT beam-end-released
# Beam-end-released means both i-end and j-end release are '11'
released_elements = set()
for _, release in beam_end_release_df.iterrows():
    if release['i-end release'] == 11 and release['j-end release'] == 11:
        released_elements.add(release['Element ID'])

# Sub-beams that are NOT beam-end-released
non_released_sub_beams = [beam_id for beam_id in sub_beams if beam_id not in released_elements]

# Sort in ascending order
non_released_sub_beams.sort()

# Create output dataframe
output_df = pd.DataFrame({
    'Element ID': non_released_sub_beams
})

# Save to CSV file
output_df.to_csv('Task_10_out.csv', index=False)