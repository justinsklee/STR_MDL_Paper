import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_30_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Fourth floor is at index 3 (0-indexed: ground=0, 2nd=1, 3rd=2, 4th=3)
if len(floor_elevations) > 3:
    fourth_floor_z = floor_elevations[3]
    
    # Find braces on fourth floor
    # Braces have one node at fourth floor and another node above fourth floor
    braces_to_remove = []
    
    for idx, row in elements_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates of both nodes
        node1_coords = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
        node2_coords = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
        
        node1_x, node1_y, node1_z = node1_coords['X (m)'], node1_coords['Y (m)'], node1_coords['Z (m)']
        node2_x, node2_y, node2_z = node2_coords['X (m)'], node2_coords['Y (m)'], node2_coords['Z (m)']
        
        # Check if this is a brace (diagonal element with change in x/y AND z coordinates)
        x_change = abs(node1_x - node2_x) > 1e-6
        y_change = abs(node1_y - node2_y) > 1e-6
        z_change = abs(node1_z - node2_z) > 1e-6
        
        is_brace = (x_change or y_change) and z_change
        
        # Check if brace is on fourth floor (one node at fourth floor, other above)
        if is_brace:
            node_at_fourth_floor = (node1_z == fourth_floor_z) or (node2_z == fourth_floor_z)
            node_above_fourth_floor = (node1_z > fourth_floor_z) or (node2_z > fourth_floor_z)
            
            if node_at_fourth_floor and node_above_fourth_floor:
                braces_to_remove.append(row['Element ID'])
    
    # Remove braces from elements dataframe
    elements_df = elements_df[~elements_df['Element ID'].isin(braces_to_remove)]

# Save updated Element.csv file
elements_df.to_csv('Task_30_out/Element.csv', index=False)