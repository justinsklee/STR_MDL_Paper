import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Create output folder
os.makedirs('Task_25_out', exist_ok=True)

# Find all unique Z coordinates and sort them to identify floors
unique_z = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
if len(unique_z) >= 3:
    third_floor_z = unique_z[2]
    
    # Find all nodes at third floor level
    third_floor_nodes = node_df[node_df['Z (m)'] == third_floor_z]['Node ID'].tolist()
    
    # Find columns that have one node at third floor and another node above third floor
    third_floor_columns = []
    
    for _, element in element_df.iterrows():
        node1 = element['Node 1']
        node2 = element['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
        
        # Check if it's a column (vertical element - same x,y but different z)
        is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                    node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                    node1_coords['Z (m)'] != node2_coords['Z (m)'])
        
        if is_column:
            # Check if one node is at third floor and the other is above
            if ((node1_coords['Z (m)'] == third_floor_z and node2_coords['Z (m)'] > third_floor_z) or
                (node2_coords['Z (m)'] == third_floor_z and node1_coords['Z (m)'] > third_floor_z)):
                third_floor_columns.append(element['Element ID'])
    
    # Find material number for SS400
    ss400_material = material_df[material_df['Name'] == 'SS400']['Material Number'].iloc[0]
    
    # Update material for third floor columns
    for col_id in third_floor_columns:
        element_df.loc[element_df['Element ID'] == col_id, 'Material'] = ss400_material

# Save updated Element.csv
element_df.to_csv('Task_25_out/Element.csv', index=False)

print(f"Updated {len(third_floor_columns)} third floor columns with SS400 material")