import pandas as pd
import os

# Create output folder
os.makedirs('Task_35_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find residential loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that define residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    residential_nodes.update(nodes)

# Find columns that support residential loads (columns below these nodes)
supporting_columns = []

for node_id in residential_nodes:
    # Get the z-coordinate of this node
    node_z = node_df[node_df['Node ID'] == node_id]['Z (m)'].iloc[0]
    
    # Find columns that have this node as their upper end (Node 2)
    # and their lower end (Node 1) is below this floor
    for _, element in element_df.iterrows():
        node1 = element['Node 1']
        node2 = element['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Check if this is a column (vertical element)
        is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                    node1_coords['Y (m)'] == node2_coords['Y (m)'] and
                    node1_coords['Z (m)'] != node2_coords['Z (m)'])
        
        if is_column:
            # Check if this column supports the residential load node
            # Column supports from below, so check if node2 matches residential node and node1 is below
            if (node2 == node_id and node1_coords['Z (m)'] < node_z):
                supporting_columns.append(element['Element ID'])

# Update material for supporting columns to SHN355 (material 1003)
for col_id in supporting_columns:
    element_df.loc[element_df['Element ID'] == col_id, 'Material'] = 1003

# Save updated Element.csv
element_df.to_csv('Task_35_out/Element.csv', index=False)

print(f"Updated {len(supporting_columns)} columns supporting residential loads to SHN355 material")
print(f"Column IDs updated: {supporting_columns}")