import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_36_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support node IDs
support_nodes = set(support_df['Node'].tolist())

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if column (vertical)
    if x1 == x2 and y1 == y2 and z1 != z2:
        return 'column'
    # Check if beam (horizontal)
    elif z1 == z2:
        return 'beam'
    # Otherwise it's a brace (diagonal)
    else:
        return 'brace'

# Classify all elements
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find columns that share supports with bracing elements
columns_to_update = []

for idx, row in element_df.iterrows():
    if row['element_type'] == 'column':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Check if either node is a support node
        column_support_nodes = {node1_id, node2_id} & support_nodes
        
        if column_support_nodes:
            # Check if any bracing element shares these support nodes
            for brace_idx, brace_row in element_df.iterrows():
                if brace_row['element_type'] == 'brace':
                    brace_nodes = {brace_row['Node 1'], brace_row['Node 2']}
                    
                    # If the column and brace share a support node
                    if column_support_nodes & brace_nodes:
                        columns_to_update.append(row['Element ID'])
                        break

# Update section for identified columns
for element_id in columns_to_update:
    element_df.loc[element_df['Element ID'] == element_id, 'Section'] = 101

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_36_out/Element.csv', index=False)