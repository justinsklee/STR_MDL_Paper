import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_48_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the first floor elevation (ground level)
first_floor_z = node_df['Z (m)'].min()

# Find the second floor elevation
second_floor_z = node_df[node_df['Z (m)'] > first_floor_z]['Z (m)'].min()

# Find Y-1 grid coordinate (minimum Y coordinate)
y1_grid = node_df['Y (m)'].min()

# Identify first floor braces along grid Y-1
first_floor_braces = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (change in x or y AND z coordinates)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if both nodes are on Y-1 grid
        node1_on_y1 = abs(node1['Y (m)'] - y1_grid) < 1e-6
        node2_on_y1 = abs(node2['Y (m)'] - y1_grid) < 1e-6
        
        if node1_on_y1 and node2_on_y1:
            # Check if one node is on first floor and other is above
            node1_first_floor = abs(node1['Z (m)'] - first_floor_z) < 1e-6
            node2_first_floor = abs(node2['Z (m)'] - first_floor_z) < 1e-6
            node1_above_first = node1['Z (m)'] > first_floor_z
            node2_above_first = node2['Z (m)'] > first_floor_z
            
            if (node1_first_floor and node2_above_first) or (node2_first_floor and node1_above_first):
                # Check if current section is 101
                if row['Section'] == 101:
                    first_floor_braces.append(idx)

# Update section for identified braces
for idx in first_floor_braces:
    element_df.at[idx, 'Section'] = 103

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Updated {len(first_floor_braces)} first floor braces along grid Y-1 from section 101 to section 103")