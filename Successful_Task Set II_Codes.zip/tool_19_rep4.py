import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Function to calculate element length
def calculate_length(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = node2['X (m)'] - node1['X (m)']
    dy = node2['Y (m)'] - node1['Y (m)']
    dz = node2['Z (m)'] - node1['Z (m)']
    
    length = np.sqrt(dx**2 + dy**2 + dz**2)
    return length

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    # Columns: change in ONLY 'z' coordinates and no change in ('x' and 'y') coordinates
    if dz > 0 and dx == 0 and dy == 0:
        return 'Column'
    # Beams: NO change in 'z' coordinates
    elif dz == 0:
        return 'Beam'
    # Braces: change in ('x' or 'y') coordinates AND 'z' coordinates
    elif (dx > 0 or dy > 0) and dz > 0:
        return 'Brace'
    else:
        return 'Unknown'

# Calculate lengths and classify elements
element_df['Length'] = element_df.apply(calculate_length, axis=1)
element_df['Type'] = element_df.apply(classify_element, axis=1)

# Filter for beams shorter than 1.3m
short_beams = element_df[(element_df['Type'] == 'Beam') & (element_df['Length'] < 1.3)]

# Create output dataframe
output_df = short_beams[['Element ID', 'Length']].copy()
output_df = output_df.sort_values('Element ID')
output_df.columns = ['Element Number', 'Length']

# Save to CSV
output_df.to_csv('Task_19_out.csv', index=False)