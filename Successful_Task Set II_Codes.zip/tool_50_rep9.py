import pandas as pd
import numpy as np

# Load CSV files
floor_load_df = pd.read_csv('Floor_Load.csv')
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Initialize list to store beam information
beam_info = []

# For each office load area
for _, load in office_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create beam pairs from the 4 nodes (forming a rectangle)
    beam_pairs = [
        (nodes[0], nodes[1]),
        (nodes[1], nodes[2]), 
        (nodes[2], nodes[3]),
        (nodes[3], nodes[0])
    ]
    
    # Find elements that connect these node pairs
    for node1, node2 in beam_pairs:
        # Find element connecting these nodes
        element = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        if not element.empty:
            element_id = element.iloc[0]['Element ID']
            section_num = element.iloc[0]['Section']
            
            # Get node coordinates to calculate length
            node1_coords = node_df[node_df['Node ID'] == node1][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
            node2_coords = node_df[node_df['Node ID'] == node2][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
            
            # Calculate length
            length = np.sqrt(
                (node2_coords['X (m)'] - node1_coords['X (m)'])**2 +
                (node2_coords['Y (m)'] - node1_coords['Y (m)'])**2 +
                (node2_coords['Z (m)'] - node1_coords['Z (m)'])**2
            )
            
            beam_info.append({
                'Element ID': element_id,
                'Section Number': section_num,
                'Length (m)': round(length, 3)
            })

# Create DataFrame and remove duplicates
result_df = pd.DataFrame(beam_info).drop_duplicates().sort_values('Element ID').reset_index(drop=True)

# Save to CSV
result_df.to_csv('Task_50_out.csv', index=False)

print(result_df)