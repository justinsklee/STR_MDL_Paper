import pandas as pd
import os

# Create output folder
os.makedirs('Task_43_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Find X1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify braces: elements that change in both (x or y) AND z coordinates
braces = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element changes in z AND (x or y)
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    xy_change = (abs(node1['X (m)'] - node2['X (m)']) > 1e-6) or (abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6)
    
    if z_change and xy_change:
        braces.append(element['Element ID'])

# Find braces along grid X1 (both nodes have X1 coordinate)
braces_on_x1 = []
for element_id in braces:
    element = element_df[element_df['Element ID'] == element_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on X1 grid
    if abs(node1['X (m)'] - x1_coord) < 1e-6 and abs(node2['X (m)'] - x1_coord) < 1e-6:
        braces_on_x1.extend([node1_id, node2_id])

# Remove duplicates
nodes_supporting_braces_x1 = list(set(braces_on_x1))

# Update support conditions for these nodes (pin support: Dx=1, Dy=1, Dz=1, Rx=0, Ry=0, Rz=0)
for node_id in nodes_supporting_braces_x1:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Dx', 'Dy', 'Dz']] = 1
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated Support.csv
support_df.to_csv('Task_43_out/Support.csv', index=False)

print(f"Updated support conditions for {len(nodes_supporting_braces_x1)} nodes supporting braces along grid X1")
print("Updated Support.csv saved to Task_43_out folder")