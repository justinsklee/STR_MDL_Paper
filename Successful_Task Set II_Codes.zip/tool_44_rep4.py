import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_44_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the top floor elevation
max_z = node_df['Z (m)'].max()

# Find beams on the top floor
top_floor_beams = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates of both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in z coordinates)
    if node1['Z (m)'] == node2['Z (m)']:
        # Check if it's on the top floor
        if node1['Z (m)'] == max_z:
            # Calculate beam length
            length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                           (node2['Y (m)'] - node1['Y (m)'])**2 + 
                           (node2['Z (m)'] - node1['Z (m)'])**2)
            
            # Check if length is longer than 1.65 meters
            if length > 1.65:
                top_floor_beams.append(element['Element ID'])

# Update section numbers for qualifying beams
for beam_id in top_floor_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 105

# Save updated Element.csv file
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Updated {len(top_floor_beams)} top floor beams with length > 1.65m to section 105")
print(f"Updated Element IDs: {top_floor_beams}")