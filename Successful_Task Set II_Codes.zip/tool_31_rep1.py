import pandas as pd

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Third floor is at index 2 (0-based: ground=0, second=1, third=2)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
else:
    third_floor_elevation = None

if third_floor_elevation is not None:
    # Get nodes on third floor
    third_floor_nodes = nodes_df[nodes_df['Z (m)'] == third_floor_elevation]['Node ID'].tolist()
    
    # Get beams on third floor (both nodes at same elevation)
    third_floor_beams = []
    for _, element in elements_df.iterrows():
        node1_z = nodes_df[nodes_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
        node2_z = nodes_df[nodes_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
        
        # Beam: no change in z coordinates
        if node1_z == node2_z == third_floor_elevation:
            third_floor_beams.append(element['Element ID'])
    
    # Identify columns (vertical elements with one node on third floor and other above)
    columns_connected_to_third_floor = []
    for _, element in elements_df.iterrows():
        node1_z = nodes_df[nodes_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
        node2_z = nodes_df[nodes_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
        
        # Column: change only in z coordinates
        node1_x = nodes_df[nodes_df['Node ID'] == element['Node 1']]['X (m)'].iloc[0]
        node1_y = nodes_df[nodes_df['Node ID'] == element['Node 1']]['Y (m)'].iloc[0]
        node2_x = nodes_df[nodes_df['Node ID'] == element['Node 2']]['X (m)'].iloc[0]
        node2_y = nodes_df[nodes_df['Node ID'] == element['Node 2']]['Y (m)'].iloc[0]
        
        if (node1_x == node2_x and node1_y == node2_y and node1_z != node2_z):
            # Check if one node is on third floor and other is above
            if (node1_z == third_floor_elevation and node2_z > third_floor_elevation) or \
               (node2_z == third_floor_elevation and node1_z > third_floor_elevation):
                # Get the node that's on the third floor
                third_floor_node = element['Node 1'] if node1_z == third_floor_elevation else element['Node 2']
                columns_connected_to_third_floor.append(third_floor_node)
    
    # Sub-beams are beams not directly connected to columns
    third_floor_sub_beams = []
    for beam_id in third_floor_beams:
        beam_row = elements_df[elements_df['Element ID'] == beam_id].iloc[0]
        node1 = beam_row['Node 1']
        node2 = beam_row['Node 2']
        
        # Check if beam is connected to any column
        if node1 not in columns_connected_to_third_floor and node2 not in columns_connected_to_third_floor:
            third_floor_sub_beams.append(beam_id)
    
    # Create result dataframe
    result_data = []
    for beam_id in third_floor_sub_beams:
        # Check if beam has end release
        release_row = beam_end_release_df[beam_end_release_df['Element ID'] == beam_id]
        if not release_row.empty:
            i_end_release = release_row.iloc[0]['i-end release']
            j_end_release = release_row.iloc[0]['j-end release']
            
            # Convert release codes to 0/1 (0 for released, 1 for fixed)
            i_status = 0 if str(i_end_release) == '11' else 1
            j_status = 0 if str(j_end_release) == '11' else 1
        else:
            # No release means fixed
            i_status = 1
            j_status = 1
        
        result_data.append([beam_id, i_status, j_status])
    
    # Create DataFrame and sort by element number
    result_df = pd.DataFrame(result_data, columns=['Element Number', 'I-End (0=Released, 1=Fixed)', 'J-End (0=Released, 1=Fixed)'])
    result_df = result_df.sort_values('Element Number')
    
    # Save to CSV
    result_df.to_csv('Task_31_out.csv', index=False)
    
    print(f"Third floor sub-beams beam-end-release status saved to Task_31_out.csv")
    print(result_df)
else:
    print("Third floor not found in the model")