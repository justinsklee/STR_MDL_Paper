import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_46_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the first floor elevation (minimum z-coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify columns: vertical elements (change only in z-coordinate)
columns = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(idx)

# Filter first floor columns along grid X-1 with section 105
first_floor_x1_columns_105 = []
for col_idx in columns:
    row = element_df.iloc[col_idx]
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if column is on X-1 grid
    if node1['X (m)'] == x1_coord and node2['X (m)'] == x1_coord:
        # Check if column has one node at first floor and other above
        if ((node1['Z (m)'] == first_floor_z and node2['Z (m)'] > first_floor_z) or
            (node2['Z (m)'] == first_floor_z and node1['Z (m)'] > first_floor_z)):
            # Check if section is 105
            if row['Section'] == 105:
                first_floor_x1_columns_105.append(col_idx)

# Update material to 1002 for identified columns
for col_idx in first_floor_x1_columns_105:
    element_df.at[col_idx, 'Material'] = 1002

# Save updated Element.csv
element_df.to_csv('Task_46_out/Element.csv', index=False)