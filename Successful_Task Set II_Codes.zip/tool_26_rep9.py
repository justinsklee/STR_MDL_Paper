import pandas as pd
import os

# Create output folder
os.makedirs('Task_26_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Get material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Find unique floor elevations and identify second floor
floor_elevations = sorted(node_df['Z (m)'].unique())
second_floor_elevation = floor_elevations[1]  # Second floor (index 1)

# Identify beams on second floor
# Beams are horizontal elements (no change in z coordinates between nodes)
second_floor_beams = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in z coordinate)
    if node1_coords['Z (m)'] == node2_coords['Z (m)']:
        # Check if it's on second floor
        if node1_coords['Z (m)'] == second_floor_elevation:
            second_floor_beams.append(row['Element ID'])

# Update material for second floor beams
element_df.loc[element_df['Element ID'].isin(second_floor_beams), 'Material'] = shn355_material

# Save updated Element.csv
element_df.to_csv('Task_26_out/Element.csv', index=False)

print(f"Updated {len(second_floor_beams)} second floor beams with SHN355 material")
print(f"Second floor beam IDs: {second_floor_beams}")