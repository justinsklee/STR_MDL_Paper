import pandas as pd
import os

# Create output folder
os.makedirs('Task_37_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Create node coordinates dictionary
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Classify elements
def classify_element(node1_id, node2_id):
    x1, y1, z1 = node_coords[node1_id]
    x2, y2, z2 = node_coords[node2_id]
    
    if z1 == z2:  # No change in z
        return 'beam'
    elif x1 == x2 and y1 == y2:  # Only z changes
        return 'column'
    else:  # Change in x or y AND z
        return 'brace'

# Add classification to elements
element_df['Type'] = element_df.apply(lambda row: classify_element(row['Node 1'], row['Node 2']), axis=1)

# Get all beams
beams_df = element_df[element_df['Type'] == 'beam'].copy()

# Get all columns
columns_df = element_df[element_df['Type'] == 'column'].copy()

# Find beams connected to columns (main beams)
main_beam_ids = set()

for _, beam in beams_df.iterrows():
    beam_node1 = beam['Node 1']
    beam_node2 = beam['Node 2']
    
    # Check if any column is connected to this beam's nodes
    for _, column in columns_df.iterrows():
        col_node1 = column['Node 1']
        col_node2 = column['Node 2']
        
        if beam_node1 in [col_node1, col_node2] or beam_node2 in [col_node1, col_node2]:
            main_beam_ids.add(beam['Element ID'])
            break

# Identify sub-beams (beams not connected to columns)
sub_beam_ids = set()
for _, beam in beams_df.iterrows():
    if beam['Element ID'] not in main_beam_ids:
        sub_beam_ids.add(beam['Element ID'])

# Get beam-end-released element IDs
released_element_ids = set(beam_end_release_df['Element ID'])

# Find sub-beams that are NOT beam-end-released
sub_beams_not_released = sub_beam_ids - released_element_ids

# Remove these sub-beams from the element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_not_released)].copy()

# Drop the temporary 'Type' column
updated_element_df = updated_element_df.drop('Type', axis=1)

# Sort by Element ID
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_37_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_not_released)} sub-beams that were not beam-end-released")
print(f"Updated Element.csv saved with {len(updated_element_df)} elements")