import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Get all unique z-coordinates and sort them to find floor elevations
unique_z = sorted(node_df['Z (m)'].unique())
first_floor_z = unique_z[0]  # Ground level
second_floor_z = unique_z[1] if len(unique_z) > 1 else first_floor_z + 1

# Create node coordinate lookup
node_coords = {}
for _, row in node_df.iterrows():
    node_coords[row['Node ID']] = (row['X (m)'], row['Y (m)'], row['Z (m)'])

# Find first floor bracing elements
first_floor_bracing = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    if node1_id in node_coords and node2_id in node_coords:
        x1, y1, z1 = node_coords[node1_id]
        x2, y2, z2 = node_coords[node2_id]
        
        # Check if this is a bracing element (diagonal: changes in x/y AND z coordinates)
        x_change = abs(x2 - x1) > 1e-6
        y_change = abs(y2 - y1) > 1e-6
        z_change = abs(z2 - z1) > 1e-6
        
        is_bracing = (x_change or y_change) and z_change
        
        # Check if it's first floor bracing (one node at first floor, other above)
        if is_bracing:
            node1_at_first_floor = abs(z1 - first_floor_z) < 1e-6
            node2_at_first_floor = abs(z2 - first_floor_z) < 1e-6
            node1_above_first_floor = z1 > first_floor_z
            node2_above_first_floor = z2 > first_floor_z
            
            # One node at first floor, other node above first floor
            if (node1_at_first_floor and node2_above_first_floor) or (node2_at_first_floor and node1_above_first_floor):
                first_floor_bracing.append({
                    'Element ID': element['Element ID'],
                    'Section': element['Section']
                })

# Create output dataframe and sort by Element ID
output_df = pd.DataFrame(first_floor_bracing)
if not output_df.empty:
    output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_13_out.csv', index=False)

print(f"Found {len(first_floor_bracing)} first floor bracing elements")
if not output_df.empty:
    print(output_df.to_string(index=False))