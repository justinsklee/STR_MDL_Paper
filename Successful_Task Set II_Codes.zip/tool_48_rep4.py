import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_48_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique Y coordinates to identify Y grids
y_coords = sorted(node_df['Y (m)'].unique())
y1_coord = y_coords[0]  # First Y grid (Y-1)

# Get unique Z coordinates to identify floors
z_coords = sorted(node_df['Z (m)'].unique())
first_floor_z = z_coords[0]  # First floor (z = 0.0m)
second_floor_z = z_coords[1] if len(z_coords) > 1 else None  # Second floor

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    if z_change and not x_change and not y_change:
        return 'column'
    elif not z_change:
        return 'beam'
    elif z_change and (x_change or y_change):
        return 'brace'
    else:
        return 'unknown'

# Function to check if element is on Y-1 grid
def is_on_y1_grid(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    return (abs(node1['Y (m)'] - y1_coord) < 1e-6 and 
            abs(node2['Y (m)'] - y1_coord) < 1e-6)

# Function to check if brace is for first floor
def is_first_floor_brace(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    z1, z2 = node1['Z (m)'], node2['Z (m)']
    
    # One node at first floor, other node above first floor
    return ((abs(z1 - first_floor_z) < 1e-6 and z2 > first_floor_z) or
            (abs(z2 - first_floor_z) < 1e-6 and z1 > first_floor_z))

# Apply classification and filtering
element_df['element_type'] = element_df.apply(classify_element, axis=1)
element_df['on_y1_grid'] = element_df.apply(is_on_y1_grid, axis=1)
element_df['is_first_floor_brace'] = element_df.apply(is_first_floor_brace, axis=1)

# Find first floor braces along Y-1 grid with section 101
mask = ((element_df['element_type'] == 'brace') & 
        (element_df['on_y1_grid'] == True) & 
        (element_df['is_first_floor_brace'] == True) & 
        (element_df['Section'] == 101))

# Update section to 103
element_df.loc[mask, 'Section'] = 103

# Remove helper columns
element_df = element_df.drop(['element_type', 'on_y1_grid', 'is_first_floor_brace'], axis=1)

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_48_out/Element.csv', index=False)