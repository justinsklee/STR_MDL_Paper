import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_24_out'
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_elevation = floor_elevations[0]  # Ground level (z = 0.0m)
second_floor_elevation = floor_elevations[1] if len(floor_elevations) > 1 else first_floor_elevation + 1

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if element is a column (vertical: only z changes)
    if x1 == x2 and y1 == y2 and z1 != z2:
        return 'column'
    # Check if element is a beam (horizontal: no z change)
    elif z1 == z2:
        return 'beam'
    # Check if element is a brace (diagonal: x or y changes AND z changes)
    elif (x1 != x2 or y1 != y2) and z1 != z2:
        return 'brace'
    else:
        return 'unknown'

# Add classification to elements
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find first floor braces
# First floor braces have one node at first floor elevation and another node above it
first_floor_braces = []

for idx, row in element_df.iterrows():
    if row['element_type'] == 'brace':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        z1, z2 = node1['Z (m)'], node2['Z (m)']
        
        # Check if one node is at first floor and the other is above
        if (z1 == first_floor_elevation and z2 > first_floor_elevation) or \
           (z2 == first_floor_elevation and z1 > first_floor_elevation):
            first_floor_braces.append(row['Element ID'])

# Update material for first floor braces to 1003
element_df.loc[element_df['Element ID'].isin(first_floor_braces), 'Material'] = 1003

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)

print(f"Updated {len(first_floor_braces)} first floor braces with material 1003")
print(f"First floor brace Element IDs: {first_floor_braces}")