import pandas as pd
import os

# Create output folder
os.makedirs('Task_37_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')
node_df = pd.read_csv('Node.csv')

# Identify columns (vertical elements with only z-coordinate change)
columns = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Identify beams (horizontal elements with no z-coordinate change)
beams = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(row['Element ID'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_row['Node 1']
    node2_id = beam_row['Node 2']
    
    # Check if beam is connected to any column
    connected_to_column = False
    for column_id in columns:
        column_row = element_df[element_df['Element ID'] == column_id].iloc[0]
        column_node1 = column_row['Node 1']
        column_node2 = column_row['Node 2']
        
        if (node1_id in [column_node1, column_node2] or 
            node2_id in [column_node1, column_node2]):
            connected_to_column = True
            break
    
    if not connected_to_column:
        sub_beams.append(beam_id)

# Get beam-end-released elements
beam_end_released = set(beam_end_release_df['Element ID'].tolist())

# Remove sub-beams that are NOT beam-end-released
sub_beams_to_remove = []
for sub_beam_id in sub_beams:
    if sub_beam_id not in beam_end_released:
        sub_beams_to_remove.append(sub_beam_id)

# Filter out the sub-beams that are not beam-end-released
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beams_to_remove)].copy()

# Sort by Element ID
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_37_out/Element.csv', index=False)

print(f"Removed {len(sub_beams_to_remove)} sub-beams that were not beam-end-released")
print(f"Sub-beams removed: {sub_beams_to_remove}")