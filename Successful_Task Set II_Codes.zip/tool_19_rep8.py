import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Function to classify elements
def classify_element(node1_coords, node2_coords):
    x1, y1, z1 = node1_coords
    x2, y2, z2 = node2_coords
    
    # Check if z coordinates are the same (horizontal)
    if abs(z1 - z2) < 1e-6:
        return 'beam'
    # Check if x and y coordinates are the same (vertical)
    elif abs(x1 - x2) < 1e-6 and abs(y1 - y2) < 1e-6:
        return 'column'
    # Otherwise it's a brace (diagonal)
    else:
        return 'brace'

# Function to calculate element length
def calculate_length(node1_coords, node2_coords):
    x1, y1, z1 = node1_coords
    x2, y2, z2 = node2_coords
    return np.sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)

# Process elements
beam_data = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1_coords = node_df[node_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].values[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].values[0]
    
    # Classify element
    element_type = classify_element(node1_coords, node2_coords)
    
    # If it's a beam, calculate length and check if shorter than 1.3m
    if element_type == 'beam':
        length = calculate_length(node1_coords, node2_coords)
        if length < 1.3:
            beam_data.append({'Element Number': element_id, 'Length': round(length, 4)})

# Create DataFrame and sort by element number
result_df = pd.DataFrame(beam_data)
result_df = result_df.sort_values('Element Number').reset_index(drop=True)

# Save to CSV
result_df.to_csv('Task_19_out.csv', index=False)