import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Filter for office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get all nodes that define office load areas
office_nodes = set()
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.update(nodes)

# Find columns supporting office loads
# Columns are vertical elements (only z-coordinate changes)
# They support loads from BELOW the floor, so we need columns that have one node
# at the office load nodes and extend downward

supporting_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical - only z changes)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if column supports office load area
        # Column supports from below, so the upper node should be in office_nodes
        upper_node_id = node1_id if node1['Z (m)'] > node2['Z (m)'] else node2_id
        
        if upper_node_id in office_nodes:
            supporting_columns.append(element['Element ID'])

# Create output dataframe
result_df = pd.DataFrame({'Element ID': sorted(supporting_columns)})

# Save to CSV
result_df.to_csv('Task_6_out.csv', index=False)