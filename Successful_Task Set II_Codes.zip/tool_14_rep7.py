import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the maximum z-coordinate (roof level)
max_z = node_df['Z (m)'].max()

# Get nodes at roof level
roof_nodes = node_df[node_df['Z (m)'] == max_z]['Node ID'].tolist()

# Find beams (horizontal elements with no change in z-coordinate)
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in z-coordinate)
    if node1_z == node2_z:
        beams.append(element['Element ID'])

# Find roof beams (beams at roof level)
roof_beams = []
for beam_id in beams:
    element_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = element_row['Node 1']
    node2_id = element_row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    
    if node1_z == max_z:
        roof_beams.append(beam_id)

# Get material information for roof beams
result_data = []
for beam_id in roof_beams:
    element_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    material_id = element_row['Material']
    material_name = material_df[material_df['Material Number'] == material_id]['Name'].iloc[0]
    
    result_data.append({
        'Element ID': beam_id,
        'Material Name': material_name
    })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_14_out.csv', index=False)

print("Roof beams information saved to Task_14_out.csv")
print(result_df)