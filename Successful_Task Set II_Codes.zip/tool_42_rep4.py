import pandas as pd
import os

# Create output folder
os.makedirs('Task_42_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check coordinate changes
    x_change = node1['X (m)'] != node2['X (m)']
    y_change = node1['Y (m)'] != node2['Y (m)']
    z_change = node1['Z (m)'] != node2['Z (m)']
    
    if z_change and not (x_change or y_change):
        return 'column'
    elif not z_change:
        return 'beam'
    elif (x_change or y_change) and z_change:
        return 'brace'
    
    return 'unknown'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find roof beams (beams where both nodes are at roof elevation)
roof_beams = []
for idx, row in element_df.iterrows():
    if row['element_type'] == 'beam':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
        node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
        
        if node1_z == roof_elevation and node2_z == roof_elevation:
            roof_beams.append(row['Element ID'])

# Find all braces
braces = element_df[element_df['element_type'] == 'brace']['Element ID'].tolist()

# Find nodes connected to braces
brace_nodes = set()
for brace_id in braces:
    brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
    brace_nodes.add(brace_row['Node 1'])
    brace_nodes.add(brace_row['Node 2'])

# Find roof beams not connected to any braces
roof_beams_no_braces = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_node1 = beam_row['Node 1']
    beam_node2 = beam_row['Node 2']
    
    # Check if neither node is connected to a brace
    if beam_node1 not in brace_nodes and beam_node2 not in brace_nodes:
        roof_beams_no_braces.append(beam_id)

# Update section to 104 for roof beams not connected to braces
element_df.loc[element_df['Element ID'].isin(roof_beams_no_braces), 'Section'] = 104

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Save updated Element.csv
element_df.to_csv('Task_42_out/Element.csv', index=False)

print(f"Updated {len(roof_beams_no_braces)} roof beams not connected to braces with section 104")
print(f"Roof beam IDs updated: {roof_beams_no_braces}")