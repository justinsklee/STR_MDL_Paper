import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_42_out', exist_ok=True)

# Find the roof level (highest z-coordinate)
roof_level = node_df['Z (m)'].max()

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check coordinate changes
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    # Classify based on coordinate changes
    if dz > 0 and (dx > 0 or dy > 0):  # Change in z AND (x or y)
        return 'brace'
    elif dz > 0 and dx == 0 and dy == 0:  # Change in z only
        return 'column'
    elif dz == 0:  # No change in z
        return 'beam'
    else:
        return 'unknown'

# Add classification to elements
element_df['classification'] = element_df.apply(classify_element, axis=1)

# Find beams on the roof level
roof_beams = []
for idx, row in element_df.iterrows():
    if row['classification'] == 'beam':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if both nodes are at roof level
        if node1['Z (m)'] == roof_level and node2['Z (m)'] == roof_level:
            roof_beams.append(row['Element ID'])

# Find all braces
braces = element_df[element_df['classification'] == 'brace']['Element ID'].tolist()

# Find nodes connected to braces
brace_nodes = set()
for brace_id in braces:
    brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
    brace_nodes.add(brace_row['Node 1'])
    brace_nodes.add(brace_row['Node 2'])

# Find roof beams not connected to any braces
roof_beams_no_braces = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_node1 = beam_row['Node 1']
    beam_node2 = beam_row['Node 2']
    
    # Check if beam nodes are not connected to any braces
    if beam_node1 not in brace_nodes and beam_node2 not in brace_nodes:
        roof_beams_no_braces.append(beam_id)

# Update section for roof beams not connected to braces
for beam_id in roof_beams_no_braces:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 104

# Remove the classification column before saving
element_df = element_df.drop('classification', axis=1)

# Save updated Element.csv file
element_df.to_csv('Task_42_out/Element.csv', index=False)

print(f"Updated {len(roof_beams_no_braces)} roof beams with section 104")
print(f"Roof beams updated: {roof_beams_no_braces}")