import pandas as pd
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Find all beams (elements with no change in z-coordinates between nodes)
beams = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in z-coordinate)
    if node1_z == node2_z:
        beams.append({
            'Element ID': row['Element ID'],
            'Node 1': node1_id,
            'Node 2': node2_id,
            'Z': node1_z
        })

# Find beams on the roof
roof_beams = [beam for beam in beams if beam['Z'] == roof_elevation]

# Find columns (elements with change only in z-coordinates)
columns = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (change only in z-coordinate)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Find nodes that are connected to columns on the roof
column_nodes_on_roof = set()
for idx, row in element_df.iterrows():
    if row['Element ID'] in columns:
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
        node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
        
        # Add the node that's on the roof elevation
        if node1_z == roof_elevation:
            column_nodes_on_roof.add(node1_id)
        if node2_z == roof_elevation:
            column_nodes_on_roof.add(node2_id)

# Find sub-beams (roof beams not directly connected to columns)
sub_beam_ids = []
for beam in roof_beams:
    # Check if both nodes of the beam are NOT connected to columns
    if (beam['Node 1'] not in column_nodes_on_roof and 
        beam['Node 2'] not in column_nodes_on_roof):
        sub_beam_ids.append(beam['Element ID'])

# Update section for sub-beams on roof
for idx, row in element_df.iterrows():
    if row['Element ID'] in sub_beam_ids:
        element_df.at[idx, 'Section'] = 104

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_22_out/Element.csv', index=False)