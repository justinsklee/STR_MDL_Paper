import pandas as pd
import numpy as np

# Load all relevant CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
sections_df = pd.read_csv('Long_Section.csv')
materials_df = pd.read_csv('Material.csv')

# Get unique floor elevations (z-coordinates) and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Second floor is at index 1 (0-indexed: ground=0, second=1)
second_floor_elevation = floor_elevations[1]

# Get unique y-coordinates to identify Y grids
y_coordinates = sorted(nodes_df['Y (m)'].unique())
y1_coordinate = y_coordinates[0]  # First Y grid (Y-1)

# Find nodes on second floor and Y-1 grid
second_floor_nodes = nodes_df[nodes_df['Z (m)'] == second_floor_elevation]['Node ID'].tolist()
y1_grid_nodes = nodes_df[nodes_df['Y (m)'] == y1_coordinate]['Node ID'].tolist()

# Find nodes that are both on second floor and Y-1 grid
second_floor_y1_nodes = list(set(second_floor_nodes) & set(y1_grid_nodes))

# Find columns on second floor along Y-1 grid
# Columns are vertical elements (only z-coordinate changes between nodes)
columns_on_second_floor_y1 = []

for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates of both nodes
    node1_coords = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2_coords = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a column (vertical: only z changes, x and y stay same)
    is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                 node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                 node1_coords['Z (m)'] != node2_coords['Z (m)'])
    
    if is_column:
        # Check if one node is on second floor and the other is above
        node1_on_second_floor = node1_id in second_floor_y1_nodes
        node2_on_second_floor = node2_id in second_floor_y1_nodes
        
        # For columns on second floor, one node should be on second floor and other above
        if (node1_on_second_floor and node2_coords['Z (m)'] > second_floor_elevation) or \
           (node2_on_second_floor and node1_coords['Z (m)'] > second_floor_elevation):
            # Check if both nodes are on Y-1 grid
            node1_on_y1 = node1_coords['Y (m)'] == y1_coordinate
            node2_on_y1 = node2_coords['Y (m)'] == y1_coordinate
            
            if node1_on_y1 and node2_on_y1:
                columns_on_second_floor_y1.append(element)

# Create result dataframe
result_data = []
for element in columns_on_second_floor_y1:
    element_id = element['Element ID']
    section_num = element['Section']
    material_num = element['Material']
    
    # Get section name
    section_info = sections_df[sections_df['Section Number'] == section_num]
    section_name = section_info['Section Name'].iloc[0] if not section_info.empty else 'Unknown'
    
    # Get material name
    material_info = materials_df[materials_df['Material Number'] == material_num]
    material_name = material_info['Name'].iloc[0] if not material_info.empty else 'Unknown'
    
    result_data.append({
        'Element ID': element_id,
        'Section Name': section_name,
        'Material Name': material_name
    })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_45_out.csv', index=False)

print("Results saved to Task_45_out.csv")
print(result_df)