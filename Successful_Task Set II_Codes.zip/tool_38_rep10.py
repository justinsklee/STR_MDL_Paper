import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_38_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
materials_df = pd.read_csv('Material.csv')

# Find the material number for SHN355
shn355_material = materials_df[materials_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Find unique X coordinates to identify grids
unique_x = sorted(nodes_df['X (m)'].unique())

# Grid X-2 corresponds to the second X coordinate
x2_coord = unique_x[1]  # X-2 grid coordinate

# Find first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find nodes on first floor at grid X-2
first_floor_x2_nodes = nodes_df[
    (nodes_df['X (m)'] == x2_coord) & 
    (nodes_df['Z (m)'] == first_floor_z)
]['Node ID'].tolist()

# Find columns: elements where one node is on first floor at X-2 and the other node is above
columns_to_update = []

for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1_coords = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2_coords = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a column (vertical element)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        
        # Check if column is at grid X-2 and has one node on first floor
        if (node1_coords['X (m)'] == x2_coord and 
            ((node1_coords['Z (m)'] == first_floor_z and node2_coords['Z (m)'] > first_floor_z) or
             (node2_coords['Z (m)'] == first_floor_z and node1_coords['Z (m)'] > first_floor_z))):
            columns_to_update.append(element['Element ID'])

# Update material for identified columns
elements_df.loc[elements_df['Element ID'].isin(columns_to_update), 'Material'] = shn355_material

# Save updated Element.csv file
elements_df.to_csv('Task_38_out/Element.csv', index=False)

print(f"Updated {len(columns_to_update)} first floor columns along grid X-2 to use SHN355 material.")
print(f"Column IDs updated: {columns_to_update}")