import pandas as pd
import numpy as np
import os

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
materials_df = pd.read_csv('Material.csv')

# Create output folder
os.makedirs('Task_38_out', exist_ok=True)

# Find unique X coordinates to identify grid lines
unique_x = sorted(nodes_df['X (m)'].unique())

# X-2 grid is the second X coordinate (index 1)
x2_coord = unique_x[1]

# Find first floor elevation (minimum Z coordinate)
first_floor_z = nodes_df['Z (m)'].min()

# Find second floor elevation (next unique Z coordinate above first floor)
unique_z = sorted(nodes_df['Z (m)'].unique())
second_floor_z = unique_z[1]

# Find SHN355 material number
shn355_material = materials_df[materials_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Find first floor columns along grid X-2
# Columns are vertical elements with one node at first floor and another above
first_floor_nodes_x2 = nodes_df[(nodes_df['X (m)'] == x2_coord) & (nodes_df['Z (m)'] == first_floor_z)]['Node ID'].tolist()
second_floor_nodes_x2 = nodes_df[(nodes_df['X (m)'] == x2_coord) & (nodes_df['Z (m)'] == second_floor_z)]['Node ID'].tolist()

# Find elements that connect first floor nodes to second floor nodes at X-2 grid
columns_to_update = []
for _, element in elements_df.iterrows():
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Check if this is a column connecting first floor to second floor at X-2 grid
    if ((node1 in first_floor_nodes_x2 and node2 in second_floor_nodes_x2) or 
        (node2 in first_floor_nodes_x2 and node1 in second_floor_nodes_x2)):
        columns_to_update.append(element['Element ID'])

# Update material for identified columns
elements_df.loc[elements_df['Element ID'].isin(columns_to_update), 'Material'] = shn355_material

# Save updated Element.csv
elements_df.to_csv('Task_38_out/Element.csv', index=False)