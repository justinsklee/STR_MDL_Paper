import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_32_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Identify third floor elevation (index 2 since we start from 0)
if len(floor_elevations) >= 3:
    third_floor_z = floor_elevations[2]
    
    # Find nodes on third floor and above
    third_floor_nodes = node_df[node_df['Z (m)'] == third_floor_z]['Node ID'].tolist()
    above_third_floor_nodes = node_df[node_df['Z (m)'] > third_floor_z]['Node ID'].tolist()
    
    # Identify braces connected to third floor
    # Braces have one node on third floor and another node above third floor
    third_floor_braces = []
    
    for idx, row in element_df.iterrows():
        node1 = row['Node 1']
        node2 = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
        
        # Check if element is a brace (changes in x/y AND z coordinates)
        x_change = node1_coords['X (m)'] != node2_coords['X (m)']
        y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        
        is_brace = (x_change or y_change) and z_change
        
        # Check if brace is connected to third floor
        if is_brace:
            node1_on_third = node1 in third_floor_nodes
            node2_above_third = node2 in above_third_floor_nodes
            node2_on_third = node2 in third_floor_nodes
            node1_above_third = node1 in above_third_floor_nodes
            
            if (node1_on_third and node2_above_third) or (node2_on_third and node1_above_third):
                third_floor_braces.append(row['Element ID'])
    
    # Update section for third floor braces to 102
    for brace_id in third_floor_braces:
        element_df.loc[element_df['Element ID'] == brace_id, 'Section'] = 102

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_32_out/Element.csv', index=False)