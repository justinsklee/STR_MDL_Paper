import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_44_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the top floor elevation
max_z = node_df['Z (m)'].max()

# Get beams on the top floor
# Beams are horizontal elements (no change in z coordinates between nodes)
beams_mask = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (horizontal element) and on top floor
    is_beam = (node1_z == node2_z)
    is_top_floor = (node1_z == max_z)
    
    beams_mask.append(is_beam and is_top_floor)

# Filter top floor beams
top_floor_beams = element_df[beams_mask].copy()

# Calculate beam lengths
for idx in top_floor_beams.index:
    node1_id = element_df.loc[idx, 'Node 1']
    node2_id = element_df.loc[idx, 'Node 2']
    
    node1_coords = node_df[node_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    
    length = np.sqrt((node1_coords['X (m)'] - node2_coords['X (m)'])**2 + 
                     (node1_coords['Y (m)'] - node2_coords['Y (m)'])**2 + 
                     (node1_coords['Z (m)'] - node2_coords['Z (m)'])**2)
    
    # Update section number to 105 if length > 1.65m
    if length > 1.65:
        element_df.loc[idx, 'Section'] = 105

# Save updated Element.csv
element_df.to_csv('Task_44_out/Element.csv', index=False)