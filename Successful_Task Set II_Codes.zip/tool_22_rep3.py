import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
roof_elevation = floor_elevations[-1]  # Highest elevation is the roof

# Find all beams on the roof (same z-coordinate for both nodes)
roof_beams = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in z-coordinate) and on roof level
    if (node1['Z (m)'] == node2['Z (m)'] == roof_elevation):
        roof_beams.append(row['Element ID'])

# Find columns (vertical elements connecting to roof)
roof_columns = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (change only in z-coordinate) with one node on roof
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        # Check if one node is on roof level
        if node1['Z (m)'] == roof_elevation or node2['Z (m)'] == roof_elevation:
            roof_columns.append(row['Element ID'])

# Find nodes that are connected to columns on the roof
column_connected_nodes = set()
for col_id in roof_columns:
    col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
    node1_id = col_row['Node 1']
    node2_id = col_row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Add the roof-level node to the set
    if node1['Z (m)'] == roof_elevation:
        column_connected_nodes.add(node1_id)
    if node2['Z (m)'] == roof_elevation:
        column_connected_nodes.add(node2_id)

# Find sub-beams on roof (beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_row['Node 1']
    node2_id = beam_row['Node 2']
    
    # Check if neither node is connected to a column
    if node1_id not in column_connected_nodes and node2_id not in column_connected_nodes:
        roof_sub_beams.append(beam_id)

# Update section for roof sub-beams to 104
for beam_id in roof_sub_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 104

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_22_out/Element.csv', index=False)