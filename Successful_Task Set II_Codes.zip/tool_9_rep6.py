import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Merge element data with node coordinates to get start and end coordinates
element_with_coords = element_df.merge(
    node_df.rename(columns={'Node ID': 'Node 1', 'X (m)': 'X1', 'Y (m)': 'Y1', 'Z (m)': 'Z1'}),
    on='Node 1'
).merge(
    node_df.rename(columns={'Node ID': 'Node 2', 'X (m)': 'X2', 'Y (m)': 'Y2', 'Z (m)': 'Z2'}),
    on='Node 2'
)

# Classify elements as braces (diagonal elements: change in x/y AND z coordinates)
element_with_coords['is_brace'] = (
    (element_with_coords['X1'] != element_with_coords['X2']) | 
    (element_with_coords['Y1'] != element_with_coords['Y2'])
) & (element_with_coords['Z1'] != element_with_coords['Z2'])

# Get brace element IDs
brace_elements = element_with_coords[element_with_coords['is_brace']]['Element ID'].tolist()

# Get beam-end-released element IDs
beam_end_released_elements = beam_end_release_df['Element ID'].tolist()

# Find braces that are NOT beam-end-released
braces_not_released = [elem for elem in brace_elements if elem not in beam_end_released_elements]

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(braces_not_released)})

# Save to CSV
output_df.to_csv('Task_9_out.csv', index=False)