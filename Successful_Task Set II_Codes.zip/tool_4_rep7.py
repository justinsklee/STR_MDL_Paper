import pandas as pd

# Load the CSV files
element_df = pd.read_csv('Element.csv')
section_df = pd.read_csv('Long_Section.csv')
node_df = pd.read_csv('Node.csv')

# Find section number for H 175x175x7.5/11
target_section = section_df[section_df['Section Name'] == 'H 175x175x7.5/11']['Section Number'].iloc[0]

# Get elements with the target section
elements_with_section = element_df[element_df['Section'] == target_section]

# Filter for columns (vertical elements - change only in z coordinate)
columns = []
for _, element in elements_with_section.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if element is vertical (column): change in z only, no change in x and y
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Create output dataframe
output_df = pd.DataFrame({'Element ID': sorted(columns)})

# Save to CSV
output_df.to_csv('Task_4_out.csv', index=False)