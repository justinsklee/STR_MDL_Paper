import pandas as pd
import numpy as np

# Load relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get the highest z-coordinate (roof level)
roof_level = node_df['Z (m)'].max()

# Filter elements with section 101
section_101_elements = element_df[element_df['Section'] == 101]

# Filter for beams (horizontal elements) at roof level
roof_beams_101 = []

for _, element in section_101_elements.iterrows():
    node1 = node_df[node_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if it's a beam (no change in z-coordinate) and at roof level
    if node1['Z (m)'] == node2['Z (m)'] == roof_level:
        roof_beams_101.append(element)

# Convert to DataFrame
roof_beams_101_df = pd.DataFrame(roof_beams_101)

# Get section properties for section 101
section_101 = section_df[section_df['Section Number'] == 101].iloc[0]
area = section_101['Area']  # m²

# Calculate total weight
total_weight = 0
density = 7850  # kg/m³

for _, beam in roof_beams_101_df.iterrows():
    node1 = node_df[node_df['Node ID'] == beam['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == beam['Node 2']].iloc[0]
    
    # Calculate length
    length = np.sqrt((node2['X (m)'] - node1['X (m)'])**2 + 
                    (node2['Y (m)'] - node1['Y (m)'])**2 + 
                    (node2['Z (m)'] - node1['Z (m)'])**2)
    
    # Calculate weight
    weight = area * length * density
    total_weight += weight

# Round up to nearest 10 kg
total_weight_rounded = np.ceil(total_weight / 10) * 10

# Create output DataFrame
result_df = pd.DataFrame({
    'Total Weight of Roof Beams with Section 101 (kg)': [total_weight_rounded]
})

# Save to CSV
result_df.to_csv('Task_41_out.csv', index=False)