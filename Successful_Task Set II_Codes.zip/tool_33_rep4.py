import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_33_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Find X-3 grid coordinate (third unique X coordinate)
unique_x_coords = sorted(nodes_df['X (m)'].unique())
x3_coord = unique_x_coords[2]  # X-3 is the third X coordinate

# Find braces along grid X-3
braces_on_x3 = []

for _, element in elements_df.iterrows():
    element_id = element['Element ID']
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get node coordinates
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if both nodes are on X-3 grid
    if abs(node1['X (m)'] - x3_coord) < 1e-6 and abs(node2['X (m)'] - x3_coord) < 1e-6:
        # Check if it's a brace (diagonal element)
        x_change = abs(node2['X (m)'] - node1['X (m)'])
        y_change = abs(node2['Y (m)'] - node1['Y (m)'])
        z_change = abs(node2['Z (m)'] - node1['Z (m)'])
        
        # Brace: change in (x or y) AND z coordinates
        if z_change > 1e-6 and (x_change > 1e-6 or y_change > 1e-6):
            braces_on_x3.append(element_id)

# Remove beam-end-release for braces along grid X-3
updated_beam_end_release_df = beam_end_release_df[~beam_end_release_df['Element ID'].isin(braces_on_x3)].copy()

# Sort by Element ID in ascending order
updated_beam_end_release_df = updated_beam_end_release_df.sort_values('Element ID').reset_index(drop=True)

# Save updated file
updated_beam_end_release_df.to_csv('Task_33_out/Beam_end_release.csv', index=False)