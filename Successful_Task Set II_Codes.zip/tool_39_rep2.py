import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_39_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Identify first floor elevation (ground level)
first_floor_z = 0.0

# Identify second floor elevation (one story above ground)
second_floor_z = node_df[node_df['Z (m)'] > first_floor_z]['Z (m)'].min()

# Find X-1 grid coordinate (first X grid line)
x1_coord = node_df['X (m)'].min()

# Identify braces on first floor along grid X-1
braces_to_remove = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates of both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal: change in x/y AND z coordinates)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if both nodes are on grid X-1
        on_x1_grid = (abs(node1['X (m)'] - x1_coord) < 1e-6 and 
                      abs(node2['X (m)'] - x1_coord) < 1e-6)
        
        # Check if brace is on first floor (one node at first floor, other above)
        node1_first_floor = abs(node1['Z (m)'] - first_floor_z) < 1e-6
        node2_first_floor = abs(node2['Z (m)'] - first_floor_z) < 1e-6
        node1_above_first = node1['Z (m)'] > first_floor_z
        node2_above_first = node2['Z (m)'] > first_floor_z
        
        first_floor_brace = ((node1_first_floor and node2_above_first) or 
                            (node2_first_floor and node1_above_first))
        
        if on_x1_grid and first_floor_brace:
            braces_to_remove.append(row['Element ID'])

# Remove identified braces
updated_element_df = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_39_out/Element.csv', index=False)

print(f"Removed {len(braces_to_remove)} braces on first floor along grid X-1")
if braces_to_remove:
    print(f"Removed element IDs: {braces_to_remove}")