import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_23_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
sections_df = pd.read_csv('Long_Section.csv')

# Find ground level (first floor)
ground_level = nodes_df['Z (m)'].min()

# Find second floor level
unique_z = sorted(nodes_df['Z (m)'].unique())
second_floor_level = unique_z[1] if len(unique_z) > 1 else ground_level + 1

# Identify first floor braces
# Braces have one node at first floor and another node above first floor
# AND they have changes in both (x,y) and z coordinates

first_floor_braces = []

for idx, row in elements_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get node coordinates
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if it's a brace (changes in x,y AND z coordinates)
    has_xy_change = (x1 != x2) or (y1 != y2)
    has_z_change = z1 != z2
    
    if has_xy_change and has_z_change:
        # Check if one node is at ground level and other is above
        if ((z1 == ground_level and z2 > ground_level) or 
            (z2 == ground_level and z1 > ground_level)):
            first_floor_braces.append(row['Element ID'])

# Find section number for H 100x100x6/8
target_section = sections_df[sections_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Update section for first floor braces
for element_id in first_floor_braces:
    elements_df.loc[elements_df['Element ID'] == element_id, 'Section'] = target_section

# Save updated Element.csv
elements_df.to_csv('Task_23_out/Element.csv', index=False)

print(f"Updated {len(first_floor_braces)} first floor braces with section H 100x100x6/8")
print(f"First floor brace elements: {first_floor_braces}")