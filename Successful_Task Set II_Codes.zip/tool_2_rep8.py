import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get the maximum Z coordinate to identify the roof level
max_z = node_df['Z (m)'].max()

# Identify columns (vertical elements with only Z coordinate change)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams at roof level (horizontal elements with Z = max_z)
roof_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is horizontal at roof level
    if (node1['Z (m)'] == node2['Z (m)'] and 
        node1['Z (m)'] == max_z):
        roof_beams.append(element['Element ID'])

# Find nodes that are connected to columns
column_nodes = set()
for _, element in element_df.iterrows():
    if element['Element ID'] in columns:
        column_nodes.add(element['Node 1'])
        column_nodes.add(element['Node 2'])

# Identify roof sub-beams (roof beams not directly connected to columns)
roof_sub_beams = []
for _, element in element_df.iterrows():
    if element['Element ID'] in roof_beams:
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Check if neither node is connected to a column
        if node1_id not in column_nodes and node2_id not in column_nodes:
            roof_sub_beams.append(element['Element ID'])

# Sort element IDs in ascending order
roof_sub_beams.sort()

# Create output DataFrame
output_df = pd.DataFrame({'Element ID': roof_sub_beams})

# Save to CSV file
output_df.to_csv('Task_2_out.csv', index=False)