import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Merge element data with node coordinates for both nodes
element_with_nodes = element_df.merge(node_df, left_on='Node 1', right_on='Node ID', suffixes=('', '_node1'))
element_with_nodes = element_with_nodes.merge(node_df, left_on='Node 2', right_on='Node ID', suffixes=('', '_node2'))

# Classify elements as braces (diagonal elements: change in x/y AND z coordinates)
element_with_nodes['is_brace'] = (
    (element_with_nodes['X (m)'] != element_with_nodes['X (m)_node2']) | 
    (element_with_nodes['Y (m)'] != element_with_nodes['Y (m)_node2'])
) & (element_with_nodes['Z (m)'] != element_with_nodes['Z (m)_node2'])

# Get brace element IDs
brace_elements = element_with_nodes[element_with_nodes['is_brace']]['Element ID'].tolist()

# Get beam-end-released element IDs
beam_end_released_elements = beam_end_release_df['Element ID'].tolist()

# Find braces that are NOT beam-end-released
braces_not_released = [elem for elem in brace_elements if elem not in beam_end_released_elements]

# Sort in ascending order
braces_not_released.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': braces_not_released})

# Save to CSV
output_df.to_csv('Task_9_out.csv', index=False)

print("Braces not beam-end-released:")
print(output_df)