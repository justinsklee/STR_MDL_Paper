import pandas as pd
import os

# Create output folder
output_folder = 'Task_26_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the material number for SHN355
shn355_material = material_df[material_df['Name'] == 'SHN355']['Material Number'].iloc[0]

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation (index 1)
second_floor_elevation = floor_elevations[1]

# Identify beams: elements with no change in Z coordinates
beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in Z coordinate)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Find second floor beams (beams at second floor elevation)
second_floor_beams = []
for beam_id in beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = element['Node 1']
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    
    if node1['Z (m)'] == second_floor_elevation:
        second_floor_beams.append(beam_id)

# Update material for second floor beams
for beam_id in second_floor_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Material'] = shn355_material

# Save updated Element.csv file
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)