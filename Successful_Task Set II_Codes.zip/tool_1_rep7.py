import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (ground level)
first_floor_z = 0.0

# Find all unique z-coordinates and sort them to identify floor levels
z_coords = sorted(node_df['Z (m)'].unique())
first_floor_z = z_coords[0]  # Ground level
second_floor_z = z_coords[1] if len(z_coords) > 1 else None

# Find first floor columns
# Columns are vertical elements with one node at first floor and another node above first floor
first_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    # Column: same x,y coordinates but different z coordinates
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is at first floor and other is above
        node_z_values = sorted([node1['Z (m)'], node2['Z (m)']])
        if node_z_values[0] == first_floor_z and node_z_values[1] > first_floor_z:
            first_floor_columns.append(element['Element ID'])

# Sort element IDs in ascending order
first_floor_columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': first_floor_columns})

# Save to CSV
output_df.to_csv('Task_1_out.csv', index=False)