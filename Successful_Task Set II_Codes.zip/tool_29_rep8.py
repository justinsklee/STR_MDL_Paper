import pandas as pd
import os

# Create output folder
os.makedirs('Task_29_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof level (highest z-coordinate)
roof_level = node_df['Z (m)'].max()

# Find all beams (elements with no change in z-coordinates between nodes)
beams = []
for idx, row in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == row['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == row['Node 2']]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in z-coordinates)
    if node1_z == node2_z:
        beams.append({
            'Element ID': row['Element ID'],
            'Node 1': row['Node 1'],
            'Node 2': row['Node 2'],
            'Z': node1_z
        })

# Find columns (vertical elements)
columns = []
for idx, row in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == row['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == row['Node 2']].iloc[0]
    
    # Check if it's a column (change only in z-coordinates)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append({
            'Element ID': row['Element ID'],
            'Node 1': row['Node 1'],
            'Node 2': row['Node 2']
        })

# Find beams on roof level
roof_beams = [beam for beam in beams if beam['Z'] == roof_level]

# Find which roof beams are connected to columns (main beams)
main_beam_ids = set()
for beam in roof_beams:
    for column in columns:
        if beam['Node 1'] == column['Node 1'] or beam['Node 1'] == column['Node 2'] or \
           beam['Node 2'] == column['Node 1'] or beam['Node 2'] == column['Node 2']:
            main_beam_ids.add(beam['Element ID'])

# Find sub-beams on roof (beams not connected to columns)
sub_beam_ids = []
for beam in roof_beams:
    if beam['Element ID'] not in main_beam_ids:
        sub_beam_ids.append(beam['Element ID'])

# Remove sub-beams from element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(sub_beam_ids)]

# Sort by Element ID
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_29_out/Element.csv', index=False)

print(f"Removed {len(sub_beam_ids)} sub-beams from roof level")
print(f"Sub-beam IDs removed: {sub_beam_ids}")