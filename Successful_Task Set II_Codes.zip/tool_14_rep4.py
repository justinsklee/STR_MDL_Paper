import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
material_df = pd.read_csv('Material.csv')
node_df = pd.read_csv('Node.csv')

# Find the maximum Z coordinate (roof level)
max_z = node_df['Z (m)'].max()

# Get nodes at roof level
roof_nodes = node_df[node_df['Z (m)'] == max_z]['Node ID'].tolist()

# Find beams at roof level (both nodes have same Z coordinate and both are at max Z)
roof_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get Z coordinates for both nodes
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (same Z coordinate) and at roof level
    if node1_z == node2_z and node1_z == max_z:
        roof_beams.append(element)

# Create result dataframe
result_data = []
for beam in roof_beams:
    element_id = beam['Element ID']
    material_num = beam['Material']
    material_name = material_df[material_df['Material Number'] == material_num]['Name'].iloc[0]
    
    result_data.append({
        'Element ID': element_id,
        'Material Name': material_name
    })

# Create dataframe and sort by Element ID
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_14_out.csv', index=False)

print("Roof beams information:")
print(result_df)