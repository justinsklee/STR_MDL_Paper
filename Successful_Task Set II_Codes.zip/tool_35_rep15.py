import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')

# Create output folder
os.makedirs('Task_35_out', exist_ok=True)

# Find residential load areas
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that are part of residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    residential_nodes.update(nodes)

# Find columns that support residential loads (columns with one end at residential load nodes and other end below)
columns_to_update = []

for _, element in element_df.iterrows():
    element_id = element['Element ID']
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # Get node coordinates
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if element is a column (vertical - only z coordinate changes)
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        
        # Check if one node is in residential load area and the other is below it
        node1_z = node1_coords['Z (m)']
        node2_z = node2_coords['Z (m)']
        
        # Determine which node is higher
        if node1_z > node2_z:
            upper_node = node1
            lower_node = node2
        else:
            upper_node = node2
            lower_node = node1
            
        # Check if upper node is in residential load area (column supports from below)
        if upper_node in residential_nodes:
            columns_to_update.append(element_id)

# Update material for columns supporting residential loads
# Material 1003 is SHN355
for element_id in columns_to_update:
    element_df.loc[element_df['Element ID'] == element_id, 'Material'] = 1003

# Save updated Element.csv
element_df.to_csv('Task_35_out/Element.csv', index=False)