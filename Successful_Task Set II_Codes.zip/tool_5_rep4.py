import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Filter residential loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Find beams supporting residential loads
supporting_beam_ids = []

for _, load in residential_loads.iterrows():
    # Parse nodes from the loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # Create beam pairs for the 4-node loading area
    beam_pairs = []
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]  # Connect to next node, wrapping around
        beam_pairs.append((min(node1, node2), max(node1, node2)))
    
    # Find elements that match these beam pairs
    for pair in beam_pairs:
        node1, node2 = pair
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            # Check if it's a beam (horizontal element - no change in z coordinates)
            n1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
            n2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
            
            if n1_z == n2_z:  # Beam condition
                supporting_beam_ids.append(element['Element ID'])

# Remove duplicates and sort
supporting_beam_ids = sorted(list(set(supporting_beam_ids)))

# Create output dataframe
output_df = pd.DataFrame({
    'Element ID': supporting_beam_ids
})

# Save to CSV
output_df.to_csv('Task_5_out.csv', index=False)

print(f"Found {len(supporting_beam_ids)} beams supporting residential loads")
print(output_df)