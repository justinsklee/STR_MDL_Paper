import pandas as pd
import os

# Create output folder
os.makedirs('Task_27_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify columns (vertical elements with only z-coordinate change)
columns = []
for _, elem in element_df.iterrows():
    node1_id, node2_id = elem['Node 1'], elem['Node 2']
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(elem['Element ID'])

# Identify beams (horizontal elements with no z-coordinate change)
beams = []
for _, elem in element_df.iterrows():
    node1_id, node2_id = elem['Node 1'], elem['Node 2']
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(elem['Element ID'])

# Find nodes that are connected to columns
column_nodes = set()
for _, elem in element_df.iterrows():
    if elem['Element ID'] in columns:
        column_nodes.add(elem['Node 1'])
        column_nodes.add(elem['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    beam_elem = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id, node2_id = beam_elem['Node 1'], beam_elem['Node 2']
    
    # Check if both nodes of the beam are NOT connected to columns
    if node1_id not in column_nodes and node2_id not in column_nodes:
        sub_beams.append(beam_id)

# Add beam-end-release entries for sub-beams
for sub_beam_id in sub_beams:
    # Check if already exists in beam_end_release_df
    if sub_beam_id not in beam_end_release_df['Element ID'].values:
        new_row = {
            'Element ID': sub_beam_id,
            'Type': 'Relative',
            'i-end release': '11',
            'Fxi': 0,
            'Fyi': 0,
            'Fzi': 0,
            'Mxi': 0,
            'Myi': 0,
            'Mzi': 0,
            'j-end release': '11',
            'Fxj': 0,
            'Fyj': 0,
            'Fzj': 0,
            'Mxj': 0,
            'Myj': 0,
            'Mzj': 0,
            'Group': 'Default'
        }
        beam_end_release_df = pd.concat([beam_end_release_df, pd.DataFrame([new_row])], ignore_index=True)

# Sort by Element ID in ascending order
beam_end_release_df = beam_end_release_df.sort_values('Element ID').reset_index(drop=True)

# Save updated beam_end_release.csv
beam_end_release_df.to_csv('Task_27_out/Beam_end_release.csv', index=False)

print("Updated Beam_end_release.csv saved in Task_27_out folder")
print(f"Sub-beams identified and assigned beam-end-release: {sub_beams}")