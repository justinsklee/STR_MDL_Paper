import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get all nodes that define office load areas
office_nodes = set()
for _, load in office_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    office_nodes.update(nodes)

# Find columns that support these nodes from below
supporting_columns = []

for node_id in office_nodes:
    # Get the z-coordinate of the node
    node_z = node_df[node_df['Node ID'] == node_id]['Z (m)'].iloc[0]
    
    # Find columns that have this node as their upper node (Node 2)
    # and the lower node (Node 1) is below this elevation
    for _, element in element_df.iterrows():
        if element['Node 2'] == node_id:
            # Check if this is a column (vertical element)
            node1_coords = node_df[node_df['Node ID'] == element['Node 1']][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
            node2_coords = node_df[node_df['Node ID'] == element['Node 2']][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
            
            # Check if it's a column (same x,y coordinates, different z)
            if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                node1_coords['Z (m)'] < node2_coords['Z (m)']):
                supporting_columns.append(element['Element ID'])

# Remove duplicates and sort
supporting_columns = sorted(list(set(supporting_columns)))

# Create output dataframe
output_df = pd.DataFrame({'Element ID': supporting_columns})

# Save to CSV
output_df.to_csv('Task_6_out.csv', index=False)