import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_47_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find Y-1 grid coordinate (first Y grid line)
y_coords = sorted(node_df['Y (m)'].unique())
y1_coord = y_coords[0]

# Find columns on first floor along grid Y-1 with section 101
first_floor_columns = []

for _, element in element_df.iterrows():
    if element['Section'] == 101:  # Section 101
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if it's a column (vertical element)
        if (node1['X (m)'] == node2['X (m)'] and 
            node1['Y (m)'] == node2['Y (m)'] and 
            node1['Z (m)'] != node2['Z (m)']):
            
            # Check if column is on Y-1 grid
            if node1['Y (m)'] == y1_coord and node2['Y (m)'] == y1_coord:
                
                # Check if one node is on first floor
                if node1['Z (m)'] == first_floor_z:
                    first_floor_columns.append(node1_id)
                elif node2['Z (m)'] == first_floor_z:
                    first_floor_columns.append(node2_id)

# Update support conditions to pin (release rotational constraints)
for node_id in first_floor_columns:
    if node_id in support_df['Node'].values:
        support_df.loc[support_df['Node'] == node_id, ['Rx', 'Ry', 'Rz']] = 0

# Save updated support file
support_df.to_csv('Task_47_out/Support.csv', index=False)

print(f"Updated support conditions for {len(first_floor_columns)} first floor columns along grid Y-1 with section 101")
print(f"Affected nodes: {first_floor_columns}")