import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is the second elevation (index 1)
second_floor_elevation = floor_elevations[1]

# Find bracing elements for second floor
# Braces have one node at the floor and another node above the floor
second_floor_braces = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if one node is at second floor and the other is above
    node1_at_second_floor = node1['Z (m)'] == second_floor_elevation
    node2_at_second_floor = node2['Z (m)'] == second_floor_elevation
    node1_above_second_floor = node1['Z (m)'] > second_floor_elevation
    node2_above_second_floor = node2['Z (m)'] > second_floor_elevation
    
    if (node1_at_second_floor and node2_above_second_floor) or (node2_at_second_floor and node1_above_second_floor):
        # Check if it's a brace (diagonal element)
        # Braces have changes in both horizontal (x or y) and vertical (z) coordinates
        dx = abs(node1['X (m)'] - node2['X (m)'])
        dy = abs(node1['Y (m)'] - node2['Y (m)'])
        dz = abs(node1['Z (m)'] - node2['Z (m)'])
        
        # Element is a brace if it has change in z AND change in (x or y)
        if dz > 0 and (dx > 0 or dy > 0):
            second_floor_braces.append({
                'Element ID': element['Element ID'],
                'Material': element['Material']
            })

# Create output dataframe
output_df = pd.DataFrame(second_floor_braces)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_15_out.csv', index=False)