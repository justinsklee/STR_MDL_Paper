import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find nodes at first floor level
first_floor_nodes = node_df[node_df['Z (m)'] == first_floor_z]['Node ID'].tolist()

# Find all columns (vertical elements - change only in z coordinate, no change in x,y)
columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column): same x,y coordinates but different z
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Find first floor columns: columns with one node at first floor and other node above
first_floor_columns = []
for col_id in columns:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if one node is at first floor and other is above
    if ((node1_z == first_floor_z and node2_z > first_floor_z) or 
        (node2_z == first_floor_z and node1_z > first_floor_z)):
        first_floor_columns.append(col_id)

# Sort element IDs in ascending order
first_floor_columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': first_floor_columns})

# Save to CSV
output_df.to_csv('Task_1_out.csv', index=False)

print(f"First floor columns found: {len(first_floor_columns)}")
print(output_df)