import pandas as pd

# Load relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get first floor elevation (z = 0.0)
first_floor_z = 0.0

# Find nodes at first floor level
first_floor_nodes = node_df[node_df['Z (m)'] == first_floor_z]['Node ID'].tolist()

# Find columns: elements where one node is at first floor and the other is above
# Columns are vertical elements (change only in z-coordinate)
first_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column): same x,y coordinates but different z
    if (node1_coords['X (m)'] == node2_coords['X (m)'] and 
        node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
        node1_coords['Z (m)'] != node2_coords['Z (m)']):
        
        # Check if one node is at first floor and the other is above
        if ((node1_id in first_floor_nodes and node2_coords['Z (m)'] > first_floor_z) or
            (node2_id in first_floor_nodes and node1_coords['Z (m)'] > first_floor_z)):
            first_floor_columns.append(element['Element ID'])

# Sort element IDs in ascending order
first_floor_columns.sort()

# Create output dataframe
output_df = pd.DataFrame({'Element ID': first_floor_columns})

# Save to CSV
output_df.to_csv('Task_1_out.csv', index=False)