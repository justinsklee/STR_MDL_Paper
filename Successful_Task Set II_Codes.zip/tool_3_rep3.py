import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find X-1 grid coordinate (first unique X coordinate when sorted)
x_coords = sorted(node_df['X (m)'].unique())
x1_coord = x_coords[0]  # X-1 grid coordinate

# Merge element data with node coordinates for both nodes
element_with_coords = element_df.merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 1', right_on='Node ID', 
    suffixes=('', '_node1')
).merge(
    node_df[['Node ID', 'X (m)', 'Y (m)', 'Z (m)']], 
    left_on='Node 2', right_on='Node ID', 
    suffixes=('_node1', '_node2')
)

# Identify braces (elements with change in both horizontal and vertical coordinates)
element_with_coords['is_brace'] = (
    (element_with_coords['X (m)_node1'] != element_with_coords['X (m)_node2']) |
    (element_with_coords['Y (m)_node1'] != element_with_coords['Y (m)_node2'])
) & (
    element_with_coords['Z (m)_node1'] != element_with_coords['Z (m)_node2']
)

# Filter braces along grid X-1 (both nodes have X-coordinate equal to X-1 grid)
braces_on_x1 = element_with_coords[
    element_with_coords['is_brace'] & 
    (element_with_coords['X (m)_node1'] == x1_coord) &
    (element_with_coords['X (m)_node2'] == x1_coord)
]

# Extract element numbers and sort in ascending order
brace_elements_x1 = braces_on_x1[['Element ID']].sort_values('Element ID')

# Save to CSV
brace_elements_x1.to_csv('Task_3_out.csv', index=False)

print(f"Braces along grid X-1 (x = {x1_coord}m):")
print(brace_elements_x1)