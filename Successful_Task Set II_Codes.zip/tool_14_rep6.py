import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Find the maximum Z coordinate to identify the roof level
max_z = node_df['Z (m)'].max()

# Merge element data with node data to get coordinates
element_with_nodes = element_df.merge(
    node_df.rename(columns={'Node ID': 'Node 1', 'X (m)': 'X1', 'Y (m)': 'Y1', 'Z (m)': 'Z1'}),
    on='Node 1'
).merge(
    node_df.rename(columns={'Node ID': 'Node 2', 'X (m)': 'X2', 'Y (m)': 'Y2', 'Z (m)': 'Z2'}),
    on='Node 2'
)

# Identify beams (horizontal elements - no change in Z coordinates)
beams = element_with_nodes[element_with_nodes['Z1'] == element_with_nodes['Z2']]

# Filter for roof beams (beams at the maximum Z level)
roof_beams = beams[beams['Z1'] == max_z]

# Merge with material data to get material names
roof_beams_with_material = roof_beams.merge(
    material_df[['Material Number', 'Name']], 
    left_on='Material', 
    right_on='Material Number'
)

# Select only the requested information and sort by Element ID
result = roof_beams_with_material[['Element ID', 'Name']].rename(columns={'Name': 'Material Name'})
result = result.sort_values('Element ID')

# Save to CSV
result.to_csv('Task_14_out.csv', index=False)