import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
long_section_df = pd.read_csv('Long_Section.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Function to calculate element length
def calculate_length(node1_id, node2_id, node_df):
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = node2['X (m)'] - node1['X (m)']
    dy = node2['Y (m)'] - node1['Y (m)']
    dz = node2['Z (m)'] - node1['Z (m)']
    
    return np.sqrt(dx**2 + dy**2 + dz**2)

# Function to classify elements
def classify_element(element_row, node_df):
    node1_id = element_row['Node 1']
    node2_id = element_row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    if dz > 0 and dx == 0 and dy == 0:
        return 'column'
    elif dz == 0:
        return 'beam'
    else:
        return 'brace'

# Get all supporting beam elements for office loads
supporting_beams = []

for _, load in office_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area'].strip('"')
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # Create pairs of consecutive nodes (forming the perimeter)
    node_pairs = []
    for i in range(len(nodes)):
        node_pairs.append((nodes[i], nodes[(i+1) % len(nodes)]))
    
    # Find elements that connect these node pairs
    for node1, node2 in node_pairs:
        # Find element connecting these nodes (in either direction)
        element = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        if not element.empty:
            element_row = element.iloc[0]
            # Check if it's a beam
            if classify_element(element_row, node_df) == 'beam':
                supporting_beams.append(element_row['Element ID'])

# Remove duplicates
supporting_beams = list(set(supporting_beams))

# Create output dataframe
output_data = []
for element_id in supporting_beams:
    element_row = element_df[element_df['Element ID'] == element_id].iloc[0]
    section_num = element_row['Section']
    length = calculate_length(element_row['Node 1'], element_row['Node 2'], node_df)
    
    output_data.append({
        'Element ID': element_id,
        'Section Number': section_num,
        'Length (m)': round(length, 4)
    })

# Sort by Element ID
output_df = pd.DataFrame(output_data)
output_df = output_df.sort_values('Element ID').reset_index(drop=True)

# Save to CSV
output_df.to_csv('Task_50_out.csv', index=False)

print("Results saved to Task_50_out.csv")
print(output_df)