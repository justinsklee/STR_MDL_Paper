import pandas as pd
import numpy as np

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
support_df = pd.read_csv('Support.csv')

# Get support node IDs
support_nodes = set(support_df['Node'].tolist())

# Classify elements based on node coordinates
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check for changes in coordinates
    dx = abs(x2 - x1) > 1e-6
    dy = abs(y2 - y1) > 1e-6
    dz = abs(z2 - z1) > 1e-6
    
    # Classification logic
    if dz and not dx and not dy:
        return 'Column'
    elif not dz:
        return 'Beam'
    elif (dx or dy) and dz:
        return 'Brace'
    else:
        return 'Unknown'

# Classify all elements
element_df['Element_Type'] = element_df.apply(classify_element, axis=1)

# Find columns that share supports with bracing elements
columns_with_shared_supports = set()

# Get all bracing elements
braces = element_df[element_df['Element_Type'] == 'Brace']

# For each brace, check if any of its nodes are support nodes
for _, brace in braces.iterrows():
    brace_nodes = {brace['Node 1'], brace['Node 2']}
    shared_support_nodes = brace_nodes.intersection(support_nodes)
    
    if shared_support_nodes:
        # Find columns that also connect to these shared support nodes
        for support_node in shared_support_nodes:
            columns_at_support = element_df[
                (element_df['Element_Type'] == 'Column') & 
                ((element_df['Node 1'] == support_node) | (element_df['Node 2'] == support_node))
            ]
            columns_with_shared_supports.update(columns_at_support['Element ID'].tolist())

# Create output dataframe
result_df = pd.DataFrame({
    'Element ID': sorted(list(columns_with_shared_supports))
})

# Save to CSV
result_df.to_csv('Task_8_out.csv', index=False)