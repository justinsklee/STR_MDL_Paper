import pandas as pd
import numpy as np

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Merge element data with node coordinates for both nodes
element_with_coords = element_df.merge(
    node_df, left_on='Node 1', right_on='Node ID', suffixes=('', '_node1')
).merge(
    node_df, left_on='Node 2', right_on='Node ID', suffixes=('', '_node2')
)

# Classify elements as columns, beams, or braces
def classify_element(row):
    x1, y1, z1 = row['X (m)'], row['Y (m)'], row['Z (m)']
    x2, y2, z2 = row['X (m)_node2'], row['Y (m)_node2'], row['Z (m)_node2']
    
    # Check if coordinates change
    x_change = abs(x2 - x1) > 1e-6
    y_change = abs(y2 - y1) > 1e-6
    z_change = abs(z2 - z1) > 1e-6
    
    # Columns: only z changes
    if z_change and not x_change and not y_change:
        return 'Column'
    # Beams: no z change
    elif not z_change:
        return 'Beam'
    # Braces: z changes AND (x or y changes)
    elif z_change and (x_change or y_change):
        return 'Brace'
    else:
        return 'Unknown'

element_with_coords['Element_Type'] = element_with_coords.apply(classify_element, axis=1)

# Get all braces
braces = element_with_coords[element_with_coords['Element_Type'] == 'Brace']

# Get element IDs that have beam-end-release
released_elements = set(beam_end_release_df['Element ID'])

# Find braces that are NOT beam-end-released
unreleased_braces = braces[~braces['Element ID'].isin(released_elements)]

# Create output dataframe with only Element ID column, sorted in ascending order
output_df = pd.DataFrame({
    'Element ID': sorted(unreleased_braces['Element ID'].tolist())
})

# Save to CSV
output_df.to_csv('Task_9_out.csv', index=False)

print(f"Found {len(output_df)} braces that are not beam-end-released")
print(output_df)