import pandas as pd
import os

# Create output folder
os.makedirs('Task_27_out', exist_ok=True)

# Load CSV files
elements_df = pd.read_csv('Element.csv')
nodes_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Identify columns (vertical elements - only z coordinate changes)
columns = []
for _, element in elements_df.iterrows():
    node1 = nodes_df[nodes_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if only z coordinate changes (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(element['Element ID'])

# Identify beams (horizontal elements - no z coordinate change)
beams = []
for _, element in elements_df.iterrows():
    node1 = nodes_df[nodes_df['Node ID'] == element['Node 1']].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == element['Node 2']].iloc[0]
    
    # Check if z coordinate doesn't change (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(element['Element ID'])

# Find nodes that are connected to columns
column_nodes = set()
for _, element in elements_df.iterrows():
    if element['Element ID'] in columns:
        column_nodes.add(element['Node 1'])
        column_nodes.add(element['Node 2'])

# Identify sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    element = elements_df[elements_df['Element ID'] == beam_id].iloc[0]
    node1 = element['Node 1']
    node2 = element['Node 2']
    
    # If neither node is connected to a column, it's a sub-beam
    if node1 not in column_nodes and node2 not in column_nodes:
        sub_beams.append(beam_id)

# Add beam-end-release for sub-beams
for sub_beam_id in sub_beams:
    # Check if already exists in beam_end_release
    if sub_beam_id not in beam_end_release_df['Element ID'].values:
        new_row = {
            'Element ID': sub_beam_id,
            'Type': 'Relative',
            'i-end release': '11',
            'Fxi': 0,
            'Fyi': 0,
            'Fzi': 0,
            'Mxi': 0,
            'Myi': 0,
            'Mzi': 0,
            'j-end release': '11',
            'Fxj': 0,
            'Fyj': 0,
            'Fzj': 0,
            'Mxj': 0,
            'Myj': 0,
            'Mzj': 0,
            'Group': 'Default'
        }
        beam_end_release_df = pd.concat([beam_end_release_df, pd.DataFrame([new_row])], ignore_index=True)

# Sort by Element ID in ascending order
beam_end_release_df = beam_end_release_df.sort_values('Element ID').reset_index(drop=True)

# Save updated beam end release file
beam_end_release_df.to_csv('Task_27_out/Beam_end_release.csv', index=False)

print("Sub-beams identified and beam-end-release applied:")
print(f"Sub-beam Element IDs: {sub_beams}")