import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get beam elements (horizontal elements - no change in z coordinates)
beam_elements = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in z coordinates)
    if node1_coords['Z (m)'] == node2_coords['Z (m)']:
        # Calculate length
        dx = node2_coords['X (m)'] - node1_coords['X (m)']
        dy = node2_coords['Y (m)'] - node1_coords['Y (m)']
        dz = node2_coords['Z (m)'] - node1_coords['Z (m)']
        
        length = np.sqrt(dx**2 + dy**2 + dz**2)
        
        # Check if length is shorter than 1.3m
        if length < 1.3:
            beam_elements.append({
                'Element Number': row['Element ID'],
                'Length': length
            })

# Create DataFrame and sort by element number
result_df = pd.DataFrame(beam_elements)
result_df = result_df.sort_values('Element Number')

# Save to CSV
result_df.to_csv('Task_19_out.csv', index=False)