import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
material_df = pd.read_csv('Material.csv')

# Get unique z-coordinates to identify floors
z_coords = sorted(node_df['Z (m)'].unique())
roof_level = max(z_coords)  # Highest level is the roof

# Get roof nodes (nodes at the highest elevation)
roof_nodes = node_df[node_df['Z (m)'] == roof_level]['Node ID'].tolist()

# Identify beams (elements with no change in z-coordinates)
beams = []
for _, element in element_df.iterrows():
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
    
    # Beam: no change in z-coordinates
    if node1_z == node2_z:
        beams.append(element['Element ID'])

# Get roof beams (beams at roof level)
roof_beams = []
for beam_id in beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
    
    if node1_z == roof_level:
        roof_beams.append(beam_id)

# Get material information for roof beams
result_data = []
for beam_id in sorted(roof_beams):
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    material_num = element['Material']
    material_name = material_df[material_df['Material Number'] == material_num]['Name'].iloc[0]
    
    result_data.append({
        'Element ID': beam_id,
        'Material Name': material_name
    })

# Create DataFrame and save to CSV
result_df = pd.DataFrame(result_data)
result_df.to_csv('Task_14_out.csv', index=False)

print(result_df)