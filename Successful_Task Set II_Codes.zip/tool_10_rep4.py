import pandas as pd

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')
node_df = pd.read_csv('Node.csv')

# Identify columns (vertical elements - change only in z coordinates)
columns = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(row['Element ID'])

# Identify beams (horizontal elements - no change in z coordinates)
beams = []
for _, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is horizontal (beam)
    if node1['Z (m)'] == node2['Z (m)']:
        beams.append(row['Element ID'])

# Find sub-beams (beams not directly connected to columns)
sub_beams = []
for beam_id in beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = beam_row['Node 1']
    node2_id = beam_row['Node 2']
    
    # Check if this beam is directly connected to any column
    is_connected_to_column = False
    for column_id in columns:
        column_row = element_df[element_df['Element ID'] == column_id].iloc[0]
        column_node1 = column_row['Node 1']
        column_node2 = column_row['Node 2']
        
        if (node1_id in [column_node1, column_node2] or 
            node2_id in [column_node1, column_node2]):
            is_connected_to_column = True
            break
    
    if not is_connected_to_column:
        sub_beams.append(beam_id)

# Find sub-beams that are NOT beam-end-released
# Beam-end-release means both 'i-end release' and 'j-end release' are '11'
released_elements = set()
for _, row in beam_end_release_df.iterrows():
    if row['i-end release'] == 11 and row['j-end release'] == 11:
        released_elements.add(row['Element ID'])

# Get sub-beams that are NOT released
non_released_sub_beams = [beam_id for beam_id in sub_beams if beam_id not in released_elements]

# Sort in ascending order
non_released_sub_beams.sort()

# Create output DataFrame
output_df = pd.DataFrame({'Element ID': non_released_sub_beams})

# Save to CSV file
output_df.to_csv('Task_10_out.csv', index=False)

print(f"Found {len(non_released_sub_beams)} sub-beams that are not beam-end-released")
print(output_df)