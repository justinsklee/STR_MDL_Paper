import pandas as pd
import os

# Create output folder
os.makedirs('Task_33_out', exist_ok=True)

# Load CSV files
beam_end_release = pd.read_csv('Beam_end_release.csv')
element = pd.read_csv('Element.csv')
node = pd.read_csv('Node.csv')

# Find X-3 grid coordinate (third unique X coordinate)
unique_x_coords = sorted(node['X (m)'].unique())
x3_coord = unique_x_coords[2] if len(unique_x_coords) >= 3 else None

if x3_coord is not None:
    # Find braces along grid X-3
    braces_x3 = []
    
    for _, elem in element.iterrows():
        node1_id = elem['Node 1']
        node2_id = elem['Node 2']
        
        # Get node coordinates
        node1 = node[node['Node ID'] == node1_id].iloc[0]
        node2 = node[node['Node ID'] == node2_id].iloc[0]
        
        # Check if both nodes are on X-3 grid
        if (abs(node1['X (m)'] - x3_coord) < 1e-6 and 
            abs(node2['X (m)'] - x3_coord) < 1e-6):
            
            # Check if it's a brace (diagonal element)
            x_change = abs(node2['X (m)'] - node1['X (m)'])
            y_change = abs(node2['Y (m)'] - node1['Y (m)'])
            z_change = abs(node2['Z (m)'] - node1['Z (m)'])
            
            # Brace: change in z AND (x or y) coordinates
            if z_change > 1e-6 and (x_change > 1e-6 or y_change > 1e-6):
                braces_x3.append(elem['Element ID'])
    
    # Remove beam-end-release for braces along grid X-3
    beam_end_release = beam_end_release[~beam_end_release['Element ID'].isin(braces_x3)]
    
    # Sort by Element ID
    beam_end_release = beam_end_release.sort_values('Element ID').reset_index(drop=True)

# Save updated file
beam_end_release.to_csv('Task_33_out/Beam_end_release.csv', index=False)