import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
third_floor_elevation = floor_elevations[2]

# Find all columns that have one node at third floor and another node above third floor
third_floor_columns = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates of both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if this is a column (vertical element - only z changes, x and y stay same)
    is_column = (node1['X (m)'] == node2['X (m)'] and 
                node1['Y (m)'] == node2['Y (m)'] and 
                node1['Z (m)'] != node2['Z (m)'])
    
    if is_column:
        # Check if one node is at third floor and other is above
        z1, z2 = node1['Z (m)'], node2['Z (m)']
        if ((z1 == third_floor_elevation and z2 > third_floor_elevation) or 
            (z2 == third_floor_elevation and z1 > third_floor_elevation)):
            third_floor_columns.append(element['Element ID'])

# Get section names for these columns
result_data = []
for element_id in third_floor_columns:
    element_row = element_df[element_df['Element ID'] == element_id].iloc[0]
    section_number = element_row['Section']
    section_name = section_df[section_df['Section Number'] == section_number]['Section Name'].iloc[0]
    result_data.append({'Element ID': element_id, 'Section Name': section_name})

# Create output dataframe and sort by Element ID
output_df = pd.DataFrame(result_data)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_11_out.csv', index=False)