import pandas as pd
import numpy as np
import os

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Create output folder
os.makedirs('Task_21_out', exist_ok=True)

# Find unique floor elevations
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Identify second floor elevation (one floor above ground)
ground_floor = floor_elevations[0]  # z = 0.0
second_floor = floor_elevations[1]  # First floor above ground

# Find columns that have one node on the second floor and the other node above
second_floor_columns = []

for idx, row in elements_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates of both nodes
    node1_coords = nodes_df[nodes_df['Node ID'] == node1_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    node2_coords = nodes_df[nodes_df['Node ID'] == node2_id][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
    
    # Check if element is a column (vertical - only Z changes, X and Y stay same)
    is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                 node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                 node1_coords['Z (m)'] != node2_coords['Z (m)'])
    
    if is_column:
        # Check if one node is on second floor and other is above
        z1, z2 = node1_coords['Z (m)'], node2_coords['Z (m)']
        if (z1 == second_floor and z2 > second_floor) or (z2 == second_floor and z1 > second_floor):
            second_floor_columns.append(row['Element ID'])

# Update section for second floor columns
elements_df.loc[elements_df['Element ID'].isin(second_floor_columns), 'Section'] = 102

# Save updated Element.csv
elements_df.to_csv('Task_21_out/Element.csv', index=False)

print(f"Updated {len(second_floor_columns)} second floor columns to section 102")
print(f"Column IDs: {second_floor_columns}")