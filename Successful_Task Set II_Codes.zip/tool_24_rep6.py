import pandas as pd
import os

# Create output folder
os.makedirs('Task_24_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())
first_floor_z = floor_elevations[0]  # Ground level (z = 0.0m)
second_floor_z = floor_elevations[1] if len(floor_elevations) > 1 else first_floor_z + 1

# Function to classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if element changes in z AND (x or y) coordinates
    z_change = abs(z2 - z1) > 1e-6
    xy_change = abs(x2 - x1) > 1e-6 or abs(y2 - y1) > 1e-6
    
    if z_change and xy_change:
        return 'brace'
    elif z_change and not xy_change:
        return 'column'
    elif not z_change and xy_change:
        return 'beam'
    else:
        return 'unknown'

# Classify all elements
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find first floor braces (one node at first floor, other node above)
first_floor_braces = []
for idx, row in element_df.iterrows():
    if row['element_type'] == 'brace':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
        node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
        
        # Check if one node is at first floor and other is above
        if (abs(node1_z - first_floor_z) < 1e-6 and node2_z > first_floor_z) or \
           (abs(node2_z - first_floor_z) < 1e-6 and node1_z > first_floor_z):
            first_floor_braces.append(row['Element ID'])

# Update material for first floor braces
element_df.loc[element_df['Element ID'].isin(first_floor_braces), 'Material'] = 1003

# Remove the temporary classification column
element_df = element_df.drop('element_type', axis=1)

# Save updated Element.csv
element_df.to_csv('Task_24_out/Element.csv', index=False)