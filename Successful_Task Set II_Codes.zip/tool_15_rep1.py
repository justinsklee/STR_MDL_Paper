import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Second floor is at index 1 (first floor is at index 0)
if len(floor_elevations) < 2:
    print("Error: Not enough floors in the model")
    exit()

second_floor_elevation = floor_elevations[1]

# Find bracing elements on second floor
# Braces have one node at the floor elevation and another node above that elevation
second_floor_braces = []

for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    node1_z = node1_coords['Z (m)']
    node2_z = node2_coords['Z (m)']
    node1_x = node1_coords['X (m)']
    node1_y = node1_coords['Y (m)']
    node2_x = node2_coords['X (m)']
    node2_y = node2_coords['Y (m)']
    
    # Check if one node is at second floor and the other is above
    # And there's change in both horizontal (x or y) and vertical (z) coordinates
    has_horizontal_change = (node1_x != node2_x) or (node1_y != node2_y)
    has_vertical_change = node1_z != node2_z
    
    # Check if it's a brace (diagonal element)
    is_brace = has_horizontal_change and has_vertical_change
    
    # Check if one node is at second floor and other is above
    is_second_floor_brace = ((node1_z == second_floor_elevation and node2_z > second_floor_elevation) or 
                            (node2_z == second_floor_elevation and node1_z > second_floor_elevation))
    
    if is_brace and is_second_floor_brace:
        second_floor_braces.append({
            'Element ID': element['Element ID'],
            'Material': element['Material']
        })

# Create output dataframe
output_df = pd.DataFrame(second_floor_braces)
output_df = output_df.sort_values('Element ID')

# Save to CSV
output_df.to_csv('Task_15_out.csv', index=False)

print(f"Found {len(second_floor_braces)} second floor bracing elements")
print(output_df)