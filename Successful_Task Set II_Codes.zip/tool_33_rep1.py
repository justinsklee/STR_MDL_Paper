import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_33_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Find X-direction grids (unique X coordinates)
x_coords = sorted(node_df['X (m)'].unique())

# Find grid X-3 coordinate (third X grid)
if len(x_coords) >= 3:
    x3_coord = x_coords[2]  # Third grid (X-3)
    
    # Find braces along grid X-3
    braces_on_x3 = []
    
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates of both nodes
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if both nodes are on grid X-3 (same X coordinate as X-3)
        if node1['X (m)'] == x3_coord and node2['X (m)'] == x3_coord:
            # Check if it's a brace (change in both horizontal and vertical coordinates)
            x_change = abs(node1['X (m)'] - node2['X (m)'])
            y_change = abs(node1['Y (m)'] - node2['Y (m)'])
            z_change = abs(node1['Z (m)'] - node2['Z (m)'])
            
            # Brace: change in z AND (x or y) coordinates
            if z_change > 0 and (x_change > 0 or y_change > 0):
                braces_on_x3.append(element['Element ID'])
    
    # Remove beam-end-release entries for braces on grid X-3
    updated_beam_end_release_df = beam_end_release_df[~beam_end_release_df['Element ID'].isin(braces_on_x3)]
    
    # Sort by Element ID in ascending order
    updated_beam_end_release_df = updated_beam_end_release_df.sort_values('Element ID').reset_index(drop=True)
    
    # Save updated file
    updated_beam_end_release_df.to_csv('Task_33_out/Beam_end_release.csv', index=False)
    
    print(f"Removed beam-end-release for {len(braces_on_x3)} braces on grid X-3")
    if braces_on_x3:
        print(f"Affected element IDs: {braces_on_x3}")
else:
    print("Grid X-3 not found in the model")