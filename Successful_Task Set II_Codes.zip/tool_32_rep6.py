import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_32_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
if len(floor_elevations) >= 3:
    third_floor_elevation = floor_elevations[2]
    
    # Find nodes on third floor
    third_floor_nodes = node_df[node_df['Z (m)'] == third_floor_elevation]['Node ID'].tolist()
    
    # Find nodes above third floor
    above_third_floor_nodes = node_df[node_df['Z (m)'] > third_floor_elevation]['Node ID'].tolist()
    
    # Identify braces connected to third floor
    # Braces have one node on third floor and one node above third floor
    third_floor_braces = []
    
    for _, element in element_df.iterrows():
        node1 = element['Node 1']
        node2 = element['Node 2']
        
        # Check if this is a brace connected to third floor
        if ((node1 in third_floor_nodes and node2 in above_third_floor_nodes) or 
            (node2 in third_floor_nodes and node1 in above_third_floor_nodes)):
            
            # Verify it's actually a brace (diagonal element)
            node1_coords = node_df[node_df['Node ID'] == node1][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
            node2_coords = node_df[node_df['Node ID'] == node2][['X (m)', 'Y (m)', 'Z (m)']].iloc[0]
            
            # Brace: change in (x or y) AND z coordinates
            x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 1e-6
            y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 1e-6
            z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
            
            if (x_change or y_change) and z_change:
                third_floor_braces.append(element['Element ID'])
    
    # Update section for third floor braces to 102
    for brace_id in third_floor_braces:
        element_df.loc[element_df['Element ID'] == brace_id, 'Section'] = 102

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_32_out/Element.csv', index=False)