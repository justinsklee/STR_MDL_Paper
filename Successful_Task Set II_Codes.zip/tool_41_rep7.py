import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Filter beams with section 101 on the roof
roof_beams_101 = element_df[
    (element_df['Section'] == 101) &
    (element_df['Node 1'].isin(node_df[node_df['Z (m)'] == roof_elevation]['Node ID'])) &
    (element_df['Node 2'].isin(node_df[node_df['Z (m)'] == roof_elevation]['Node ID']))
]

# Get section properties for section 101
section_101 = section_df[section_df['Section Number'] == 101]
area_101 = section_101['Area'].iloc[0]  # m²

# Calculate total length of roof beams with section 101
total_length = 0
for _, beam in roof_beams_101.iterrows():
    node1 = node_df[node_df['Node ID'] == beam['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == beam['Node 2']].iloc[0]
    
    length = np.sqrt(
        (node2['X (m)'] - node1['X (m)'])**2 +
        (node2['Y (m)'] - node1['Y (m)'])**2 +
        (node2['Z (m)'] - node1['Z (m)'])**2
    )
    total_length += length

# Calculate total weight
density = 7850  # kg/m³
total_volume = total_length * area_101  # m³
total_weight = total_volume * density  # kg

# Round up to nearest 10 kg
total_weight_rounded = np.ceil(total_weight / 10) * 10

# Create output dataframe
output_df = pd.DataFrame({
    'Total Weight (kg)': [int(total_weight_rounded)]
})

# Save to CSV
output_df.to_csv('Task_41_out.csv', index=False)