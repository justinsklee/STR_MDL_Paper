import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_29_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof level (highest z-coordinate)
roof_level = node_df['Z (m)'].max()

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element changes only in z (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        return 'column'
    # Check if element has no change in z (beam)
    elif node1['Z (m)'] == node2['Z (m)']:
        return 'beam'
    # Otherwise it's a brace
    else:
        return 'brace'

# Add element classification
element_df['element_type'] = element_df.apply(classify_element, axis=1)

# Find all columns to identify which beams are directly connected to columns
columns = element_df[element_df['element_type'] == 'column']
column_nodes = set()
for _, col in columns.iterrows():
    column_nodes.add(col['Node 1'])
    column_nodes.add(col['Node 2'])

# Find beams on the roof level
roof_beams = element_df[
    (element_df['element_type'] == 'beam') & 
    (element_df.apply(lambda row: node_df[node_df['Node ID'] == row['Node 1']]['Z (m)'].iloc[0] == roof_level, axis=1))
]

# Identify sub-beams on roof (beams not directly connected to columns)
roof_sub_beams = []
for _, beam in roof_beams.iterrows():
    node1 = beam['Node 1']
    node2 = beam['Node 2']
    
    # Check if both nodes are NOT connected to columns
    if node1 not in column_nodes and node2 not in column_nodes:
        roof_sub_beams.append(beam['Element ID'])

# Remove roof sub-beams from element dataframe
updated_element_df = element_df[~element_df['Element ID'].isin(roof_sub_beams)].copy()

# Remove the temporary classification column
updated_element_df = updated_element_df.drop('element_type', axis=1)

# Sort by Element ID
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_29_out/Element.csv', index=False)

print(f"Removed {len(roof_sub_beams)} sub-beams from roof level")
print(f"Removed elements: {roof_sub_beams}")