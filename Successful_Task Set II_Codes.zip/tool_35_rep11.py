import pandas as pd
import os

# Create output folder
os.makedirs('Task_35_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find residential loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get all nodes that define residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    residential_nodes.update(nodes)

# Find columns that support residential loads (columns below residential load nodes)
supporting_columns = []

for node_id in residential_nodes:
    # Get the z-coordinate of the residential load node
    load_node = node_df[node_df['Node ID'] == node_id].iloc[0]
    load_z = load_node['Z (m)']
    load_x = load_node['X (m)']
    load_y = load_node['Y (m)']
    
    # Find columns that have one node at the same x,y coordinates but lower z (supporting from below)
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a column (vertical element)
        if (node1['X (m)'] == node2['X (m)'] and 
            node1['Y (m)'] == node2['Y (m)'] and 
            node1['Z (m)'] != node2['Z (m)']):
            
            # Check if one node is at the load location and the other is below
            if ((node1['X (m)'] == load_x and node1['Y (m)'] == load_y and node1['Z (m)'] == load_z and node2['Z (m)'] < load_z) or
                (node2['X (m)'] == load_x and node2['Y (m)'] == load_y and node2['Z (m)'] == load_z and node1['Z (m)'] < load_z)):
                supporting_columns.append(element['Element ID'])

# Update material for supporting columns to SHN355 (material 1003)
for col_id in supporting_columns:
    element_df.loc[element_df['Element ID'] == col_id, 'Material'] = 1003

# Save updated Element.csv
element_df.to_csv('Task_35_out/Element.csv', index=False)

print(f"Updated {len(supporting_columns)} columns supporting residential loads to SHN355 material")
print(f"Column IDs updated: {supporting_columns}")