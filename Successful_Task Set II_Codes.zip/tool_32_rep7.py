import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_32_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Identify third floor elevation (index 2 since we start from 0)
if len(floor_elevations) >= 3:
    third_floor_z = floor_elevations[2]
else:
    print("Model does not have a third floor")
    exit()

# Function to classify elements
def classify_element(row):
    node1_id = int(row['Node 1'])
    node2_id = int(row['Node 2'])
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x1, y1, z1 = node1['X (m)'], node1['Y (m)'], node1['Z (m)']
    x2, y2, z2 = node2['X (m)'], node2['Y (m)'], node2['Z (m)']
    
    # Check if element is a column (vertical - only z changes)
    if abs(x1 - x2) < 1e-6 and abs(y1 - y2) < 1e-6 and abs(z1 - z2) > 1e-6:
        return 'column'
    # Check if element is a beam (horizontal - no z change)
    elif abs(z1 - z2) < 1e-6:
        return 'beam'
    # Otherwise it's a brace (diagonal - x/y and z change)
    else:
        return 'brace'

# Function to check if element is associated with a specific floor
def is_element_on_floor(row, floor_z):
    node1_id = int(row['Node 1'])
    node2_id = int(row['Node 2'])
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    z1, z2 = node1['Z (m)'], node2['Z (m)']
    
    element_type = classify_element(row)
    
    if element_type == 'brace':
        # For braces, one node should be at the floor level, the other above
        return (abs(z1 - floor_z) < 1e-6 and z2 > floor_z) or (abs(z2 - floor_z) < 1e-6 and z1 > floor_z)
    
    return False

# Update section for third floor braces
for idx, row in element_df.iterrows():
    if is_element_on_floor(row, third_floor_z):
        element_df.at[idx, 'Section'] = 102

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_32_out/Element.csv', index=False)