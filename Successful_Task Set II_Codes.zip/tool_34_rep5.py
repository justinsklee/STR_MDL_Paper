import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_34_out', exist_ok=True)

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Find beams supporting office loads
beams_to_update = set()

for _, load in office_loads.iterrows():
    # Parse nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Find beams connecting these nodes in sequence
    beam_connections = []
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]  # Connect back to first node for last pair
        beam_connections.append((node1, node2))
    
    # Find elements that match these beam connections
    for node1, node2 in beam_connections:
        # Check both directions (node1->node2 and node2->node1)
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            # Verify it's a beam (horizontal element - same Z coordinate for both nodes)
            node1_z = node_df[node_df['Node ID'] == element['Node 1']]['Z (m)'].iloc[0]
            node2_z = node_df[node_df['Node ID'] == element['Node 2']]['Z (m)'].iloc[0]
            
            if node1_z == node2_z:  # Beam (horizontal element)
                beams_to_update.add(element['Element ID'])

# Update section numbers for identified beams
for beam_id in beams_to_update:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 101

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_34_out/Element.csv', index=False)