import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
beam_end_release_df = pd.read_csv('Beam_end_release.csv')

# Find third floor elevation (z = 2.0m based on the data)
floor_elevations = sorted(node_df['Z (m)'].unique())
third_floor_elevation = floor_elevations[2]  # Third floor (index 2)

# Find all beams on third floor (beams have no change in z coordinates)
third_floor_beams = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a beam (no change in z coordinates) on third floor
    if node1['Z (m)'] == node2['Z (m)'] == third_floor_elevation:
        third_floor_beams.append(element['Element ID'])

# Find columns on third floor (elements with only z coordinate change)
third_floor_columns = []
for _, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (change only in z coordinates)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        # Check if one node is on third floor
        if node1['Z (m)'] == third_floor_elevation or node2['Z (m)'] == third_floor_elevation:
            third_floor_columns.append(element['Element ID'])

# Find nodes that are connected to columns
column_connected_nodes = set()
for col_id in third_floor_columns:
    element = element_df[element_df['Element ID'] == col_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Add the node that's on third floor
    if node1['Z (m)'] == third_floor_elevation:
        column_connected_nodes.add(node1_id)
    if node2['Z (m)'] == third_floor_elevation:
        column_connected_nodes.add(node2_id)

# Find sub-beams (beams not directly connected to columns)
third_floor_sub_beams = []
for beam_id in third_floor_beams:
    element = element_df[element_df['Element ID'] == beam_id].iloc[0]
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Check if neither node is connected to a column
    if node1_id not in column_connected_nodes and node2_id not in column_connected_nodes:
        third_floor_sub_beams.append(beam_id)

# Create output dataframe with beam-end-release status
output_data = []
for beam_id in sorted(third_floor_sub_beams):
    # Check if beam has release in beam_end_release_df
    release_info = beam_end_release_df[beam_end_release_df['Element ID'] == beam_id]
    
    if not release_info.empty:
        i_release = release_info.iloc[0]['i-end release']
        j_release = release_info.iloc[0]['j-end release']
        
        # Convert release codes to 0 (released) or 1 (fixed)
        # Release code '10' or '11' means released (0), otherwise fixed (1)
        i_status = 0 if str(i_release) in ['10', '11'] else 1
        j_status = 0 if str(j_release) in ['10', '11'] else 1
    else:
        # No release information means fixed
        i_status = 1
        j_status = 1
    
    output_data.append({
        'Element ID': beam_id,
        'i-end': i_status,
        'j-end': j_status
    })

# Create and save output CSV
output_df = pd.DataFrame(output_data)
output_df.to_csv('Task_31_out.csv', index=False)

print(f"Found {len(third_floor_sub_beams)} sub-beams on third floor")
print("Output saved to Task_31_out.csv")