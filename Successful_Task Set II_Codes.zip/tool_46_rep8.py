import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_46_out', exist_ok=True)

# Find first floor elevation (minimum z coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find X-1 grid coordinate (minimum x coordinate)
x1_coord = node_df['X (m)'].min()

# Find columns on first floor along grid X-1 with section 105
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (vertical element - only z changes)
    is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                node1_coords['Z (m)'] != node2_coords['Z (m)'])
    
    # Check if it's on grid X-1
    on_x1_grid = (node1_coords['X (m)'] == x1_coord and node2_coords['X (m)'] == x1_coord)
    
    # Check if it's a first floor column (one node at first floor, other above)
    first_floor_column = ((node1_coords['Z (m)'] == first_floor_z and node2_coords['Z (m)'] > first_floor_z) or
                         (node2_coords['Z (m)'] == first_floor_z and node1_coords['Z (m)'] > first_floor_z))
    
    # Check if it has section 105
    has_section_105 = (row['Section'] == 105)
    
    # Update material if all conditions are met
    if is_column and on_x1_grid and first_floor_column and has_section_105:
        element_df.at[idx, 'Material'] = 1002

# Save updated Element.csv
element_df.to_csv('Task_46_out/Element.csv', index=False)