import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_32_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0: ground, 1: second floor, 2: third floor)
if len(floor_elevations) < 3:
    print("Model does not have a third floor")
else:
    third_floor_elevation = floor_elevations[2]
    
    # Find braces on third floor
    # Braces have one node at third floor elevation and another node above it
    third_floor_braces = []
    
    for idx, row in element_df.iterrows():
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        # Get coordinates for both nodes
        node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if this is a brace on third floor
        # One node at third floor elevation, other node above
        node1_at_third = node1_coords['Z (m)'] == third_floor_elevation
        node2_at_third = node2_coords['Z (m)'] == third_floor_elevation
        node1_above_third = node1_coords['Z (m)'] > third_floor_elevation
        node2_above_third = node2_coords['Z (m)'] > third_floor_elevation
        
        # Check if it's a brace (diagonal element)
        x_change = node1_coords['X (m)'] != node2_coords['X (m)'] or node1_coords['Y (m)'] != node2_coords['Y (m)']
        z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
        is_brace = x_change and z_change
        
        if is_brace and ((node1_at_third and node2_above_third) or (node2_at_third and node1_above_third)):
            third_floor_braces.append(idx)
    
    # Update section for third floor braces
    for brace_idx in third_floor_braces:
        element_df.at[brace_idx, 'Section'] = 102
    
    # Sort by Element ID
    element_df = element_df.sort_values('Element ID').reset_index(drop=True)
    
    # Save updated Element.csv
    element_df.to_csv('Task_32_out/Element.csv', index=False)