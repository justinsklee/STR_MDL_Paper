import pandas as pd
import numpy as np
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_39_out', exist_ok=True)

# Find first floor elevation (minimum z-coordinate)
first_floor_z = node_df['Z (m)'].min()

# Find second floor elevation (next unique z-coordinate above first floor)
unique_z = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z[1] if len(unique_z) > 1 else first_floor_z + 1

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Identify braces on first floor along grid X-1
braces_to_remove = []

for idx, element in element_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    # Get coordinates for both nodes
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal: change in x/y AND z coordinates)
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if both nodes are on X-1 grid
        node1_on_x1 = abs(node1['X (m)'] - x1_coord) < 1e-6
        node2_on_x1 = abs(node2['X (m)'] - x1_coord) < 1e-6
        
        # Check if one node is on first floor and other is above
        node1_first_floor = abs(node1['Z (m)'] - first_floor_z) < 1e-6
        node2_first_floor = abs(node2['Z (m)'] - first_floor_z) < 1e-6
        node1_above_first = node1['Z (m)'] > first_floor_z
        node2_above_first = node2['Z (m)'] > first_floor_z
        
        on_first_floor = (node1_first_floor and node2_above_first) or (node2_first_floor and node1_above_first)
        
        if node1_on_x1 and node2_on_x1 and on_first_floor:
            braces_to_remove.append(element['Element ID'])

# Remove identified braces
element_df_updated = element_df[~element_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID
element_df_updated = element_df_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df_updated.to_csv('Task_39_out/Element.csv', index=False)