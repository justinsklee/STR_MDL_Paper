import pandas as pd
import numpy as np
import os

# Create output folder
os.makedirs('Task_40_out', exist_ok=True)

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Find Y-1 grid coordinate (minimum Y coordinate)
y1_coord = nodes_df['Y (m)'].min()

# Find second floor elevation (one floor above ground level z=0.0)
floor_elevations = sorted(nodes_df['Z (m)'].unique())
second_floor_z = floor_elevations[1]  # Second floor is index 1 (first is ground at index 0)

# Identify braces: elements that change in both horizontal (x or y) and vertical (z) coordinates
braces_to_remove = []

for idx, row in elements_df.iterrows():
    element_id = row['Element ID']
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2_coords = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (changes in both horizontal and vertical coordinates)
    x_change = abs(node1_coords['X (m)'] - node2_coords['X (m)']) > 1e-6
    y_change = abs(node1_coords['Y (m)'] - node2_coords['Y (m)']) > 1e-6
    z_change = abs(node1_coords['Z (m)'] - node2_coords['Z (m)']) > 1e-6
    
    is_brace = z_change and (x_change or y_change)
    
    if is_brace:
        # Check if brace is along Y-1 grid (both nodes have Y coordinate = y1_coord)
        node1_on_y1 = abs(node1_coords['Y (m)'] - y1_coord) < 1e-6
        node2_on_y1 = abs(node2_coords['Y (m)'] - y1_coord) < 1e-6
        
        if node1_on_y1 and node2_on_y1:
            # Check if brace has one node on second floor
            node1_on_second_floor = abs(node1_coords['Z (m)'] - second_floor_z) < 1e-6
            node2_on_second_floor = abs(node2_coords['Z (m)'] - second_floor_z) < 1e-6
            
            # Brace is associated with second floor if one node is on second floor and other is above
            if (node1_on_second_floor and node2_coords['Z (m)'] > second_floor_z) or \
               (node2_on_second_floor and node1_coords['Z (m)'] > second_floor_z):
                braces_to_remove.append(element_id)

# Remove identified braces
elements_df_updated = elements_df[~elements_df['Element ID'].isin(braces_to_remove)]

# Sort by Element ID in ascending order
elements_df_updated = elements_df_updated.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
elements_df_updated.to_csv('Task_40_out/Element.csv', index=False)