import pandas as pd

# Load CSV files
floor_load_df = pd.read_csv('Floor_Load.csv')
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find residential floor loads
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Extract supporting beam element numbers
supporting_beams = []

for _, load in residential_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # Create beam pairs from the 4 nodes (forming a rectangle)
    beam_pairs = [
        (nodes[0], nodes[1]),
        (nodes[1], nodes[2]), 
        (nodes[2], nodes[3]),
        (nodes[3], nodes[0])
    ]
    
    # Find element IDs for these beam pairs
    for node1, node2 in beam_pairs:
        # Check both directions since beam can be defined either way
        beam_element = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        if not beam_element.empty:
            supporting_beams.extend(beam_element['Element ID'].tolist())

# Remove duplicates and sort
supporting_beams = sorted(list(set(supporting_beams)))

# Create output dataframe
output_df = pd.DataFrame({'Element ID': supporting_beams})

# Save to CSV
output_df.to_csv('Task_5_out.csv', index=False)