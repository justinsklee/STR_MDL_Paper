import pandas as pd

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Get unique floor elevations and sort them
floor_elevations = sorted(node_df['Z (m)'].unique())

# Third floor is at index 2 (0=ground, 1=second, 2=third)
if len(floor_elevations) < 3:
    print("Model does not have a third floor")
    third_floor_columns = pd.DataFrame(columns=['Element ID', 'Section Name'])
else:
    third_floor_elevation = floor_elevations[2]
    
    # Find columns that have one node at third floor and another node above third floor
    third_floor_columns = []
    
    for _, element in element_df.iterrows():
        node1_id = element['Node 1']
        node2_id = element['Node 2']
        
        # Get coordinates for both nodes
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        # Check if element is a column (vertical: only z changes, x and y stay same)
        is_column = (node1['X (m)'] == node2['X (m)'] and 
                    node1['Y (m)'] == node2['Y (m)'] and 
                    node1['Z (m)'] != node2['Z (m)'])
        
        if is_column:
            # Check if one node is at third floor and other is above
            node1_z = node1['Z (m)']
            node2_z = node2['Z (m)']
            
            if ((node1_z == third_floor_elevation and node2_z > third_floor_elevation) or
                (node2_z == third_floor_elevation and node1_z > third_floor_elevation)):
                
                # Get section name
                section_num = element['Section']
                section_name = section_df[section_df['Section Number'] == section_num]['Section Name'].iloc[0]
                
                third_floor_columns.append({
                    'Element ID': element['Element ID'],
                    'Section Name': section_name
                })
    
    # Convert to DataFrame and sort by Element ID
    third_floor_columns = pd.DataFrame(third_floor_columns)
    if not third_floor_columns.empty:
        third_floor_columns = third_floor_columns.sort_values('Element ID')

# Save to CSV
third_floor_columns.to_csv('Task_11_out.csv', index=False)

print(f"Found {len(third_floor_columns)} third floor columns")
print(third_floor_columns)