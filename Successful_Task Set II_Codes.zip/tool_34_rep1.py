import pandas as pd
import os

# Create output folder
os.makedirs('Task_34_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get all beams supporting office loads
beams_to_update = []

for _, load in office_loads.iterrows():
    # Parse the nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    
    # Find beams connecting these nodes in sequence
    # For nodes [a,b,c,d], beams are (a,b), (b,c), (c,d), (d,a)
    beam_pairs = []
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]  # Wrap around to first node
        beam_pairs.append((min(node1, node2), max(node1, node2)))
    
    # Find elements that match these beam pairs
    for node1, node2 in beam_pairs:
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        beams_to_update.extend(matching_elements['Element ID'].tolist())

# Remove duplicates
beams_to_update = list(set(beams_to_update))

# Update section numbers for these beams
element_df.loc[element_df['Element ID'].isin(beams_to_update), 'Section'] = 101

# Save updated Element.csv
element_df.to_csv('Task_34_out/Element.csv', index=False)