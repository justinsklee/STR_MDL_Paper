import pandas as pd
import os

# Create output folder
os.makedirs('Task_42_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Classify elements
def classify_element(row):
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    x_change = abs(node1['X (m)'] - node2['X (m)']) > 1e-6
    y_change = abs(node1['Y (m)'] - node2['Y (m)']) > 1e-6
    z_change = abs(node1['Z (m)'] - node2['Z (m)']) > 1e-6
    
    if z_change and not x_change and not y_change:
        return 'column'
    elif not z_change:
        return 'beam'
    else:
        return 'brace'

# Add classification to elements
element_df['classification'] = element_df.apply(classify_element, axis=1)

# Find beams on the roof (both nodes at roof elevation)
roof_beams = []
for idx, row in element_df.iterrows():
    if row['classification'] == 'beam':
        node1_id = row['Node 1']
        node2_id = row['Node 2']
        
        node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
        node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
        
        if node1['Z (m)'] == roof_elevation and node2['Z (m)'] == roof_elevation:
            roof_beams.append(row['Element ID'])

# Find all braces
braces = element_df[element_df['classification'] == 'brace']['Element ID'].tolist()

# Find nodes connected to braces
brace_nodes = set()
for brace_id in braces:
    brace_row = element_df[element_df['Element ID'] == brace_id].iloc[0]
    brace_nodes.add(brace_row['Node 1'])
    brace_nodes.add(brace_row['Node 2'])

# Find roof beams not connected to any braces
roof_beams_not_connected_to_braces = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_node1 = beam_row['Node 1']
    beam_node2 = beam_row['Node 2']
    
    if beam_node1 not in brace_nodes and beam_node2 not in brace_nodes:
        roof_beams_not_connected_to_braces.append(beam_id)

# Update section for identified beams
for beam_id in roof_beams_not_connected_to_braces:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 104

# Remove the classification column
element_df = element_df.drop('classification', axis=1)

# Save updated Element.csv file
element_df.to_csv('Task_42_out/Element.csv', index=False)

print(f"Updated {len(roof_beams_not_connected_to_braces)} roof beams with section 104")
print(f"Beam IDs updated: {roof_beams_not_connected_to_braces}")