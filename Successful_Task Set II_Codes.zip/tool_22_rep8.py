import pandas as pd
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Get all beams (elements with no change in z-coordinates between nodes)
beams = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1_z = node_df[node_df['Node ID'] == node1_id]['Z (m)'].iloc[0]
    node2_z = node_df[node_df['Node ID'] == node2_id]['Z (m)'].iloc[0]
    
    # Check if it's a beam (no change in z-coordinates)
    if node1_z == node2_z:
        beams.append({
            'Element ID': row['Element ID'],
            'elevation': node1_z,
            'node1': node1_id,
            'node2': node2_id
        })

# Filter beams on the roof
roof_beams = [beam for beam in beams if beam['elevation'] == roof_elevation]

# Find columns (elements with change only in z-coordinates)
columns = []
for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    node1_data = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_data = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a column (change only in z, no change in x and y)
    if (node1_data['X (m)'] == node2_data['X (m)'] and 
        node1_data['Y (m)'] == node2_data['Y (m)'] and 
        node1_data['Z (m)'] != node2_data['Z (m)']):
        columns.append(row['Element ID'])

# Find nodes that are connected to columns
column_connected_nodes = set()
for idx, row in element_df.iterrows():
    if row['Element ID'] in columns:
        column_connected_nodes.add(row['Node 1'])
        column_connected_nodes.add(row['Node 2'])

# Identify sub-beams on roof (beams not directly connected to columns)
roof_sub_beams = []
for beam in roof_beams:
    if beam['node1'] not in column_connected_nodes and beam['node2'] not in column_connected_nodes:
        roof_sub_beams.append(beam['Element ID'])

# Update section for roof sub-beams
for idx, row in element_df.iterrows():
    if row['Element ID'] in roof_sub_beams:
        element_df.at[idx, 'Section'] = 104

# Save updated Element.csv
element_df.to_csv('Task_22_out/Element.csv', index=False)