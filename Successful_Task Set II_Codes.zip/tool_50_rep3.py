import pandas as pd
import numpy as np

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Function to calculate element length
def calculate_length(node1_id, node2_id, node_df):
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = node2['X (m)'] - node1['X (m)']
    dy = node2['Y (m)'] - node1['Y (m)']
    dz = node2['Z (m)'] - node1['Z (m)']
    
    return np.sqrt(dx**2 + dy**2 + dz**2)

# Function to classify element type
def classify_element(node1_id, node2_id, node_df):
    node1 = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2 = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    dx = abs(node2['X (m)'] - node1['X (m)'])
    dy = abs(node2['Y (m)'] - node1['Y (m)'])
    dz = abs(node2['Z (m)'] - node1['Z (m)'])
    
    if dz > 0 and dx == 0 and dy == 0:
        return 'column'
    elif dz == 0:
        return 'beam'
    else:
        return 'brace'

# Get supporting beams for office loads
supporting_beams = []

for _, load in office_loads.iterrows():
    # Parse nodes from the load area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Find beams that connect these nodes in sequence
    beam_pairs = []
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]  # Connect last node to first
        beam_pairs.append((min(node1, node2), max(node1, node2)))
    
    # Find elements that match these node pairs and are beams
    for node1, node2 in beam_pairs:
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, element in matching_elements.iterrows():
            element_type = classify_element(element['Node 1'], element['Node 2'], node_df)
            if element_type == 'beam':
                length = calculate_length(element['Node 1'], element['Node 2'], node_df)
                supporting_beams.append({
                    'Element ID': element['Element ID'],
                    'Section Number': element['Section'],
                    'Length (m)': round(length, 3)
                })

# Remove duplicates and sort by Element ID
supporting_beams_df = pd.DataFrame(supporting_beams).drop_duplicates().sort_values('Element ID')

# Save to CSV
supporting_beams_df.to_csv('Task_50_out.csv', index=False)

print(supporting_beams_df)