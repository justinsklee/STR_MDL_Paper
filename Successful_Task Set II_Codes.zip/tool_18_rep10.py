import pandas as pd
import numpy as np

# Load the CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')

# Get all unique Z coordinates from nodes and sort them
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Create output dataframe
output_df = pd.DataFrame({
    'Floor Elevation (m)': floor_elevations
})

# Save to CSV file
output_df.to_csv('Task_18_out.csv', index=False)