import pandas as pd
import os

# Create output folder
os.makedirs('Task_34_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')
node_df = pd.read_csv('Node.csv')

# Find office live loads
office_loads = floor_load_df[floor_load_df['Load Type'] == 'Office']

# Get all beams supporting office loads
supporting_beams = set()

for _, load in office_loads.iterrows():
    # Parse nodes for loading area
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(x.strip()) for x in nodes_str.split(',')]
    
    # Create beam connections for the 4-node area: (1,2), (2,3), (3,4), (4,1)
    beam_connections = []
    for i in range(len(nodes)):
        node1 = nodes[i]
        node2 = nodes[(i + 1) % len(nodes)]  # Wrap around for last connection
        beam_connections.append((min(node1, node2), max(node1, node2)))
    
    # Find elements that match these beam connections
    for node1, node2 in beam_connections:
        matching_elements = element_df[
            ((element_df['Node 1'] == node1) & (element_df['Node 2'] == node2)) |
            ((element_df['Node 1'] == node2) & (element_df['Node 2'] == node1))
        ]
        
        for _, elem in matching_elements.iterrows():
            # Check if it's a beam (horizontal element - same Z coordinate)
            n1_z = node_df[node_df['Node ID'] == elem['Node 1']]['Z (m)'].iloc[0]
            n2_z = node_df[node_df['Node ID'] == elem['Node 2']]['Z (m)'].iloc[0]
            
            if n1_z == n2_z:  # Beam (horizontal element)
                supporting_beams.add(elem['Element ID'])

# Update section numbers for supporting beams
for beam_id in supporting_beams:
    element_df.loc[element_df['Element ID'] == beam_id, 'Section'] = 101

# Sort by Element ID
element_df = element_df.sort_values('Element ID')

# Save updated Element.csv
element_df.to_csv('Task_34_out/Element.csv', index=False)