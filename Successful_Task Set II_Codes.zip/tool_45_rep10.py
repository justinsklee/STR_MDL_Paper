import pandas as pd

# Load CSV files
nodes_df = pd.read_csv('Node.csv')
elements_df = pd.read_csv('Element.csv')
sections_df = pd.read_csv('Long_Section.csv')
materials_df = pd.read_csv('Material.csv')

# Find unique floor elevations
floor_elevations = sorted(nodes_df['Z (m)'].unique())

# Second floor is the second elevation level (index 1)
second_floor_z = floor_elevations[1]

# Find Y-1 grid coordinate (minimum Y coordinate)
y1_coord = nodes_df['Y (m)'].min()

# Get nodes on second floor along Y-1 grid
second_floor_y1_nodes = nodes_df[
    (nodes_df['Z (m)'] == second_floor_z) & 
    (nodes_df['Y (m)'] == y1_coord)
]['Node ID'].tolist()

# Find columns: elements that are vertical (only Z changes, X and Y stay same)
columns = []
for _, element in elements_df.iterrows():
    node1_id = element['Node 1']
    node2_id = element['Node 2']
    
    node1 = nodes_df[nodes_df['Node ID'] == node1_id].iloc[0]
    node2 = nodes_df[nodes_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is vertical (column)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        
        # Check if one node is on second floor Y-1 grid and other is above
        if ((node1_id in second_floor_y1_nodes and node2['Z (m)'] > second_floor_z) or
            (node2_id in second_floor_y1_nodes and node1['Z (m)'] > second_floor_z)):
            columns.append(element)

# Create result dataframe
result_data = []
for column in columns:
    element_id = column['Element ID']
    section_num = column['Section']
    material_num = column['Material']
    
    # Get section name
    section_name = sections_df[sections_df['Section Number'] == section_num]['Section Name'].iloc[0]
    
    # Get material name
    material_name = materials_df[materials_df['Material Number'] == material_num]['Name'].iloc[0]
    
    result_data.append({
        'Element ID': element_id,
        'Section Name': section_name,
        'Material Name': material_name
    })

# Create DataFrame and sort by Element ID
result_df = pd.DataFrame(result_data)
result_df = result_df.sort_values('Element ID')

# Save to CSV
result_df.to_csv('Task_45_out.csv', index=False)

print(f"Found {len(result_df)} columns on second floor along grid Y-1")
print(result_df)