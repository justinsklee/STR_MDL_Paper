import pandas as pd
import os

# Load all relevant CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
floor_load_df = pd.read_csv('Floor_Load.csv')

# Create output folder
os.makedirs('Task_35_out', exist_ok=True)

# Find residential load areas
residential_loads = floor_load_df[floor_load_df['Load Type'] == 'Residential']

# Get nodes that define residential load areas
residential_nodes = set()
for _, load in residential_loads.iterrows():
    nodes_str = load['Nodes for Loading Area']
    nodes = [int(n.strip()) for n in nodes_str.split(',')]
    residential_nodes.update(nodes)

# Find columns that support residential loads (columns attached to residential load nodes from below)
supporting_columns = []

for _, element in element_df.iterrows():
    node1, node2 = element['Node 1'], element['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2].iloc[0]
    
    # Check if element is a column (vertical - only z coordinates change)
    is_column = (node1_coords['X (m)'] == node2_coords['X (m)'] and 
                node1_coords['Y (m)'] == node2_coords['Y (m)'] and 
                node1_coords['Z (m)'] != node2_coords['Z (m)'])
    
    if is_column:
        # Determine which node is above and which is below
        if node1_coords['Z (m)'] > node2_coords['Z (m)']:
            upper_node = node1
            lower_node = node2
        else:
            upper_node = node2
            lower_node = node1
        
        # Check if upper node is in residential load nodes
        if upper_node in residential_nodes:
            supporting_columns.append(element['Element ID'])

# Update material for supporting columns to SHN355 (material 1003)
for col_id in supporting_columns:
    element_df.loc[element_df['Element ID'] == col_id, 'Material'] = 1003

# Sort by Element ID
element_df = element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
element_df.to_csv('Task_35_out/Element.csv', index=False)