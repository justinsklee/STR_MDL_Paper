import pandas as pd
import numpy as np
import os

# Create output folder
output_folder = 'Task_23_out'
os.makedirs(output_folder, exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')
section_df = pd.read_csv('Long_Section.csv')

# Find the section number for H 100x100x6/8
target_section = section_df[section_df['Section Name'] == 'H 100x100x6/8']['Section Number'].iloc[0]

# Find first floor elevation (minimum z value)
first_floor_z = node_df['Z (m)'].min()

# Find second floor elevation (next unique z value above first floor)
unique_z_values = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z_values[1]

# Identify first floor braces
first_floor_braces = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if it's a brace (change in x or y AND change in z)
    x_change = node1_coords['X (m)'] != node2_coords['X (m)']
    y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
    z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if it's a first floor brace (one node at first floor, other above)
        node1_at_first = node1_coords['Z (m)'] == first_floor_z
        node2_at_first = node2_coords['Z (m)'] == first_floor_z
        node1_above_first = node1_coords['Z (m)'] > first_floor_z
        node2_above_first = node2_coords['Z (m)'] > first_floor_z
        
        if (node1_at_first and node2_above_first) or (node2_at_first and node1_above_first):
            first_floor_braces.append(row['Element ID'])

# Update section for first floor braces
for brace_id in first_floor_braces:
    element_df.loc[element_df['Element ID'] == brace_id, 'Section'] = target_section

# Save updated Element.csv
element_df.to_csv(os.path.join(output_folder, 'Element.csv'), index=False)