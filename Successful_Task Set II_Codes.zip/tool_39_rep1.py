import pandas as pd
import os

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Create output folder
os.makedirs('Task_39_out', exist_ok=True)

# Find first floor elevation (ground level)
first_floor_z = 0.0

# Find X-1 grid coordinate (minimum x-coordinate)
x1_coord = node_df['X (m)'].min()

# Find second floor elevation (one story above ground)
unique_z = sorted(node_df['Z (m)'].unique())
second_floor_z = unique_z[1] if len(unique_z) > 1 else first_floor_z + 1

# Identify braces on first floor along grid X-1
elements_to_remove = []

for idx, row in element_df.iterrows():
    node1_id = row['Node 1']
    node2_id = row['Node 2']
    
    # Get coordinates for both nodes
    node1_coords = node_df[node_df['Node ID'] == node1_id].iloc[0]
    node2_coords = node_df[node_df['Node ID'] == node2_id].iloc[0]
    
    # Check if element is a brace (diagonal - change in x/y AND z coordinates)
    x_change = node1_coords['X (m)'] != node2_coords['X (m)']
    y_change = node1_coords['Y (m)'] != node2_coords['Y (m)']
    z_change = node1_coords['Z (m)'] != node2_coords['Z (m)']
    
    is_brace = (x_change or y_change) and z_change
    
    if is_brace:
        # Check if brace is on grid X-1 (both nodes have X-1 coordinate)
        on_x1_grid = (node1_coords['X (m)'] == x1_coord and node2_coords['X (m)'] == x1_coord)
        
        # Check if brace is on first floor (one node at first floor, other above)
        node1_first_floor = node1_coords['Z (m)'] == first_floor_z
        node2_above_first = node2_coords['Z (m)'] > first_floor_z
        node2_first_floor = node2_coords['Z (m)'] == first_floor_z
        node1_above_first = node1_coords['Z (m)'] > first_floor_z
        
        on_first_floor = (node1_first_floor and node2_above_first) or (node2_first_floor and node1_above_first)
        
        if on_x1_grid and on_first_floor:
            elements_to_remove.append(row['Element ID'])

# Remove identified braces
updated_element_df = element_df[~element_df['Element ID'].isin(elements_to_remove)]

# Sort by Element ID in ascending order
updated_element_df = updated_element_df.sort_values('Element ID').reset_index(drop=True)

# Save updated Element.csv
updated_element_df.to_csv('Task_39_out/Element.csv', index=False)

print(f"Removed {len(elements_to_remove)} braces on first floor along grid X-1")
if elements_to_remove:
    print(f"Removed element IDs: {elements_to_remove}")