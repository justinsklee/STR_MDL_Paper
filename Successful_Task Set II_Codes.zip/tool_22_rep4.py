import pandas as pd
import os

# Create output folder
os.makedirs('Task_22_out', exist_ok=True)

# Load CSV files
element_df = pd.read_csv('Element.csv')
node_df = pd.read_csv('Node.csv')

# Find the roof elevation (highest z-coordinate)
roof_elevation = node_df['Z (m)'].max()

# Identify columns (vertical elements with same x,y coordinates but different z)
columns = []
for _, elem in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == elem['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == elem['Node 2']].iloc[0]
    
    # Check if it's a column (same x,y but different z)
    if (node1['X (m)'] == node2['X (m)'] and 
        node1['Y (m)'] == node2['Y (m)'] and 
        node1['Z (m)'] != node2['Z (m)']):
        columns.append(elem['Element ID'])

# Find beams on the roof (both nodes at roof elevation)
roof_beams = []
for _, elem in element_df.iterrows():
    node1 = node_df[node_df['Node ID'] == elem['Node 1']].iloc[0]
    node2 = node_df[node_df['Node ID'] == elem['Node 2']].iloc[0]
    
    # Check if it's a beam on the roof (both nodes at same z, which is roof elevation)
    if (node1['Z (m)'] == node2['Z (m)'] == roof_elevation):
        roof_beams.append(elem['Element ID'])

# Find sub-beams on roof (roof beams not directly connected to columns)
roof_sub_beams = []
for beam_id in roof_beams:
    beam_row = element_df[element_df['Element ID'] == beam_id].iloc[0]
    beam_node1 = beam_row['Node 1']
    beam_node2 = beam_row['Node 2']
    
    # Check if this beam is connected to any column
    connected_to_column = False
    for col_id in columns:
        col_row = element_df[element_df['Element ID'] == col_id].iloc[0]
        col_node1 = col_row['Node 1']
        col_node2 = col_row['Node 2']
        
        if (beam_node1 in [col_node1, col_node2] or 
            beam_node2 in [col_node1, col_node2]):
            connected_to_column = True
            break
    
    if not connected_to_column:
        roof_sub_beams.append(beam_id)

# Update section for roof sub-beams to 104
for sub_beam_id in roof_sub_beams:
    element_df.loc[element_df['Element ID'] == sub_beam_id, 'Section'] = 104

# Save updated Element.csv
element_df.to_csv('Task_22_out/Element.csv', index=False)